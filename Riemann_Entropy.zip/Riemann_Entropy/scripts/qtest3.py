import numpy as np

g = np.load("gammas.npy")
N = len(g)
# unfold so the mean spacing is 1; tau is then time in units of the mean level spacing
w = (g / (2 * np.pi)) * np.log(g / (2 * np.pi * np.e)) + 7.0 / 8.0

BLOCK = 200                                  # average over blocks of zeros
tau = np.linspace(0.005, 2.5, 5000)
K = np.zeros(len(tau))
nb = 0
for i in range(0, N - BLOCK + 1, BLOCK):
    ww = w[i:i + BLOCK]
    amp = np.exp(2j * np.pi * np.outer(tau, ww)).sum(axis=1)   # the complex number that is sensed
    K += np.abs(amp) ** 2 / BLOCK
    nb += 1
K /= nb

print(f"{N} zeros, {nb} blocks of {BLOCK}")
print("power of the complex amplitude |sum exp(2 pi i tau w_n)|^2 / n, averaged in bins of tau")
print("   tau      zeros   no stiffness   unitary stiffness")
edges = [0.05, 0.15, 0.25, 0.35, 0.5, 0.7, 0.9, 1.1, 1.5, 2.0, 2.5]
for a, b in zip(edges[:-1], edges[1:]):
    m = (tau >= a) & (tau < b)
    c = 0.5 * (a + b)
    print(f"{a:4.2f}-{b:4.2f} {K[m].mean():8.4f} {1.0:10.1f} {min(c, 1.0):14.3f}")
