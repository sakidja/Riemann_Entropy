#!/bin/bash
#SBATCH -A m4675
#SBATCH -C cpu
#SBATCH -q debug
#SBATCH -N 1
#SBATCH -t 00:30:00
#SBATCH -J ri_campaign5
#SBATCH -o ri_campaign5_%j.out
#SBATCH -e ri_campaign5_%j.err

module load python
source $SCRATCH/qiskit-env/bin/activate
cd "$SLURM_SUBMIT_DIR"

# Needs, in this folder: zeros1, and the result files of campaigns 1 to 4
# (ri_campaign_results.json, ri_campaign2_results.json, ri_probe_height_results.json, ri_dh_results.json, ri_lpair_results.json).

if [ ! -f gammas.npy ]; then
  echo "===== make_gammas.py 2000 ====="
  python make_gammas.py 2000
  echo
fi

echo "===== qtest1.py: the X reading and the post selection (Tables 14 and 16) ====="
python qtest1.py
echo
echo "===== force.py: restoring force with the zeros of gammas.npy (Section 6.1) ====="
python force.py
echo
echo "===== ri_figdata.py: entropy out to log x = 100, mode shares, modulus across the strip (Figures 4 to 7) ====="
python ri_figdata.py 100
echo
echo "===== ri_derived.py: means, ratios and counts quoted in the text, from the result files ====="
python ri_derived.py
echo
echo "===== make_figures.py: draws Figures 1 to 7 from the result files into ./figures ====="
python -c "import matplotlib" 2>/dev/null || pip install --quiet matplotlib
python make_figures.py
