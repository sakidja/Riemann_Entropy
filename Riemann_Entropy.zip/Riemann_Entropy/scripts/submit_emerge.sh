#!/bin/bash
#SBATCH -A m4675
#SBATCH -C cpu
#SBATCH -q regular
#SBATCH -N 1
#SBATCH -t 03:00:00
#SBATCH -J ri_emerge
#SBATCH -o ri_emerge_%j.out
#SBATCH -e ri_emerge_%j.err

module load python
source $SCRATCH/qiskit-env/bin/activate
cd "$SLURM_SUBMIT_DIR"

# Needs, in this folder: zeros1 (for the check and the floor only) and ri_dh_results.json (for the DH check only).
# The three runs themselves read nothing but the primes and the DH series.

echo "===== ri_emerge.py: the zeros from the primes alone, delta free (version two) ====="
python -c "import scipy" 2>/dev/null || pip install --quiet scipy
python ri_emerge.py 1e9 1e8 500 2000
python ri_mirror.py
