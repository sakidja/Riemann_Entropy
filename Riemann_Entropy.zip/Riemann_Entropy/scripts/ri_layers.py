"""The layers of the Davenport and Heilbronn function: groups of modes with one common weight.

Reads   ri_dh_results.json      zeros of the Davenport and Heilbronn function   (ri_dh.py, campaign 3)
        ri_figdata_results.json (if present) entropy at single values of log x   (ri_figdata.py, campaign 5), for a check
Writes  ri_layers_results.json  every number that the figure shows
        figures/fig9_layers.png and .pdf

With t = log x, rho_n = sigma_n + i gamma_n, delta_n = sigma_n - 1/2, zeros above the real axis, and shares
   p_n(t) = |rho_n|^-2 e^(2 delta_n t) / sum_m |rho_m|^-2 e^(2 delta_m t)          (Section 1; ri_figdata.py part B)
the modes are sorted into layers, a layer being the set of modes with one value of delta:
   the zeros on the line (delta = 0) are one layer; every zero off the line is a layer of its own.
Shannon's grouping rule splits the entropy exactly:
   H(t) = H_between(t) + sum_g P_g(t) H_g
   P_g(t)       share of layer g
   H_between    entropy of the shares P_g
   H_g          entropy inside layer g, from the shares of its modes relative to the layer
Inside a layer the factor e^(2 delta t) is common and cancels: H_g does not depend on t.

Usage:  python ri_layers.py [TMAX]        (default 100; a few seconds, no job needed)
"""
import json
import os
import sys
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

TMAX = int(sys.argv[1]) if len(sys.argv) > 1 else 100
HERE = os.path.dirname(os.path.abspath(__file__))
FLAT = os.path.exists(os.path.join(HERE, "ri_dh_results.json"))      # on Perlmutter the scripts and the results share one folder
R = HERE if FLAT else os.path.join(HERE, "..", "results")
F = os.path.join(HERE, "figures") if FLAT else os.path.join(HERE, "..", "figures")
os.makedirs(F, exist_ok=True)


def H_of(p):
    q = p[p > 0]
    return float(-np.sum(q * np.log(q)))


p_dh = os.path.join(R, "ri_dh_results.json")
if not os.path.exists(p_dh):
    sys.exit(f"ri_dh_results.json is not in {os.path.normpath(R)}")
with open(p_dh) as f:
    dh = json.load(f)
on = np.array(dh["zeros"]["on_line"])
osig, ogam = np.array(dh["zeros"]["off_sigma"]), np.array(dh["zeros"]["off_gamma"])
rho_on = 0.5 + 1j * on
rho_up = osig + 1j * ogam                    # the member of each pair with delta > 0
rho_dn = 1 - osig + 1j * ogam                # its mirror image, delta < 0
if np.any(osig < 0.5):
    rho_up, rho_dn = np.where(osig >= 0.5, rho_up, rho_dn), np.where(osig >= 0.5, rho_dn, rho_up)
t = np.linspace(2, TMAX, 10 * (TMAX - 2) + 1)
print(f"Davenport and Heilbronn, heights below {dh['zeros']['T']:g}:")
print(f"   layer of the line: {len(rho_on)} modes with delta = 0")
print(f"   {len(rho_up)} single mode layers with delta > 0, and their {len(rho_dn)} mirror images with delta < 0")


def logterm(rho):
    return -2 * np.log(np.abs(rho))[:, None] + 2 * (rho.real - 0.5)[:, None] * t[None, :]


l_on, l_up, l_dn = logterm(rho_on), logterm(rho_up), logterm(rho_dn)
allm = np.vstack([l_on, l_up, l_dn])
mx = allm.max(axis=0)
logS = mx + np.log(np.exp(allm - mx).sum(axis=0))
p_on, p_up, p_dn = np.exp(l_on - logS), np.exp(l_up - logS), np.exp(l_dn - logS)

# ---- the grouping rule
P_on = p_on.sum(axis=0)                                              # share of the layer of the line
w = 1.0 / np.abs(rho_on) ** 2
H_on = H_of(w / w.sum())                                             # entropy inside the layer of the line: no t in it
H_on_t = np.array([H_of(p_on[:, j] / P_on[j]) if P_on[j] > 1e-300 else np.nan for j in range(0, len(t), 49)])
Hb = np.array([H_of(np.concatenate([[P_on[j]], p_up[:, j], p_dn[:, j]])) for j in range(len(t))])        # entropy between the layers
Htot = np.array([H_of(np.concatenate([p_on[:, j], p_up[:, j], p_dn[:, j]])) for j in range(len(t))])   # entropy over all the modes
inside = P_on * H_on

print("\nA. INSIDE THE LAYER OF THE LINE")
print(f"   entropy inside the layer, from |rho|^-2 alone:          {H_on:.6f}")
print(f"   the same, from the shares at {len(H_on_t)} values of log x:      {np.nanmin(H_on_t):.6f} to {np.nanmax(H_on_t):.6f}")

print("\nB. THE GROUPING RULE   H = H_between + P_line x H_line     (single mode layers have no entropy inside)")
print("   log x    H, all modes   H between layers   share of the line   P_line x H_line   sum         difference")
tab = []
for tv in [2, 5, 7] + list(range(10, TMAX + 1, 10)):
    j = int(np.argmin(np.abs(t - tv)))
    tab.append([float(t[j]), float(Htot[j]), float(Hb[j]), float(P_on[j]), float(inside[j]), float(Hb[j] + inside[j])])
    print(f"   {t[j]:5.0f}   {Htot[j]:10.4f}   {Hb[j]:14.4f}   {P_on[j]:16.3e}   {inside[j]:14.4f}   {Hb[j] + inside[j]:10.4f}   {Htot[j] - Hb[j] - inside[j]:10.1e}")
print(f"   largest difference on the grid: {np.abs(Htot - Hb - inside).max():.1e}")

chk = os.path.join(R, "ri_figdata_results.json")
if os.path.exists(chk):
    with open(chk) as f:
        fd = json.load(f)
    if "shares_at_log_x" in fd and "rows" in fd["shares_at_log_x"]:
        c = fd["shares_at_log_x"]["columns"]
        print("\n   check against campaign 5 (ri_figdata.py part B), entropy at single values of log x:")
        for r in fd["shares_at_log_x"]["rows"]:
            d = dict(zip(c, r))
            tv = d.get("log_x", r[0])
            Hc = d.get("H", r[-1])
            j = int(np.argmin(np.abs(t - tv)))
            if abs(t[j] - tv) < 1e-9:
                print(f"      log x = {tv:5.0f}   here {Htot[j]:.4f}   campaign 5 {Hc:.4f}")

print("\nC. THE LAYERS IN THE ORDER THEY GO   (a layer is counted while its share is above 0.01)")
print("   layer                         delta      largest share   at log x   above 0.01 from   to")
order = np.argsort(rho_up.real)
rows_c = []
big = []
for i in order:
    s = p_up[i]
    if s.max() < 0.01:
        continue
    a = np.where(s >= 0.01)[0]
    last = "end" if a[-1] == len(t) - 1 else f"{t[a[-1]]:.1f}"
    print(f"   {rho_up[i].real:.6f} + {rho_up[i].imag:10.6f} i   {rho_up[i].real - 0.5:.4f}   {s.max():10.4f}   {t[s.argmax()]:9.1f}   {t[a[0]]:10.1f}      {last}")
    rows_c.append({"sigma": float(rho_up[i].real), "gamma": float(rho_up[i].imag), "largest_share": float(s.max()), "at_log_x": float(t[s.argmax()]),
                   "above_from": float(t[a[0]]), "above_to": float(t[a[-1]])})
    if s.max() >= 0.03:
        big.append(int(i))
a = np.where(P_on >= 0.01)[0]
print(f"   the layer of the line          0.0000   {P_on.max():10.4f}   {t[P_on.argmax()]:9.1f}   {t[a[0]]:10.1f}      {t[a[-1]]:.1f}")
print(f"   all mirror images together: largest share {p_dn.sum(axis=0).max():.2e}")

rest = np.ones(len(rho_up), dtype=bool)
rest[big] = False
OUT = {"t": t.tolist(), "H_all_modes": Htot.tolist(), "H_between_layers": Hb.tolist(), "share_of_the_line": P_on.tolist(), "H_inside_the_line": H_on,
       "share_of_mirror_images": p_dn.sum(axis=0).tolist(), "share_of_other_off_line_layers": p_up[rest].sum(axis=0).tolist(),
       "named_layers": [{"sigma": float(rho_up[i].real), "gamma": float(rho_up[i].imag), "share": p_up[i].tolist()} for i in sorted(big, key=lambda k: rho_up[k].real)],
       "layers_above_one_percent": rows_c, "table": {"columns": ["log_x", "H_all_modes", "H_between_layers", "share_of_the_line", "inside_term", "sum"], "rows": tab}}
with open(os.path.join(R, "ri_layers_results.json"), "w") as f:
    json.dump(OUT, f)
print("\nwrote ri_layers_results.json")

# ---------------------------------------------------------------- the figure, drawn from the file just written
with open(os.path.join(R, "ri_layers_results.json")) as f:
    D = json.load(f)
BLUE, ORANGE, AQUA, YELLOW, VIOLET, MAGENTA = "#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#7a5cd6", "#c2417c"
INK, INK2, GRID, SURF, GREY = "#0b0b0b", "#52514e", "#e4e3df", "#fcfcfb", "#b9b7b0"
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9, "axes.edgecolor": INK2, "axes.labelcolor": INK,
                     "xtick.color": INK2, "ytick.color": INK2, "axes.spines.top": False, "axes.spines.right": False,
                     "axes.linewidth": 0.8, "figure.facecolor": SURF, "axes.facecolor": SURF, "savefig.facecolor": SURF,
                     "axes.titlesize": 10, "axes.titleweight": "bold", "axes.titlelocation": "left"})
tt = np.array(D["t"])
named = D["named_layers"]
pal = [YELLOW, AQUA, MAGENTA, "#3aa6c9", "#9a7b2f", "#6b8e23", "#d98c5f"]
ncol = [VIOLET if k == len(named) - 1 else pal[k % len(pal)] for k in range(len(named))]
stack = [np.array(D["share_of_the_line"]), np.array(D["share_of_other_off_line_layers"]) + np.array(D["share_of_mirror_images"])] + [np.array(m["share"]) for m in named]
cols = [BLUE, GREY] + ncol
fig, (a1, a2) = plt.subplots(2, 1, figsize=(7.2, 6.8), sharex=True, gridspec_kw={"height_ratios": [1.15, 1], "hspace": 0.2})
fig.suptitle("The layers go one at a time, lowest δ first; inside a layer nothing changes", x=0.02, ha="left", fontsize=11, fontweight="bold", y=0.975)

a1.set_title("Share of the variance held by each layer")
a1.stackplot(tt, *stack, colors=cols, linewidth=0.6, edgecolor=SURF)
a1.set_ylim(0, 1)
a1.set_ylabel("share")
cum = np.cumsum(np.vstack(stack), axis=0)


def label(ax, k, text, color):
    s = stack[k]
    j = int(np.argmax(s * (tt < 0.93 * tt[-1])))
    if j < len(tt) // 4:
        j = int(np.argmin(np.abs(tt - (tt[j] + 0.09 * (tt[-1] - tt[0])))))
    y = cum[k, j] - 0.5 * s[j]
    ax.text(tt[j], y, text, color=color, fontsize=8, ha="center", va="center", bbox={"facecolor": SURF, "edgecolor": "none", "pad": 1.2, "alpha": 0.85})


a1.text(tt[0] + 0.6, 0.30, f"the line\nδ = 0\n{len(rho_on)} modes\none layer", color="white", fontsize=8, ha="left", va="center", fontweight="bold")
for k, m in enumerate(named):
    if max(m["share"]) >= 0.12:
        label(a1, k + 2, f"δ = {m['sigma'] - 0.5:.4f}\n{m['sigma']:.3f} + {m['gamma']:.1f} i", INK)
a1.text(tt[-1] * 0.99, 0.04, "grey: all other layers off the line", color=INK2, fontsize=8, ha="right", va="bottom")

a2.set_title("Entropy over modes, split by Shannon's grouping rule")
a2.fill_between(tt, 0, D["H_between_layers"], color=ORANGE, alpha=0.28, linewidth=0)
a2.fill_between(tt, D["H_between_layers"], D["H_all_modes"], color=BLUE, alpha=0.30, linewidth=0)
a2.plot(tt, D["H_all_modes"], color=INK, lw=2.0)
a2.plot(tt, D["H_between_layers"], color=ORANGE, lw=1.8)
a2.set_ylim(0, max(D["H_all_modes"]) * 1.12)
a2.set_xlim(tt[0], tt[-1])
a2.set_xlabel("log x")
a2.set_ylabel("entropy")
a2.grid(axis="y", color=GRID, lw=0.8)
a2.set_axisbelow(True)
jm = int(np.argmax(D["H_all_modes"]))
a2.annotate("total, H", xy=(tt[jm] + 3, D["H_all_modes"][jm + 30]), xytext=(tt[jm] + 14, max(D["H_all_modes"]) * 0.98), color=INK, fontsize=8.5,
            arrowprops={"arrowstyle": "-", "color": INK2, "lw": 0.7})
a2.text(tt[-1] * 0.99, max(D["H_all_modes"]) * 0.80, f"blue band: inside the layer of the line\n= its share × {D['H_inside_the_line']:.3f}; the {D['H_inside_the_line']:.3f} never changes, only the share does",
        color=BLUE, fontsize=8.5, ha="right", va="top")
a2.text(tt[-1] * 0.99, max(D["H_all_modes"]) * 0.50, "orange: between the layers", color=ORANGE, fontsize=8.5, ha="right", va="top")
fig.savefig(os.path.join(F, "fig9_layers.png"), dpi=300, bbox_inches="tight")
fig.savefig(os.path.join(F, "fig9_layers.pdf"), bbox_inches="tight")
print("wrote figures/fig9_layers.png and .pdf")
