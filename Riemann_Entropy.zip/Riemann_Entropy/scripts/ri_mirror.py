"""The mirror test on the returned modes: no new run, the data of ri_emerge_results.json only.

Each mode returned by ri_emerge.py has a position s = 1/2 + delta + i gamma. The functional equation sends s to 1 - s^*,
that is Re s to 1 - Re s at the same height. A mode on the line is its own mirror image, and the distance between a mode
and its image is the mirror gap, 2 |delta|. For each function one figure with two parts:
  A  the returned modes (left) and their mirror images (right) on the same axes, in the layout of Figure 7 of version one;
  B  the mirror gap of every mode against height on a log axis, with the mean of log(gap) as a line and its one sigma
     band shaded: for a closed register every mode sits in the band at the precision of the data; a leak stands above it.
The output prints the largest gap and the mean and spread of log(gap).

Reads    ri_emerge_results.json (zeta: modes below GMAX, and the bands above it if present; DH: the same)
Writes   figures/fig_mirror_zeta.png/.pdf and figures/fig_mirror_dh.png/.pdf

Usage:   python ri_mirror.py            (run in the folder that holds ri_emerge_results.json)
"""
import json
import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import gridspec

HERE = os.path.dirname(os.path.abspath(__file__))
FLAT = os.path.exists(os.path.join(HERE, "ri_emerge_results.json"))
R = HERE if FLAT else os.path.join(HERE, "..", "results")
F = os.path.join(HERE, "figures") if FLAT else os.path.join(HERE, "..", "figures")
os.makedirs(F, exist_ok=True)

J = json.load(open(os.path.join(R, "ri_emerge_results.json")))
GMAX = float(J["GMAX"])

BLUE, ORANGE, INK, INK2, GRID, SURF = "#2a78d6", "#eb6834", "#0b0b0b", "#52514e", "#e4e3df", "#fcfcfb"
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9, "axes.edgecolor": INK2, "axes.labelcolor": INK,
                     "xtick.color": INK2, "ytick.color": INK2, "axes.spines.top": False, "axes.spines.right": False,
                     "axes.linewidth": 0.8, "figure.facecolor": SURF, "axes.facecolor": SURF, "savefig.facecolor": SURF,
                     "axes.titlesize": 9.5, "axes.titleweight": "bold", "axes.titlelocation": "left"})


def collect(key):
    """gamma and delta of every returned mode: the main run below GMAX plus the bands above it, if present"""
    m = np.array(J[key]["modes"])
    gam, dl = m[:, 0], m[:, 1]
    if "wide" in J:
        w = J["wide"]["zeta" if key == "zeta" else "DH"]
        gw, dw = np.array(w["gamma"]), np.array(w["delta"])
        if gw.min() < GMAX:                               # the bands cover the whole strip: use them alone
            gam, dl = gw, dw
        else:                                             # older runs: the single window below GMAX, the bands above it
            keep = gw >= GMAX
            gam, dl = np.concatenate([gam, gw[keep]]), np.concatenate([dl, dw[keep]])
    o = np.argsort(gam)
    return gam[o], dl[o]


for key, tag, name in (("zeta", "zeta", "Zeta function"), ("DH", "dh", "Davenport and Heilbronn function")):
    gam, dl = collect(key)
    hmax = float(np.ceil(gam.max() / 100) * 100)
    gap = 2 * np.abs(dl)                                  # distance between a mode and its mirror image
    # a doublet member is one of two poles returned at the same height (ri_emerge.py, pole_groups); every other mode is on the line
    dg = np.array([d[0] for d in (J["wide"]["DH"]["doublets"] if ("wide" in J and key == "DH") else [])] + [d[0] for d in (J["states"]["dh_doublets"] if key == "DH" else [])])
    on = np.ones(len(gam), bool) if len(dg) == 0 else (np.min(np.abs(gam[:, None] - dg[None, :]), axis=1) > 1e-2)
    gap_pos = np.where(gap > 0, gap, 1e-16)
    lg = np.log10(gap_pos[on])                            # the band is the spread of the modes on the line
    lm, ls = lg.mean(), lg.std()
    i = int(np.argmax(gap))
    print(f"{name}: {len(gam)} returned modes below {hmax:.0f}; {int(on.sum())} on the line, {int((~on).sum())} off it")
    print(f"   largest mirror gap 2|delta| = {gap[i]:.2e} at gamma = {gam[i]:.6f}")
    print(f"   log10 of the gap on the line: mean {lm:.2f}, one sigma {ls:.2f}; band 10^{lm - ls:.2f} to 10^{lm + ls:.2f}")
    print(f"   modes with a mirror gap above 1e-6: {int(np.sum(gap > 1e-6))} of {len(gam)}")

    fig = plt.figure(figsize=(7.4, 5.4))
    gs = gridspec.GridSpec(2, 2, figure=fig, height_ratios=[1, 1.05], hspace=0.55, wspace=0.12)
    a1 = fig.add_subplot(gs[0, 0]); a2 = fig.add_subplot(gs[0, 1], sharey=a1); b = fig.add_subplot(gs[1, :])
    for ax, res, title in ((a1, 0.5 + dl, "A. returned modes"), (a2, 0.5 - dl, "their mirror images, Re s to 1 − Re s")):
        ax.axhline(0.5, color=GRID, lw=0.8)
        ax.plot(gam, res, ls="", marker="x", ms=3.0, mew=0.7, color=INK)
        ax.set_xlim(0, hmax); ax.set_ylim(0, 1); ax.set_yticks([0, 0.25, 0.5, 0.75, 1])
        ax.set_xlabel("height of the mode, Im s"); ax.set_title(title)
    a1.set_ylabel("Re s"); plt.setp(a2.get_yticklabels(), visible=False)
    b.plot(gam[on], gap_pos[on], ls="", marker=".", ms=2.4, color=INK, alpha=0.75)
    b.plot(gam[~on], gap_pos[~on], ls="", marker="o", ms=3.2, mfc="none", mec=ORANGE, mew=0.9)
    b.axhspan(10 ** (lm - ls), 10 ** (lm + ls), color=BLUE, alpha=0.18, lw=0)
    b.axhline(10 ** lm, color=BLUE, lw=1.0)
    b.set_yscale("log"); b.set_xlim(0, hmax)
    b.set_ylim(10 ** min(lm - 3.5, lg.min() - 0.5), max(10 ** (lm + 2.5), gap.max() * 3))
    b.set_xlabel("height of the mode, Im s"); b.set_ylabel("mirror gap, 2|δ|")
    b.set_title("B. mirror gap of every mode (line and band: mean and one sigma of the modes on the line)")
    if (~on).any():                                       # the modes off the line: their gap is 2|delta| of the pair, a property of the function
        b.text(0.02 * hmax, 10 ** (np.median(np.log10(gap[~on])) - 1.6), "open circles: 2|δ| of the pairs off the line, inherent to the function",
               fontsize=8, color=ORANGE, ha="left", va="top")
    fig.suptitle(f"{name}: the mirror test on the returned modes", x=0.02, ha="left", fontsize=11, fontweight="bold", y=0.985)
    fig.savefig(os.path.join(F, f"fig_mirror_{tag}.png"), dpi=300, bbox_inches="tight")
    fig.savefig(os.path.join(F, f"fig_mirror_{tag}.pdf"), bbox_inches="tight")
    plt.close(fig)
print("wrote figures/fig_mirror_zeta, fig_mirror_dh")
