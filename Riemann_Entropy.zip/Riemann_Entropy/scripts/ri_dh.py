"""A collapsing case that is not made by hand: the Davenport and Heilbronn function.
   f(s) = 5^(-s) [ zeta(s,1/5) + k zeta(s,2/5) - k zeta(s,3/5) - zeta(s,4/5) ],  k = (sqrt(10 - 2 sqrt 5) - 2)/(sqrt 5 - 1)
It has a functional equation of the same kind as the zeta function, s <-> 1 - s, and a Dirichlet series
with coefficients 1, k, -k, -1, 0 (period 5), but NO product over primes.  Its zeros are not all on the line.
  A. All zeros with 0 < Im < T are located numerically (on the line and off it).
  B. Variance of the scaled fluctuation by window, share of the modes off the line, entropy over modes.
  C. The same fluctuation from the arithmetic side alone (coefficients of -f'/f), no zeros used.
Usage: python ri_dh.py [T] [NMAX]      (default T = 2000, NMAX = 1e6; zeros1 in this folder is used for comparison if present)
"""
import json
import os
import sys
import time
import numpy as np
from scipy.special import loggamma

T0 = time.time()
TTOP = float(sys.argv[1]) if len(sys.argv) > 1 else 2000.0
NMAX = int(float(sys.argv[2])) if len(sys.argv) > 2 else 10 ** 6
KAP = (np.sqrt(10 - 2 * np.sqrt(5)) - 2) / (np.sqrt(5) - 1)
BERN = [1 / 6, -1 / 30, 1 / 42, -1 / 30, 5 / 66, -691 / 2730, 7 / 6, -3617 / 510]
OUT = {}


def section(title):
    print()
    print("=" * 78)
    print(title)
    print("=" * 78)
    sys.stdout.flush()


def hurwitz(s, a, N):
    """Hurwitz zeta by Euler and Maclaurin summation; s complex array, N terms (N > |s|)."""
    n = np.arange(N) + a
    S = np.exp(-np.outer(s, np.log(n))).sum(axis=1)
    b = N + a
    lb = np.log(b)
    S += np.exp((1 - s) * lb) / (s - 1) + 0.5 * np.exp(-s * lb)
    poch = s.copy()
    fact = 2.0
    for k in range(1, len(BERN) + 1):
        S += BERN[k - 1] / fact * poch * np.exp((-s - 2 * k + 1) * lb)
        poch = poch * (s + 2 * k - 1) * (s + 2 * k)
        fact *= (2 * k + 1) * (2 * k + 2)
    return S


def F(s, N=None, chunk=4000):
    s = np.atleast_1d(np.asarray(s, dtype=complex))
    out = np.empty(len(s), dtype=complex)
    for i in range(0, len(s), chunk):
        ss = s[i:i + chunk]
        n = N if N is not None else int(np.abs(ss.imag).max()) + 40
        out[i:i + chunk] = np.exp(-ss * np.log(5)) * (hurwitz(ss, 0.2, n) + KAP * hurwitz(ss, 0.4, n)
                                                       - KAP * hurwitz(ss, 0.6, n) - hurwitz(ss, 0.8, n))
    return out


def theta(t):
    return np.imag(loggamma(0.75 + 0.5j * t)) + 0.5 * t * np.log(5 / np.pi)


def Z(t):
    """real on the critical line: e^(i theta(t)) f(1/2 + it)"""
    return np.real(np.exp(1j * theta(t)) * F(0.5 + 1j * t))


# ---------------------------------------------------------------- A. zeros
section(f"A. ZEROS of the Davenport and Heilbronn function, 0 < Im < {TTOP:g}")
chk = F(np.array([0.5 + 10j]))[0]
print(f"check: f(1/2 + 10i) = {chk:.12f}   (mpmath: 1.667900783472+0.949827346451j)")
tg = np.arange(0.5, TTOP, 0.01)
zg = Z(tg)
idx = np.nonzero(np.sign(zg[:-1]) * np.sign(zg[1:]) < 0)[0]
lo, hi = tg[idx].copy(), tg[idx + 1].copy()
flo = zg[idx].copy()
for _ in range(45):
    mid = 0.5 * (lo + hi)
    fm = Z(mid)
    left = np.sign(fm) == np.sign(flo)
    lo = np.where(left, mid, lo)
    flo = np.where(left, fm, flo)
    hi = np.where(left, hi, mid)
on_line = 0.5 * (lo + hi)
print(f"on the line, by sign changes of Z(t): {len(on_line)} zeros   [{time.time() - T0:.0f} s]")
sys.stdout.flush()

# off the line: local minima of |f| on a grid, then Newton
sig = np.arange(0.5, 2.0001, 0.05)
tt = np.arange(0.5, TTOP, 0.05)
starts = []
CH = 2000
prev_tail = None
for i in range(0, len(tt), CH):
    j0, j1 = max(i - 1, 0), min(i + CH + 1, len(tt))
    tc = tt[j0:j1]
    S, Tm = np.meshgrid(sig, tc, indexing="ij")
    A = np.abs(F((S + 1j * Tm).ravel(), N=int(tc[-1]) + 40)).reshape(S.shape)
    P = np.pad(A, 1, constant_values=np.inf)
    ismin = np.ones_like(A, dtype=bool)
    for da in (-1, 0, 1):
        for db in (-1, 0, 1):
            if da or db:
                ismin &= A <= P[1 + da:1 + da + A.shape[0], 1 + db:1 + db + A.shape[1]]
    ismin[:, 0] &= (j0 == 0)
    ismin[:, -1] &= (j1 == len(tt))
    ia, ib = np.nonzero(ismin & (A < 1.0))
    starts.extend(sig[ia] + 1j * tc[ib])
starts = np.array(starts)
print(f"grid of {len(sig)} x {len(tt)} points: {len(starts)} local minima of |f|   [{time.time() - T0:.0f} s]")
sys.stdout.flush()
s = starts.copy()
NN = int(TTOP) + 60
h = 1e-5
for _ in range(40):
    f0 = F(s, N=NN)
    d = (F(s + h, N=NN) - F(s - h, N=NN)) / (2 * h)
    step = f0 / np.where(np.abs(d) > 1e-12, d, 1e-12)
    step = np.where(np.abs(step) > 0.2, 0.2 * step / np.abs(step), step)
    s = s - step
res = np.abs(F(s, N=NN))
ok = (res < 1e-8) & (s.imag > 0.4) & (s.imag < TTOP) & (s.real > -1.5) & (s.real < 2.5)
s = s[ok]
s = np.where(s.real < 0.5, 1 - s.real + 1j * s.imag, s)          # zeros come in pairs sigma, 1 - sigma
s = s[np.argsort(s.imag)]
keep = np.ones(len(s), dtype=bool)
for i in range(1, len(s)):
    if abs(s[i] - s[i - 1]) < 1e-5:
        keep[i] = False
s = s[keep]
off = s[np.abs(s.real - 0.5) > 1e-6]
newton_on = s[np.abs(s.real - 0.5) <= 1e-6].imag
extra = [g for g in newton_on if np.min(np.abs(on_line - g)) > 1e-5]
if extra:
    on_line = np.sort(np.concatenate([on_line, extra]))
print(f"Newton: {len(s)} zeros in the right half of the strip and beyond, {len(off)} of them off the line; "
      f"{len(extra)} more on the line that the sign changes missed   [{time.time() - T0:.0f} s]")
ntot = len(on_line) + 2 * len(off)
nbar = theta(np.array([TTOP]))[0] / np.pi
print(f"total with 0 < Im < {TTOP:g}: {len(on_line)} on the line + 2 x {len(off)} off the line = {ntot};  "
      f"smooth count theta(T)/pi = {nbar:.1f}")
print(f"fraction off the line: {2 * len(off) / ntot:.4f}")
right = off[off.real > 1]
print(f"zeros to the right of sigma = 1: {len(right)}")
print("\nzeros off the line (sigma > 1/2; each has a partner at 1 - sigma), first 25 and the 5 with the largest sigma:")
for z in off[:25]:
    print(f"   {z.real:.6f} + {z.imag:.6f} i")
print("   ...")
for z in off[np.argsort(-off.real)[:5]]:
    print(f"   {z.real:.6f} + {z.imag:.6f} i      weight 1/|rho|^2 = {1 / abs(z) ** 2:.3e}")
OUT["zeros"] = {"T": TTOP, "on_line": on_line.tolist(), "off_sigma": off.real.tolist(), "off_gamma": off.imag.tolist()}
sys.stdout.flush()

# ---------------------------------------------------------------- B. variance and entropy
section("B. VARIANCE BY WINDOW and ENTROPY OVER MODES, from the zeros")
rho_on = 0.5 + 1j * on_line
rho_off = np.concatenate([off, 1 - off.real + 1j * off.imag])
rho_all = np.concatenate([rho_on, rho_off])


def mode_sum(rho, t, chunk=400):
    f = np.zeros(len(t))
    for i in range(0, len(rho), chunk):
        r = rho[i:i + chunk]
        f += 2.0 * np.real(np.exp(np.outer(r - 0.5, t)) / r[:, None]).sum(axis=0)
    return f


def entropy(rho, lo, hi):
    a = 1.0 / np.abs(rho) ** 2
    e = 2 * (rho.real - 0.5)
    g = np.where(np.abs(e) < 1e-12, 1.0, (np.exp(e * hi) - np.exp(e * lo)) / np.where(np.abs(e) < 1e-12, 1.0, e * (hi - lo)))
    p = a * g
    p = p / p.sum()
    q = p[p > 0]
    return -np.sum(q * np.log(q)), p


WINDOWS = [(2, 4), (4, 6), (6, 8), (8, 10), (10, 12), (12, 14), (14, 16), (16, 18), (18, 20)]
zeta = None
if os.path.exists("zeros1"):
    zz = np.loadtxt("zeros1")
    zeta = 0.5 + 1j * zz[:len(rho_all)]
print("The scaled fluctuation is 2 Re sum over zeros of x^(rho - 1/2) / rho, with t = log x.")
print(f"Davenport and Heilbronn: {len(rho_all)} zeros.  Zeta function, for comparison: the first {len(rho_all)} zeros (all on the line).")
print("share off the line: measured = (Var all - Var line only)/Var all;  predicted = sum over the modes off the line of their weights")
print("\n  window   Var, zeros on   Var, all    share off line   share off line   entropy   largest single   | zeta:      zeta:")
print("           the line only   zeros       measured         predicted        H         share            | Var        entropy H")
rows = []
for lo, hi in WINDOWS:
    t = np.linspace(lo, hi, 6000)
    v_on = mode_sum(rho_on, t).var()
    v_all = mode_sum(rho_all, t).var()
    H, p = entropy(rho_all, lo, hi)
    sp = p[len(rho_on):].sum()
    sm = (v_all - v_on) / v_all
    zv, zH = (np.nan, np.nan)
    if zeta is not None:
        zv = mode_sum(zeta, t).var()
        zH = entropy(zeta, lo, hi)[0]
    print(f"  [{lo:2d},{hi:2d}] {v_on:13.5f} {v_all:12.5g} {sm:13.4f} {sp:16.4f} {H:12.4f} {p.max():12.4f}          | {zv:8.5f} {zH:10.4f}")
    rows.append([lo, hi, float(v_on), float(v_all), float(sm), float(sp), float(H), float(p.max()), float(zv), float(zH)])
OUT["variance_entropy"] = rows
top = rho_all[np.argmax(rho_all.real)]
print(f"\nmode with the largest sigma: {top.real:.6f} + {top.imag:.6f} i;  its variance grows by e^(2 (sigma - 1/2) 2) = "
      f"{np.exp(4 * (top.real - 0.5)):.3f} from one window to the next")
print(f"entropy with every zero held on the line (same heights): {entropy(0.5 + 1j * rho_all.imag, 2, 4)[0]:.4f}, the same in every window")
print(f"[{time.time() - T0:.0f} s]")
sys.stdout.flush()

# ---------------------------------------------------------------- C. arithmetic side
section("C. THE SAME FLUCTUATION FROM THE ARITHMETIC SIDE (no zeros used)")
print("-f'(s)/f(s) = sum c(n) n^(-s), with c from  a(n) log n = sum over d | n of c(d) a(n/d),  a = 1, k, -k, -1, 0 (period 5).")
print("For the zeta function c(n) is log p on prime powers and zero elsewhere.  Here there is no product over primes,")
print("and c(n) is not confined to prime powers.  psi_f(x) = sum of c(n) for n <= x;  the explicit formula gives")
print("psi_f(x) = - sum over zeros of x^rho / rho + smooth terms, with no term in x.")
a = np.array([0.0, 1.0, KAP, -KAP, -1.0])[np.arange(NMAX + 1) % 5]
c = a * np.log(np.maximum(np.arange(NMAX + 1), 1))
for d in range(2, NMAX // 2 + 1):
    if c[d] != 0.0:
        m = NMAX // d
        c[2 * d::d] -= c[d] * a[2:m + 1]
pp = np.ones(NMAX + 1, dtype=bool)
pp[:2] = False
for i in range(2, int(NMAX ** 0.5) + 1):
    if pp[i]:
        pp[i * i::i] = False
ispp = np.zeros(NMAX + 1, dtype=bool)
for p in np.nonzero(pp)[0]:
    q = int(p)
    while q <= NMAX:
        ispp[q] = True
        q *= int(p)
tot = np.sum(np.abs(c[2:]))
print(f"\nn up to {NMAX:.3g}: share of sum |c(n)| that sits on prime powers = {np.sum(np.abs(c[ispp])) / tot:.4f}   (zeta function: 1)")
print("first values c(2) ... c(12): " + "  ".join(f"{v:.4f}" for v in c[2:13]))
psi = np.cumsum(c)
rng = np.random.default_rng(20261105)
tmax = np.log(NMAX)
WA = [(lo, hi) for lo, hi in WINDOWS if hi <= tmax + 1e-9]
if WA[-1][1] < tmax - 0.3:
    WA.append((WA[-1][1], float(np.floor(tmax * 10) / 10)))
print("\n  window        Var of psi_f(x)/sqrt(x),    Var from all zeros     ratio    correlation of the two")
print("                arithmetic side             found in part A                 on the same points")
rows = []
for lo, hi in WA:
    t = np.sort(rng.uniform(lo, hi, 6000))
    x = np.exp(t)
    fa = psi[np.minimum(x.astype(np.int64), NMAX)] / np.sqrt(x)
    fz = -mode_sum(rho_all, t)
    cc = np.corrcoef(fa, fz)[0, 1]
    print(f"  [{lo:4.1f},{hi:4.1f}] {fa.var():20.5g} {fz.var():22.5g} {fa.var() / fz.var():10.3f} {cc:14.4f}")
    rows.append([lo, hi, float(fa.var()), float(fz.var()), float(cc)])
OUT["arithmetic"] = rows
print("\nFor the true primes the same quantity is 0.046 in every window (campaign 2, part C1).")

with open("ri_dh_results.json", "w") as fjs:
    json.dump(OUT, fjs, indent=1)
print(f"\nwrote ri_dh_results.json   [{time.time() - T0:.0f} s]")
