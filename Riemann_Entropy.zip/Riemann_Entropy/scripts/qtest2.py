import numpy as np

g = np.load("gammas.npy")
# unfold: mean spacing 1 everywhere, using the smooth (first moment) count of zeros
w = (g / (2 * np.pi)) * np.log(g / (2 * np.pi * np.e)) + 7.0 / 8.0
s = np.diff(w)
print(f"{len(g)} zeros, mean unfolded spacing = {s.mean():.4f}, smallest spacing = {s.min():.4f}")

# 1. resistance to clumping: how often are two neighbours close?
ss = np.linspace(0, 4, 40001)
wig = (32 / np.pi ** 2) * ss ** 2 * np.exp(-4 * ss ** 2 / np.pi)
cdf = np.cumsum(wig) * (ss[1] - ss[0])
print()
print("fraction of neighbour spacings below s")
print("   s    zeros   no stiffness (random)   unitary repulsion (s^2)")
for x in [0.1, 0.25, 0.5, 0.75]:
    print(f"{x:5.2f} {np.mean(s < x):8.4f} {1 - np.exp(-x):14.4f} {cdf[np.searchsorted(ss, x)]:22.4f}")

# 2. stiffness over long range: variance of the number of zeros in a window of length L
print()
print("variance of the count of zeros in a window of L mean spacings")
print("    L     zeros   no stiffness   unitary (log growth)")
for L in [0.5, 1, 2, 4, 8, 16, 32, 64]:
    starts = np.arange(w[0], w[-1] - L, 0.1)
    cnt = np.searchsorted(w, starts + L) - np.searchsorted(w, starts)
    gue = (np.log(2 * np.pi * L) + 0.5772156649 + 1) / np.pi ** 2
    print(f"{L:6.1f} {cnt.var():8.4f} {L:10.1f} {gue:16.4f}")
