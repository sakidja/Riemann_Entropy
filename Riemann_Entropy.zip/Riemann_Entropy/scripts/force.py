import numpy as np

g0 = np.load("gammas.npy")
N = len(g0)
LO, HI, NX = 6.0, 12.0, 24000
t = np.linspace(LO, HI, NX)          # t = log x
x = np.exp(t)

# true primes: psi(x) = sum of log p over prime powers p^k <= x
M = int(x[-1]) + 1
sieve = np.ones(M + 1, bool)
sieve[:2] = False
for i in range(2, int(M ** 0.5) + 1):
    if sieve[i]:
        sieve[i * i::i] = False
lam = np.zeros(M + 1)
for p in np.nonzero(sieve)[0]:
    q = p
    while q <= M:
        lam[q] = np.log(p)
        q *= p
psi_true = np.cumsum(lam)[np.floor(x).astype(int)]
base = x - np.log(2 * np.pi) - 0.5 * np.log(1 - x ** -2.0)


def rotor(gam):
    rho = 0.5 + 1j * gam
    return 2.0 * np.real(np.exp(1j * np.outer(gam, t)) / rho[:, None])   # scaled by sqrt(x)


full = np.zeros(NX)
for i in range(0, N, 200):          # chunked to keep memory small
    full += rotor(g0[i:i + 200]).sum(axis=0)


def mse(idx, newg):
    """mean square error of the prime count (scaled by sqrt x) after moving zeros idx to newg"""
    f = full - rotor(g0[idx]).sum(axis=0) + rotor(np.asarray(newg)).sum(axis=0)
    err = (base - np.sqrt(x) * f - psi_true) / np.sqrt(x)
    return np.mean(err ** 2)


E0 = mse([0], [g0[0]])
print(f"{N} zeros, window log x in [{LO},{HI}]")
print(f"error of the prime count with every zero in place: {E0:.6f}")

# 1. one zero moved by a: is the true position the minimum, and how stiff is the well?
k = 9
print()
print(f"zero number {k + 1} (gamma = {g0[k]:.4f}) moved by a; added error = mse(a) - mse(0)")
print("      a     added error    harmonic prediction")
t2 = np.mean(t ** 2)
for a in [-0.2, -0.1, -0.05, -0.02, 0.0, 0.02, 0.05, 0.1, 0.2]:
    pred = (2.0 / (0.25 + g0[k] ** 2)) * (a ** 2) * t2
    print(f"{a:8.3f} {mse([k], [g0[k] + a]) - E0:12.6f} {pred:14.6f}")

# 2. a neighbouring pair: pushed together, pulled apart, or shifted the same way
sep = g0[k + 1] - g0[k]
print()
print(f"pair {k + 1},{k + 2}: separation {sep:.4f}. Each zero moved by the same distance in three ways.")
print("fraction of sep   together      apart     same way")
for fr in [0.05, 0.1, 0.2, 0.3, 0.4, 0.5]:
    a = fr * sep
    tog = mse([k, k + 1], [g0[k] + a, g0[k + 1] - a]) - E0
    apa = mse([k, k + 1], [g0[k] - a, g0[k + 1] + a]) - E0
    sam = mse([k, k + 1], [g0[k] + a, g0[k + 1] + a]) - E0
    print(f"{fr:10.2f} {tog:14.6f} {apa:10.6f} {sam:10.6f}")
