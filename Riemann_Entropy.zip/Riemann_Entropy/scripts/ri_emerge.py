"""The zeros from the primes alone, with their position in the strip free (version two).

Nothing about the zeros is put in. The input is the primes, through Lambda(n), by sieve to X. The count psi(x) is
smoothed with a Gaussian of width h in t = log x,

   S(t) = integral of psi(e^u) g(u - t) du = sum over n of Lambda(n) Phi((t - log n) / h),

with g the Gaussian density and Phi its cumulative, and the explicit formula turns this into a sum over the zeros
rho = 1/2 + delta + i gamma, exactly:

   F(t) = (S(t) - e^(t + h^2/2) + log 2 pi) e^(-t/2) = - sum over rho of  e^(rho^2 h^2 / 2)  e^((delta + i gamma) t) / rho   (+ trivial zeros).

This is the state of the paper, |psi> = sum (1/rho_n)|n> under M(t), with each mode's weight multiplied by the known
factor e^(rho^2 h^2/2), which is e^(-gamma^2 h^2/2) in size; a mode's growth rate delta and frequency gamma are untouched, and the modes above gamma ~ 7/h are
suppressed below numerical precision, so the signal is band limited without any filter on the samples. The modes
are then extracted from F(t) by the matrix pencil method (Hua and Sarkar, IEEE Trans. Acoust. Speech Signal
Process. 38, 814 (1990)): the sampled signal is written as a Hankel matrix, its dominant right singular vectors
are kept, and the generalized eigenvalues of the shifted pair give the poles z_n = e^((delta_n + i gamma_n) dt),

   gamma_n = arg(z_n) / dt,      delta_n = log|z_n| / dt.

So delta_n is an output. A mode on the line gives |z_n| = 1. The method places no mode on the line and none off it;
the primes decide. (In the Fourier picture of Mazur and Stein the frequencies gamma_n appear as peaks of a prime
sum; that recovers gamma only. Here the growth rate delta is recovered as well.)

Three runs with the same estimator, and one calibration:
   zeta        the primes, from the sieve to X.                   Output: (gamma_n, delta_n) for the modes below GMAX.
   components  Lambda(n) chi(n) for the two quartic characters mod 5 (each L function has an Euler product).
   DH          the Davenport and Heilbronn function, through the coefficients b_n of -f'/f obtained by Dirichlet
               inversion of its series (no product over primes). The same estimator should then return modes
               with |z| != 1 where that function has zeros off the line.
   floor       the estimator applied to a signal synthesized from Odlyzko's zeros with every delta = 0, over the
               same window and sampling. The spread of the recovered delta there is the resolution floor of the
               method: a recovered |delta| below it is zero within the method. The zeros enter here only to
               measure the estimator; they are not used in the three runs above.

The recovered gamma_n are compared with Odlyzko's table after the fact, as a check, and the DH modes with the
zeros found by ri_dh.py (ri_dh_results.json), also after the fact.

Reads    zeros1 (Odlyzko; for the check and the floor), ri_dh_results.json (for the DH check; optional)
Writes   ri_emerge_results.json and, in figures/, two figures, each a repeat of a figure of version one drawn with
         the same code and the same data, with the returned modes added on top:
         fig_v1b_fig7       Figure 7 of version one (the Davenport and Heilbronn zeros to height 2,000), the returned modes as crosses
         fig_v1b_fig8       Figure 8 of version one (the entropy by window), the entropy over the returned modes dashed
         (ri_mirror.py then draws the mirror test on the returned modes of both functions from ri_emerge_results.json)

Usage:   python ri_emerge.py [X] [NDH] [GMAX] [GWIDE]
         X     sieve limit for the primes          (default 1e9; the window is then t = log x up to 20.7)
         NDH   length of the DH coefficient sum    (default 1e8; the window is then t up to 18.3, which resolves the bands to 2,000)
         GMAX  highest gamma of the single window   (default 200; the smoothing width is h = 2 / GMAX; 500 is tested and used for the paper)
         GWIDE height to which the strip is covered in bands (default 2000), for the counterpart of Figure 7
Memory: the sieve to 1e9 and the series to 1e8 take about 3 GB. Runtime on one Perlmutter CPU node with GMAX 500 and the bands every 100: about 1.5 hours.
"""
import json
import os
import sys
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE = os.path.dirname(os.path.abspath(__file__))
FLAT = os.path.exists(os.path.join(HERE, "ri_dh_results.json"))      # on Perlmutter the scripts and the results share one folder
R = HERE if FLAT else os.path.join(HERE, "..", "results")
F = os.path.join(HERE, "figures") if FLAT else os.path.join(HERE, "..", "figures")
os.makedirs(F, exist_ok=True)

X = int(float(sys.argv[1])) if len(sys.argv) > 1 else 10**9
NDH = int(float(sys.argv[2])) if len(sys.argv) > 2 else 10**8
GMAX = float(sys.argv[3]) if len(sys.argv) > 3 else 200.0
H = 2.0 / GMAX                              # smoothing width: a mode at GMAX keeps e^(-2) of its weight
DT = np.pi / (4.0 * GMAX)                   # Nyquist at 4 GMAX; modes above 7/h = 3.5 GMAX are below 1e-11 in weight
T0 = 2.0                                    # window start
SV_CUT = 1e-8                               # singular values kept, relative to the largest (the prime side is exact to ~1e-9 at x = 1e9)
DELTA_SIG = 1e-6                            # a recovered |delta| above this is reported as off the line; the floor of the method is ~1e-12
KAP = (np.sqrt(10 - 2 * np.sqrt(5)) - 2) / (np.sqrt(5) - 1)
A_DH = np.array([0.0, 1.0, KAP, -KAP, -1.0])        # coefficients of the DH series by n mod 5 (index = n mod 5)
CHI = np.array([0, 1, 1j, -1j, -1])                 # the quartic character mod 5, chi(2) = i


# ---------------------------------------------------------------- the primes
def sieve(n):
    s = np.ones(n + 1, dtype=bool)
    s[:2] = False
    for p in range(2, int(n ** 0.5) + 1):
        if s[p]:
            s[p * p::p] = False
    return np.nonzero(s)[0]


def prime_powers(primes, n):
    """every p^k <= n with k >= 2, and its log p."""
    vals, ws = [], []
    for p in primes[primes <= int(n ** 0.5)]:
        q = p * p
        while q <= n:
            vals.append(q)
            ws.append(np.log(p))
            q *= p
    return np.array(vals, dtype=np.int64), np.array(ws)


# ---------------------------------------------------------------- the smoothed sum, exact
def smoothed_sum(logn, w, t, H=H, DT=DT):
    """S(t_k) = sum_n w_n Phi((t_k - log n) / H) on the grid t (uniform step DT), Phi the Gaussian cumulative.
    Points more than 7 H below t_k count in full (a sorted cumulative sum); points within 7 H count with Phi,
    each reaching only the few samples near it; points above do not count. Exact to e^(-24.5)."""
    try:
        from scipy.special import erf
    except ImportError:                                    # slow fallback
        from math import erf as _erf
        erf = np.vectorize(_erf)
    o = np.argsort(logn)
    logn, w = logn[o], w[o]
    cum = np.concatenate([[0], np.cumsum(w)])
    S = cum[np.searchsorted(logn, t - 7 * H, side="right")].astype(w.dtype)     # the points fully below each t_k
    reach = int(np.ceil(7 * H / DT))
    i0 = np.round((logn - t[0]) / DT).astype(np.int64)
    Phi = lambda u: 0.5 * (1.0 + erf(u / np.sqrt(2.0)))
    for k in range(-reach, reach + 1):
        i = i0 + k
        ok = (i >= 0) & (i < len(t))
        u = (t[i[ok]] - logn[ok]) / H
        gk = np.where(u >= 7, 0.0, Phi(np.clip(u, -7.5, 7)))                     # points with u >= 7 are already in cum
        if np.iscomplexobj(w):
            S += np.bincount(i[ok], weights=(w[ok] * gk).real, minlength=len(t)) + \
                 1j * np.bincount(i[ok], weights=(w[ok] * gk).imag, minlength=len(t))
        else:
            S += np.bincount(i[ok], weights=w[ok] * gk, minlength=len(t))
    return S


def grid(tmax, H=H, DT=DT):
    """t from T0 to tmax - 7H (where the sum over n <= X is complete), step DT."""
    n = int(np.floor((tmax - 7 * H - T0) / DT)) + 1
    return T0 + DT * np.arange(n)


# ---------------------------------------------------------------- the Davenport and Heilbronn coefficients
def dh_log_derivative_coefficients(n):
    """b_k, k <= n, the Dirichlet coefficients of -f'/f for f(s) = sum a_k k^(-s), a_k = A_DH[k mod 5]:
    1/f by Dirichlet inversion (a_1 = 1), then -f'/f = (-f') * (1/f), with -f' having the coefficients a_k log k."""
    k = np.arange(n + 1)
    a = A_DH[k % 5]
    c = np.zeros(n + 1)
    c[1] = 1.0
    for m in range(1, n // 2 + 1):
        if c[m] != 0.0:
            c[2 * m::m] -= a[2:n // m + 1] * c[m]
    u = a * np.log(np.maximum(k, 1))
    b = np.zeros(n + 1)
    for d in range(1, n + 1):
        if u[d] != 0.0:
            b[d::d] += u[d] * c[1:n // d + 1]
    return b


# ---------------------------------------------------------------- the matrix pencil
def matrix_pencil(f, dt, sv_cut=None, dmax=1.5):
    """Poles z_n and amplitudes a_n of f_k = sum_n a_n z_n^k. The number of poles is set by the singular values;
    a pole with |log|z|| / dt > dmax (a growth rate beyond anything in the strip) is discarded before the amplitude fit."""
    N = len(f)
    L = N // 2
    Y = np.lib.stride_tricks.sliding_window_view(f, L + 1)[: N - L]
    _, s, Vh = np.linalg.svd(Y, full_matrices=False)
    M = int(np.sum(s > (SV_CUT if sv_cut is None else sv_cut) * s[0]))
    V = Vh[:M].T                                    # rows of Vh span the row space [z^j]; no conjugate, or the poles come out conjugated
    z = np.linalg.eigvals(np.linalg.pinv(V[:-1]) @ V[1:])
    z = z[np.abs(np.log(np.abs(z))) / dt <= dmax]
    Z = z[None, :] ** np.arange(N)[:, None]
    amp = np.linalg.lstsq(Z, f, rcond=None)[0]
    resid = np.linalg.norm(f - Z @ amp) / np.linalg.norm(f)
    return z, amp, M, resid


def modes(z, amp, dt, t0, gmin, gmax, H=H):
    """(gamma, delta, |weight at t = 0|) of the poles with gmin < gamma < gmax, sorted by gamma.
    The known smoothing factor e^(rho^2 h^2 / 2) is divided out of the weight, so |a| should be 1/|rho|."""
    gam = np.angle(z) / dt
    dl = np.log(np.abs(z)) / dt
    rho = 0.5 + dl + 1j * gam
    with np.errstate(over="ignore", invalid="ignore"):
        a = amp * np.exp(-(dl + 1j * gam) * t0) / np.exp(rho ** 2 * H ** 2 / 2)
    a = np.where(np.isfinite(a), a, 0.0)
    keep = (gam > gmin) & (gam < gmax) & (np.abs(a) > 1e-4 * np.abs(a).max())     # a pole with no weight is not a mode
    o = np.argsort(gam[keep])
    return gam[keep][o], dl[keep][o], np.abs(a[keep][o])


def run(f, t, label):
    z, amp, M, resid = matrix_pencil(f, DT)
    print(f"  {label}: {len(f)} samples, t = {t[0]:.2f} to {t[-1]:.2f}, {M} poles kept, fit residual {resid:.1e}")
    return z, amp


def entropy_curve(dl, a, ts):
    out = []
    for t in ts:
        w = a ** 2 * np.exp(2 * dl * t)
        p = w / w.sum()
        out.append(float(-(p * np.log(p)).sum()))
    return np.array(out)


def load_table(name):
    vals = []
    with open(name) as fh:
        for line in fh:
            try:
                vals.append(float(line.strip()))
            except ValueError:
                pass
    return np.array(vals)


def nearest(ref, g):
    i = np.clip(np.searchsorted(ref, g), 1, len(ref) - 1)
    lo, hi = ref[i - 1], ref[i]
    return np.where(np.abs(g - lo) < np.abs(g - hi), lo, hi)


OUT = {"X": X, "NDH": NDH, "GMAX": GMAX, "h": H, "dt": DT, "T0": T0}
print(f"X = {X:.3g}, GMAX = {GMAX}, h = {H:.4f}, dt = {DT:.5f}")

# ================================================================ 1. zeta: the primes, nothing else
primes = sieve(X)
pp_val, pp_w = prime_powers(primes, X)
logn = np.concatenate([np.log(primes.astype(float)), np.log(pp_val.astype(float))])
lam = np.concatenate([np.log(primes.astype(float)), pp_w])
print(f"sieve: {len(primes)} primes, {len(pp_val)} prime powers")
t = grid(np.log(X))
S = smoothed_sum(logn, lam, t)
F_zeta = (S - np.exp(t + H ** 2 / 2) + np.log(2 * np.pi)) * np.exp(-t / 2)
z, amp = run(F_zeta, t, "zeta")
gam_z, dl_z, a_z = modes(z, amp, DT, t[0], 1.0, GMAX)

# ================================================================ 2. the floor: the same estimator with every delta = 0
zeros1 = os.path.join(HERE, "zeros1")
have_zeros = os.path.exists(zeros1)
if have_zeros:
    g_ref = load_table(zeros1)
    rho = 0.5 + 1j * g_ref
    F_syn = np.zeros_like(t)
    for k0 in range(0, len(g_ref), 2000):
        blk = rho[k0:k0 + 2000]
        wgt = np.exp(blk ** 2 * H ** 2 / 2) / blk
        F_syn -= 2 * np.real(np.exp(1j * np.outer(t, blk.imag)) * wgt).sum(axis=1)
    z, amp = run(F_syn, t, "floor (synthetic from the table, all delta = 0)")
    gam_f, dl_f, a_f = modes(z, amp, DT, t[0], 1.0, GMAX)
    floor = float(np.sqrt(np.mean(dl_f ** 2)))
    floor_max = float(np.max(np.abs(dl_f)))
    print(f"  floor: {len(dl_f)} modes, rms of recovered delta {floor:.2e}, largest |delta| {floor_max:.2e}, "
          f"rms gamma error {np.sqrt(np.mean((gam_f - nearest(g_ref, gam_f)) ** 2)):.2e}")
else:
    g_ref = None
    floor = floor_max = float("nan")
    print("  zeros1 not found: no floor and no check against the table")

n_exp = (GMAX / (2 * np.pi)) * np.log(GMAX / (2 * np.pi * np.e)) + 7 / 8
print(f"\nzeta: {len(gam_z)} modes below gamma = {GMAX} (the count of zeros there is about {n_exp:.0f})")
print("   gamma (recovered)   delta (recovered)   |a| (1/|rho| expected)   table gamma    difference")
rows = []
for gm, dl, a in zip(gam_z, dl_z, a_z):
    ng = float(nearest(g_ref, gm)) if have_zeros else float("nan")
    rows.append([float(gm), float(dl), float(a), ng, float(gm - ng)])
    print(f"   {gm:12.6f}      {dl:+12.2e}     {a:8.5f} ({1 / abs(0.5 + 1j * gm):8.5f})   {ng:12.6f}   {gm - ng:+10.2e}")
rms_z = float(np.sqrt(np.mean(dl_z ** 2)))
print(f"   rms delta {rms_z:.2e}, largest |delta| {np.max(np.abs(dl_z)):.2e}; floor rms {floor:.2e}, floor max {floor_max:.2e}")
print(f"   modes with |delta| above {DELTA_SIG:.0e} (the floor of the method is {floor_max:.1e}): {int(np.sum(np.abs(dl_z) > DELTA_SIG))}")
if have_zeros:
    print(f"   gamma: rms difference from the table {np.sqrt(np.mean((gam_z - nearest(g_ref, gam_z)) ** 2)):.2e}")
ts = np.linspace(T0, 100, 50)
H_z = entropy_curve(dl_z, a_z, ts)
print(f"   entropy over the recovered modes with their recovered growth rates: {H_z[0]:.5f} at t = {ts[0]:.0f}, "
      f"{H_z[-1]:.5f} at t = {ts[-1]:.0f}")
OUT["zeta"] = {"modes": rows, "rms_delta": rms_z, "floor_rms": floor, "floor_max": floor_max,
               "t": ts.tolist(), "entropy": H_z.tolist()}

# ================================================================ 3. the two components mod 5 (each with an Euler product)
OUT["components"] = {}
nn = np.concatenate([primes, pp_val])
for name, chi in (("chi", CHI), ("chibar", CHI.conj())):
    Sc = smoothed_sum(logn, lam * chi[nn % 5], t)
    Fc = Sc * np.exp(-t / 2)                                   # no main term: L(s, chi) is entire
    z, amp = run(Fc, t, f"component {name}")
    gam_c, dl_c, a_c = modes(z, amp, DT, t[0], -GMAX, GMAX)
    k = np.abs(gam_c) > 1.0
    gam_c, dl_c, a_c = gam_c[k], dl_c[k], a_c[k]
    print(f"\ncomponent {name}: {len(gam_c)} modes with |gamma| < {GMAX}; rms delta {np.sqrt(np.mean(dl_c ** 2)):.2e}, "
          f"largest |delta| {np.max(np.abs(dl_c)):.2e}")
    OUT["components"][name] = {"gamma": gam_c.tolist(), "delta": dl_c.tolist(), "amp": a_c.tolist(),
                               "rms_delta": float(np.sqrt(np.mean(dl_c ** 2)))}

# ================================================================ 4. Davenport and Heilbronn: the series, no product
print(f"\nDavenport and Heilbronn: coefficients of -f'/f to n = {NDH:.3g} by Dirichlet inversion")
b = dh_log_derivative_coefficients(NDH)
t_dh = grid(np.log(NDH))
nz = np.nonzero(b[1:])[0] + 1
F_dh = smoothed_sum(np.log(nz.astype(float)), b[nz], t_dh) * np.exp(-t_dh / 2)      # no main term: f is entire
z, amp = run(F_dh, t_dh, "DH")
gam_d, dl_d, a_d = modes(z, amp, DT, t_dh[0], 1.0, GMAX)
ref_dh = os.path.join(R, "ri_dh_results.json")
have_dh = os.path.exists(ref_dh)
if have_dh:
    D = json.load(open(ref_dh))["zeros"]
    on = np.array(sorted(D["on_line"]))
    off = sorted(zip(D["off_gamma"], D["off_sigma"]))
    off_g = np.array([g for g, _ in off])
    off_d = np.array([s - 0.5 for _, s in off])
    allg = np.concatenate([on, off_g])
    alld = np.concatenate([np.zeros_like(on), off_d])
print(f"  {len(gam_d)} modes below gamma = {GMAX}")
print("   gamma (recovered)   delta (recovered)   |a|       ri_dh.py: nearest zero, its delta")
rows = []
for gm, dl, a in zip(gam_d, dl_d, a_d):
    if have_dh:
        j = int(np.argmin(np.abs(allg - gm)))
        ref = f"{allg[j]:12.6f}   {alld[j]:+9.5f}"
        rows.append([float(gm), float(dl), float(a), float(allg[j]), float(alld[j])])
    else:
        ref = "n/a"
        rows.append([float(gm), float(dl), float(a), float("nan"), float("nan")])
    print(f"   {gm:12.6f}      {dl:+12.5f}     {a:8.5f}   {ref}")
if have_dh:
    sel = off_g < GMAX
    print(f"   zeros off the line below {GMAX} found by ri_dh.py: " +
          ", ".join(f"({g:.4f}, delta = {d:+.4f})" for g, d in zip(off_g[sel], off_d[sel])))
print(f"   modes with |delta| above {DELTA_SIG:.0e}: {int(np.sum(np.abs(dl_d) > DELTA_SIG))}")
ts_dh = np.linspace(T0, 100, 50)
H_d = entropy_curve(dl_d, a_d, ts_dh)
print(f"   entropy over the recovered modes with their recovered growth rates: {H_d[0]:.5f} at t = {ts_dh[0]:.0f}, "
      f"{H_d[-1]:.5f} at t = {ts_dh[-1]:.0f}")
OUT["DH"] = {"modes": rows, "t": ts_dh.tolist(), "entropy": H_d.tolist()}

# ================================================================ 5. one state on the line, two off it: the count of poles at each gamma
def pole_groups(gam, dl, a, tol=1e-3):
    """group the returned modes by gamma: the count of poles in a group is the count of states at that height."""
    groups = []
    for g, d, w in zip(gam, dl, a):
        if groups and abs(g - groups[-1][0][-1]) < tol:
            groups[-1][0].append(g); groups[-1][1].append(d); groups[-1][2].append(w)
        else:
            groups.append([[g], [d], [w]])
    return groups

print("\nstates at each height (poles returned at the same gamma): zeta")
gz = pole_groups(gam_z, dl_z, a_z)
print(f"   {len(gz)} heights, poles per height: {sorted(set(len(g[0]) for g in gz))}")
gd = pole_groups(gam_d, dl_d, a_d)
print("states at each height: Davenport and Heilbronn")
print(f"   {len(gd)} heights; one pole at {sum(1 for g in gd if len(g[0]) == 1)} of them, two poles at {sum(1 for g in gd if len(g[0]) == 2)}")
print("   gamma           poles   delta of each pole            |a| of each pole")
doublets = []
for g in gd:
    if len(g[0]) > 1:
        print(f"   {np.mean(g[0]):12.6f}   {len(g[0])}      " + ", ".join(f"{d:+.5f}" for d in g[1]) + "        " + ", ".join(f"{w:.5f}" for w in g[2]))
        doublets.append([float(np.mean(g[0])), [float(d) for d in g[1]], [float(w) for w in g[2]]])
OUT["states"] = {"zeta_poles_per_height": [len(g[0]) for g in gz], "dh_poles_per_height": [len(g[0]) for g in gd], "dh_doublets": doublets}

# ================================================================ 6. the entropy, given the zeros and given the primes only, on the same modes
def entropy_given(gams, dls, ts):
    """the entropy of Section 8 computed from a list of zeros (gamma, delta) with weights 1/|rho|^2 e^(2 delta t)"""
    w0 = 1.0 / np.abs(0.5 + dls + 1j * gams) ** 2
    out = []
    for t in ts:
        w = w0 * np.exp(2 * dls * t); p = w / w.sum(); out.append(float(-(p * np.log(p)).sum()))
    return np.array(out)

OUT["entropy_overlay"] = {}
if have_zeros:
    gz_in = g_ref[(g_ref > 1.0) & (g_ref < GMAX)]
    H_z_given = entropy_given(gz_in, np.zeros_like(gz_in), ts)
    print(f"\nentropy over the modes below {GMAX}, zeta: given the zeros (table, delta = 0) against returned from the primes only")
    print(f"   given: {H_z_given[0]:.5f} at t = {ts[0]:.0f}, {H_z_given[-1]:.5f} at t = {ts[-1]:.0f};  returned: {H_z[0]:.5f}, {H_z[-1]:.5f};  "
          f"largest difference {np.max(np.abs(H_z_given - H_z)):.1e}")
    OUT["entropy_overlay"]["zeta"] = {"t": ts.tolist(), "given": H_z_given.tolist(), "returned": H_z.tolist()}
if have_dh:
    sel_on = (on > 1.0) & (on < GMAX); sel_off = off_g < GMAX
    gd_in = np.concatenate([on[sel_on], off_g[sel_off], off_g[sel_off]])
    dd_in = np.concatenate([np.zeros(sel_on.sum()), off_d[sel_off], -off_d[sel_off]])     # the mirror partner by the functional equation
    H_d_given = entropy_given(gd_in, dd_in, ts_dh)
    print(f"entropy over the modes below {GMAX}, Davenport and Heilbronn: given the zeros of Section 8 (with their mirrors) against returned from the series only")
    print(f"   given: {H_d_given[0]:.5f} at t = {ts_dh[0]:.0f}, {H_d_given[-1]:.5f} at t = {ts_dh[-1]:.0f};  returned: {H_d[0]:.5f}, {H_d[-1]:.5f};  "
          f"largest difference {np.max(np.abs(H_d_given - H_d)):.1e}")
    OUT["entropy_overlay"]["DH"] = {"t": ts_dh.tolist(), "given": H_d_given.tolist(), "returned": H_d.tolist()}

# ================================================================ 7. the strip to height GWIDE, in bands: the counterpart of Figure 7
# The matrix pencil cannot hold the thousands of modes below height 2,000 at once, so the whole strip is taken in bands,
# from the first zero up; every mode in Figures 14 to 17 comes from a band centred on it. The single window of sections 1 to 6
# (below GMAX, with the weights 1/rho) serves Table 21, the floor run, the doublet table and the entropy below GMAX.
# For a band centred at gamma_c the prime measure is smoothed with a Gabor kernel, g(u) e^(-i gamma_c u), which by the
# explicit formula multiplies the weight of each mode by e^((rho - i gamma_c)^2 h^2 / 2): the modes within about 7/h of
# gamma_c are kept (here h = 0.02, so about 350 either side), the others are suppressed below precision, and delta and gamma are untouched. The band is then
# demodulated by e^(-i gamma_c t) and the pencil returns the poles (delta + i (gamma - gamma_c)). These bands use the
# density kernel, so the mode weights are e^((rho - i gamma_c)^2 h^2/2) without the factor 1/rho; only gamma, delta
# and the count of poles at each height are read from them.
GWIDE = float(sys.argv[4]) if len(sys.argv) > 4 else 2000.0
HWB = 200.0                                           # half width of a band as reported
SV_CUT_B = 1e-6                                       # the coefficient sums of the high bands are exact to about 1e-7
H_B, DT_B = 4.0 / HWB, np.pi / (4.0 * HWB)            # kernel width and step: the band passes |gamma - gamma_c| < 7/h = 350, the Nyquist is 800
GWIDE_Z = 2600.0                                       # zeta bands reach the 2,029th zero (height 2,515), the set used in Figure 8 of version one
STEP = HWB / 2                                        # band centres every 100
KEEP = STEP / 2                                       # modes kept from a band: |gamma - gamma_c| <= 50, where the kernel weight is at least e^(-1/2)
centres = np.arange(KEEP, max(GWIDE, GWIDE_Z), STEP)                  # bands every 100 from centre 50, each keeping its middle 100: the strip is covered once, every mode near the centre of its fit


def gabor_sum(logn, w, t, gc, H, DT):
    """sum_n w_n g(log n - t) e^(-i gc (log n - t)), the Gaussian density of width H, cut at 7 H, demodulated by e^(-i gc t)"""
    reach = int(np.ceil(7 * H / DT))
    i0 = np.round((logn - t[0]) / DT).astype(np.int64)
    S = np.zeros(len(t), dtype=complex)
    norm = 1.0 / (H * np.sqrt(2 * np.pi))
    for k in range(-reach, reach + 1):
        i = i0 + k
        ok = (i >= 0) & (i < len(t))
        u = t[i[ok]] - logn[ok]
        gk = norm * np.exp(-0.5 * (u / H) ** 2) * np.exp(1j * gc * u) * w[ok]
        S += np.bincount(i[ok], weights=gk.real, minlength=len(t)) + 1j * np.bincount(i[ok], weights=gk.imag, minlength=len(t))
    return S * np.exp(-1j * gc * t)


def band_modes(F, t, gc, sv_cut=None, gmax_b=None):
    gmax_b = GWIDE if gmax_b is None else gmax_b
    z, amp, M, resid = matrix_pencil(F, DT_B, sv_cut=sv_cut)
    gam = np.angle(z) / DT_B + gc
    dl = np.log(np.abs(z)) / DT_B
    keep = (np.abs(gam - gc) <= KEEP) & (gam > 0) & (gam < gmax_b) & (np.abs(amp) > 1e-4 * np.abs(amp).max())
    o = np.argsort(gam[keep])
    return gam[keep][o], dl[keep][o], M, resid


t_b = grid(np.log(X), H_B, DT_B)
t_bd = grid(np.log(NDH), H_B, DT_B)
print(f"\nthe strip to {GWIDE:.0f} in bands (kernel width h = {H_B:.3f}, each band keeps |gamma - centre| <= {KEEP:.0f}): zeta from the primes, DH from the series")
print("   centre   zeta: modes   largest |delta|   |  DH: modes   doublets   largest |delta| on the single poles")
wide_z, wide_d = [], []
for gc in centres:
    Sb = gabor_sum(logn, lam, t_b, gc, H_B, DT_B) if gc - KEEP < GWIDE_Z else None
    if Sb is None:
        gz_b, dz_b = np.array([]), np.array([])
    else:
        pass
    if Sb is not None:
        Fb = (Sb - np.exp((1 - 1j * gc) * t_b + (1 - 1j * gc) ** 2 * H_B ** 2 / 2)) * np.exp(-t_b / 2)   # the main term e^t under the same kernel, demodulated
        gz_b, dz_b, Mz, rz = band_modes(Fb, t_b, gc, gmax_b=GWIDE_Z)                  # the prime side: the default cut, 1e-8
    if gc - KEEP < GWIDE:
        Sd = gabor_sum(np.log(nz.astype(float)), b[nz].astype(complex), t_bd, gc, H_B, DT_B)
        Fd = Sd * np.exp(-t_bd / 2)
        gd_b, dd_b, Md, rd = band_modes(Fd, t_bd, gc, sv_cut=SV_CUT_B)
    else:
        gd_b, dd_b = np.array([]), np.array([])
    grp = pole_groups(gd_b, dd_b, np.ones_like(gd_b), tol=1e-2)
    n2 = sum(1 for g in grp if len(g[0]) > 1)
    single = np.array([g[1][0] for g in grp if len(g[0]) == 1] or [0.0])
    print(f"   {gc:6.0f}      {len(gz_b):5d}       {np.max(np.abs(dz_b)) if len(dz_b) else float('nan'):10.1e}     |    {len(gd_b):5d}       {n2:4d}        {np.max(np.abs(single)):10.1e}")
    wide_z += list(zip(gz_b.tolist(), dz_b.tolist()))
    wide_d += list(zip(gd_b.tolist(), dd_b.tolist()))
wide_z.sort(); wide_d.sort()
gz_w = np.array([g for g, _ in wide_z]); dz_w = np.array([d for _, d in wide_z])
gd_w = np.array([g for g, _ in wide_d]); dd_w = np.array([d for _, d in wide_d])
n_exp_w = (GWIDE_Z / (2 * np.pi)) * np.log(GWIDE_Z / (2 * np.pi * np.e)) + 7 / 8
print(f"   zeta: {len(gz_w)} modes below {GWIDE_Z:.0f} (the count of zeros there is about {n_exp_w:.0f}); largest |delta| {np.max(np.abs(dz_w)):.1e}; "
      f"modes with |delta| > {DELTA_SIG:.0e}: {int(np.sum(np.abs(dz_w) > DELTA_SIG))}")
if have_zeros:
    gz_in = g_ref[g_ref < GWIDE_Z]
    print(f"   zeta: rms difference of gamma from the table {np.sqrt(np.mean((gz_w - nearest(g_ref, gz_w)) ** 2)):.1e}; table has {len(gz_in)} zeros there")
grp_w = pole_groups(gd_w, dd_w, np.ones_like(gd_w), tol=1e-2)
dbl_w = [g for g in grp_w if len(g[0]) > 1]
dbl_all = dbl_w                                                           # the bands cover the whole strip
n1_all = sum(1 for g in grp_w if len(g[0]) == 1)
print(f"   DH: {len(gd_w)} modes below {GWIDE:.0f}: {n1_all} heights with one pole, {len(dbl_all)} with two")
if have_dh:
    sel_w = off_g < GWIDE
    matched = 0
    for g in dbl_all:
        j = int(np.argmin(np.abs(off_g - g[0][0])))
        if abs(off_g[j] - g[0][0]) < 1e-2 and abs(max(g[1]) - off_d[j]) < 1e-2:
            matched += 1
    print(f"   DH: ri_dh.py found {int(sel_w.sum())} pairs off the line below {GWIDE:.0f}; {len(dbl_all)} doublets returned, "
          f"{matched} of them at one of those pairs in gamma and delta to 1e-2")
OUT["wide"] = {"GWIDE": GWIDE, "band_halfwidth": HWB, "h": H_B, "zeta": {"gamma": gz_w.tolist(), "delta": dz_w.tolist()},
               "DH": {"gamma": gd_w.tolist(), "delta": dd_w.tolist(), "doublets": [[float(np.mean(g[0])), [float(d) for d in g[1]]] for g in dbl_w]}}

# ================================================================ 8. the figures of version one, repeated with the symmetry lifted
# Figure 7 of version one (make_figures.py, fig3_dh_zeros) and Figure 8 (fig4_entropy), drawn with the same code and the
# same data, with the returned modes added on top: crosses for the modes, dashed for the entropy. The entropy by window is
# computed exactly as in ri_figdata.py (window_shares), from the first 2,029 returned modes of zeta and from every returned
# mode of the Davenport and Heilbronn function, with the weight 1/|rho|^2 of the returned rho.
def window_shares(rho, lo, hi):
    a = 1.0 / np.abs(rho) ** 2
    e = 2 * (rho.real - 0.5)
    small = np.abs(e) < 1e-12
    g = np.where(small, 1.0, (np.exp(e * hi) - np.exp(e * lo)) / np.where(small, 1.0, e * (hi - lo)))
    p = a * g
    return p / p.sum()


def H_of(p):
    q = p[p > 0]
    return float(-np.sum(q * np.log(q)))


gz_full = gz_w.copy(); dz_full = dz_w.copy()                              # every mode in the figures comes from a band centred on it
o = np.argsort(gz_full); gz_full, dz_full = gz_full[o], dz_full[o]
gd_full = gd_w.copy(); dd_full = dd_w.copy()
o = np.argsort(gd_full); gd_full, dd_full = gd_full[o], dd_full[o]
rho_z_ret = 0.5 + dz_full[:2029] + 1j * gz_full[:2029]
rho_d_ret = 0.5 + dd_full + 1j * gd_full
fig8 = os.path.join(R, "ri_figdata_results.json")
have_fig8 = os.path.exists(fig8)
if have_fig8:
    EW = np.array(json.load(open(fig8))["entropy_by_window"]["rows"])
    xe = 0.5 * (EW[:, 0] + EW[:, 1]); TMAX = float(EW[-1, 1])
    Hz_ret = np.array([H_of(window_shares(rho_z_ret, lo, hi)) for lo, hi in zip(EW[:, 0], EW[:, 1])])
    Hd_ret = np.array([H_of(window_shares(rho_d_ret, lo, hi)) for lo, hi in zip(EW[:, 0], EW[:, 1])])
    print(f"\nFigure 8 of version one repeated: zeta, given {EW[0, 10]:.4f} to {EW[-1, 10]:.4f}, returned {Hz_ret[0]:.4f} to {Hz_ret[-1]:.4f} "
          f"(largest difference {np.max(np.abs(Hz_ret - EW[:, 10])):.1e}); DH, given {EW[0, 4]:.4f}, {EW[:, 4].max():.4f}, {EW[-1, 4]:.4f}, "
          f"returned {Hd_ret[0]:.4f}, {Hd_ret.max():.4f}, {Hd_ret[-1]:.4f} (largest difference {np.max(np.abs(Hd_ret - EW[:, 4])):.1e})")
    OUT["figure8_repeat"] = {"lo": EW[:, 0].tolist(), "hi": EW[:, 1].tolist(), "zeta_given": EW[:, 10].tolist(), "zeta_returned": Hz_ret.tolist(),
                             "dh_given": EW[:, 4].tolist(), "dh_returned": Hd_ret.tolist()}
else:
    print("\nri_figdata_results.json not found: Figure 8 of version one is not repeated")

with open(os.path.join(R, "ri_emerge_results.json"), "w") as fh:
    json.dump(OUT, fh)
print("\nwrote ri_emerge_results.json")

# ---------------------------------------------------------------- figures
BLUE, ORANGE, INK, INK2, GRID, SURF = "#2a78d6", "#eb6834", "#0b0b0b", "#52514e", "#e4e3df", "#fcfcfb"
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9, "axes.edgecolor": INK2, "axes.labelcolor": INK,
                     "xtick.color": INK2, "ytick.color": INK2, "axes.spines.top": False, "axes.spines.right": False,
                     "axes.linewidth": 0.8, "figure.facecolor": SURF, "axes.facecolor": SURF, "savefig.facecolor": SURF,
                     "axes.titlesize": 10, "axes.titleweight": "bold", "axes.titlelocation": "left"})
# ---------------------------------------------------------------- the figures of version one, repeated
X_MARK = dict(ls="", marker="x", ms=3.2, mew=0.7, color=INK)
# Figure 7 of version one: the Davenport and Heilbronn zeros, with the returned modes as crosses
if have_dh:
    fig, ax = plt.subplots(figsize=(6.6, 3.0))
    ax.axhline(0.5, color=GRID, lw=0.8)
    ax.plot(on, np.full(len(on), 0.5), ls="", marker="|", ms=2.6, mew=0.35, color=BLUE)
    ax.plot(off_g, 0.5 + off_d, ls="", marker="o", ms=4.2, color=ORANGE, mec=SURF, mew=0.6)
    ax.plot(off_g, 0.5 - off_d, ls="", marker="o", ms=4.2, color=ORANGE, mec=SURF, mew=0.6)
    ax.plot(gd_full, 0.5 + dd_full, **X_MARK)
    ax.set_xlim(0, 2000); ax.set_ylim(0, 1); ax.set_yticks([0, 0.25, 0.5, 0.75, 1])
    ax.set_xlabel("height of the zero, Im s"); ax.set_ylabel("Re s")
    ax.text(2010, 0.5, f"{len(on):,} on the line", color=INK, va="center", fontsize=8)
    ax.text(2010, 0.86, f"{len(off_g)} pairs off the line", color=INK, va="center", fontsize=8)
    ax.text(2010, 0.14, f"crosses: {len(gd_full):,} modes returned\nfrom the series alone", color=INK, va="center", fontsize=8)
    ax.set_title("Davenport and Heilbronn function: one zero in twelve leaves the line")
    fig.savefig(os.path.join(F, "fig_v1b_fig7.png"), dpi=300, bbox_inches="tight"); fig.savefig(os.path.join(F, "fig_v1b_fig7.pdf"), bbox_inches="tight"); plt.close(fig)
# Figure 8 of version one: the entropy by window, given (solid) and returned (dashed)
if have_fig8:
    fig, ax = plt.subplots(figsize=(6.6, 3.4))
    ax.plot(xe, EW[:, 10], color=BLUE, lw=2)
    ax.plot(xe, EW[:, 4], color=ORANGE, lw=2)
    ax.plot(xe[::4], EW[::4, 10], ls="", marker="o", ms=4.5, color=BLUE, mec=SURF, mew=1)
    ax.plot(xe[::4], EW[::4, 4], ls="", marker="s", ms=4.5, color=ORANGE, mec=SURF, mew=1)
    ax.plot(xe, Hz_ret, color=INK, lw=1.2, ls="--", dashes=(4, 3))
    ax.plot(xe, Hd_ret, color=INK, lw=1.2, ls="--", dashes=(4, 3))
    ax.set_xlim(0, TMAX * 1.02); ax.set_ylim(0, 4.6)
    ax.set_xlabel("log x (center of the window)"); ax.set_ylabel("entropy over modes, H")
    ax.grid(axis="y", color=GRID, lw=0.6); ax.set_axisbelow(True)
    ax.text(TMAX * 0.985, EW[-1, 10] - 0.16, f"zeta function: {EW[-1, 10]:.3f} in every window", color=INK, va="top", ha="right", fontsize=8)
    ax.text(TMAX * 0.985, EW[-1, 4] + 0.2, f"Davenport and Heilbronn:\n{EW[0, 4]:.2f}, then {EW[:, 4].max():.2f}, down to {EW[-1, 4]:.2f}", color=INK, va="bottom", ha="right", fontsize=8)
    ax.text(TMAX * 0.985, 2.2, "dashed: from the modes returned with the symmetry lifted", color=INK, va="bottom", ha="right", fontsize=8)
    ax.set_title("The entropy over modes is conserved only with every zero on the line")
    fig.savefig(os.path.join(F, "fig_v1b_fig8.png"), dpi=300, bbox_inches="tight"); fig.savefig(os.path.join(F, "fig_v1b_fig8.pdf"), bbox_inches="tight"); plt.close(fig)
print("wrote figures/fig_v1b_fig7, fig_v1b_fig8")
