"""The two components of the Davenport and Heilbronn function, measured one at a time.
   chi is the character modulo 5 with chi(2) = i:   chi = 1, i, -i, -1, 0 (period 5);   chibar is its conjugate.
   L(s, chi) = 5^(-s) [ zeta(s,1/5) + i zeta(s,2/5) - i zeta(s,3/5) - zeta(s,4/5) ]   has a product over primes.
   Davenport and Heilbronn:  f = [ (1 - i k) L(s, chi) + (1 + i k) L(s, chibar) ] / 2   has the same symmetry and no product.
  A. Zeros of L(s, chi) and L(s, chibar) with 0 < Im < T: on the line by sign changes, off the line by search.
  B. Variance by window and entropy over modes for each component, next to the combination (ri_dh_results.json).
  C. The same fluctuation from the primes alone:  psi(x, chi) = sum of chi(p^k) log p.
  D. Pair statistics of the zeros of the components against the sum over primes (p = 5 left out) and the unitary ramp.
Usage: python ri_lpair.py [T] [NMAX]      (default T = 2000, NMAX = 1e6)
"""
import json
import os
import sys
import time
import numpy as np
from scipy.special import loggamma

T0 = time.time()
TTOP = float(sys.argv[1]) if len(sys.argv) > 1 else 2000.0
NMAX = int(float(sys.argv[2])) if len(sys.argv) > 2 else 10 ** 6
KAP = (np.sqrt(10 - 2 * np.sqrt(5)) - 2) / (np.sqrt(5) - 1)
BERN = [1 / 6, -1 / 30, 1 / 42, -1 / 30, 5 / 66, -691 / 2730, 7 / 6, -3617 / 510]
EULER = 0.5772156649015329
OUT = {}


def section(title):
    print()
    print("=" * 78)
    print(title)
    print("=" * 78)
    sys.stdout.flush()


def hurwitz(s, a, N):
    n = np.arange(N) + a
    S = np.exp(-np.outer(s, np.log(n))).sum(axis=1)
    b = N + a
    lb = np.log(b)
    S += np.exp((1 - s) * lb) / (s - 1) + 0.5 * np.exp(-s * lb)
    poch = s.copy()
    fact = 2.0
    for k in range(1, len(BERN) + 1):
        S += BERN[k - 1] / fact * poch * np.exp((-s - 2 * k + 1) * lb)
        poch = poch * (s + 2 * k - 1) * (s + 2 * k)
        fact *= (2 * k + 1) * (2 * k + 2)
    return S


def F(s, k2, N=None, chunk=4000):
    """5^(-s) [ zeta(s,1/5) + k2 zeta(s,2/5) - k2 zeta(s,3/5) - zeta(s,4/5) ];  k2 = i, -i (components) or k (combination)"""
    s = np.atleast_1d(np.asarray(s, dtype=complex))
    out = np.empty(len(s), dtype=complex)
    for i in range(0, len(s), chunk):
        ss = s[i:i + chunk]
        n = N if N is not None else int(np.abs(ss.imag).max()) + 40
        out[i:i + chunk] = np.exp(-ss * np.log(5)) * (hurwitz(ss, 0.2, n) + k2 * hurwitz(ss, 0.4, n)
                                                       - k2 * hurwitz(ss, 0.6, n) - hurwitz(ss, 0.8, n))
    return out


def theta(t):
    return np.imag(loggamma(0.75 + 0.5j * t)) + 0.5 * t * np.log(5 / np.pi)


def find_zeros(k2, name):
    """all zeros with 0 < Im < TTOP; returns (heights on the line, zeros off the line with sigma > 1/2)"""
    ts = np.linspace(3.0, min(TTOP, 60.0), 400)
    ws = np.exp(1j * theta(ts)) * F(0.5 + 1j * ts, k2)
    phi = 0.5 * np.angle(np.mean(ws ** 2 / np.abs(ws) ** 2))
    leak = np.max(np.abs(np.imag(np.exp(-1j * phi) * ws)) / np.maximum(np.abs(ws), 1e-30))
    print(f"{name}: e^(i theta(t)) L(1/2 + it) = e^(i phi) Z(t) with Z real, phi = {phi:.6f};  largest |Im| / |L| on 400 points = {leak:.1e}")

    def Z(t):
        return np.real(np.exp(1j * (theta(t) - phi)) * F(0.5 + 1j * t, k2))

    tg = np.arange(0.05, TTOP, 0.01)
    zg = Z(tg)
    idx = np.nonzero(np.sign(zg[:-1]) * np.sign(zg[1:]) < 0)[0]
    lo, hi = tg[idx].copy(), tg[idx + 1].copy()
    flo = zg[idx].copy()
    for _ in range(45):
        mid = 0.5 * (lo + hi)
        fm = Z(mid)
        left = np.sign(fm) == np.sign(flo)
        lo = np.where(left, mid, lo)
        flo = np.where(left, fm, flo)
        hi = np.where(left, hi, mid)
    on_line = 0.5 * (lo + hi)
    print(f"   on the line, by sign changes of Z(t): {len(on_line)} zeros   [{time.time() - T0:.0f} s]")
    sys.stdout.flush()
    sig = np.arange(0.5, 2.0001, 0.05)
    tt = np.arange(0.05, TTOP, 0.05)
    starts = []
    CH = 2000
    for i in range(0, len(tt), CH):
        j0, j1 = max(i - 1, 0), min(i + CH + 1, len(tt))
        tc = tt[j0:j1]
        S, Tm = np.meshgrid(sig, tc, indexing="ij")
        A = np.abs(F((S + 1j * Tm).ravel(), k2, N=int(tc[-1]) + 40)).reshape(S.shape)
        P = np.pad(A, 1, constant_values=np.inf)
        ismin = np.ones_like(A, dtype=bool)
        for da in (-1, 0, 1):
            for db in (-1, 0, 1):
                if da or db:
                    ismin &= A <= P[1 + da:1 + da + A.shape[0], 1 + db:1 + db + A.shape[1]]
        ismin[:, 0] &= (j0 == 0)
        ismin[:, -1] &= (j1 == len(tt))
        ia, ib = np.nonzero(ismin & (A < 1.0))
        starts.extend(sig[ia] + 1j * tc[ib])
    s = np.array(starts)
    nmin = len(s)
    NN = int(TTOP) + 60
    h = 1e-5
    for _ in range(40):
        f0 = F(s, k2, N=NN)
        d = (F(s + h, k2, N=NN) - F(s - h, k2, N=NN)) / (2 * h)
        step = f0 / np.where(np.abs(d) > 1e-12, d, 1e-12)
        step = np.where(np.abs(step) > 0.2, 0.2 * step / np.abs(step), step)
        s = s - step
    res = np.abs(F(s, k2, N=NN))
    ok = (res < 1e-8) & (s.imag > 0.04) & (s.imag < TTOP) & (s.real > -1.5) & (s.real < 2.5)
    s = s[ok]
    s = np.where(s.real < 0.5, 1 - s.real + 1j * s.imag, s)
    s = s[np.argsort(s.imag)]
    keep = np.ones(len(s), dtype=bool)
    for i in range(1, len(s)):
        if abs(s[i] - s[i - 1]) < 1e-5:
            keep[i] = False
    s = s[keep]
    off = s[np.abs(s.real - 0.5) > 1e-6]
    newton_on = s[np.abs(s.real - 0.5) <= 1e-6].imag
    extra = [g for g in newton_on if np.min(np.abs(on_line - g)) > 1e-5]
    if extra:
        on_line = np.sort(np.concatenate([on_line, extra]))
    print(f"   search off the line: {nmin} local minima of |L| on a grid of {len(sig)} x {len(tt)} points; Newton gives {len(s)} zeros, "
          f"{len(off)} of them off the line; {len(extra)} more on the line that the sign changes missed   [{time.time() - T0:.0f} s]")
    for z in off:
        print(f"      off the line: {z.real:.6f} + {z.imag:.6f} i")
    print(f"   first zeros: " + "  ".join(f"{g:.6f}" for g in on_line[:6]))
    sys.stdout.flush()
    return on_line, off


# ---------------------------------------------------------------- A. zeros
section(f"A. ZEROS of the two components, 0 < Im < {TTOP:g}")
s0 = np.array([0.5 + 10j])
la, lb_ = F(s0, 1j)[0], F(s0, -1j)[0]
comb = 0.5 * ((1 - 1j * KAP) * la + (1 + 1j * KAP) * lb_)
print(f"check at s = 1/2 + 10i:  [(1 - ik) L(chi) + (1 + ik) L(chibar)] / 2 = {comb:.12f};  Davenport and Heilbronn directly = {F(s0, KAP)[0]:.12f}")
gA, offA = find_zeros(1j, "L(s, chi)")
gB, offB = find_zeros(-1j, "L(s, chibar)")
nbar = theta(np.array([TTOP]))[0] / np.pi
print(f"\ntotal for the pair: {len(gA)} + {len(gB)} = {len(gA) + len(gB)} on the line, {len(offA) + len(offB)} off the line;  "
      f"smooth count 2 theta(T)/pi = {2 * nbar:.1f}")
OUT["zeros"] = {"T": TTOP, "chi": gA.tolist(), "chibar": gB.tolist(), "off_chi": len(offA), "off_chibar": len(offB)}

# ---------------------------------------------------------------- B. variance and entropy
section("B. VARIANCE BY WINDOW and ENTROPY OVER MODES, from the zeros")
# all zeros of L(s, chi): 1/2 + i g for g in gA, and 1/2 - i g for g in gB (the zeros of chibar are the conjugates)
rho_chi = np.concatenate([0.5 + 1j * gA, 0.5 - 1j * gB])
rho_bar = np.conj(rho_chi)
h = 1e-3
Lp, Lm = F(np.array([1 + h + 0j]), 1j)[0], F(np.array([1 - h + 0j]), 1j)[0]
exact = np.log(5 / np.pi) - EULER + 2 * np.real(((Lp - Lm) / (2 * h)) / (0.5 * (Lp + Lm)))
tail = (np.log(5 * TTOP / (2 * np.pi)) + 1) / (np.pi * TTOP)
ssum = np.sum(1 / np.abs(rho_chi) ** 2)
print("The scaled fluctuation of a component is psi(x, chi)/sqrt(x) = - sum over all its zeros of x^(rho - 1/2) / rho  (complex).")
print("With every zero on the line its variance is the sum of 1/|rho|^2, which has the closed form")
print(f"   log(5/pi) - gamma_E + 2 Re L'(1, chi)/L(1, chi) = {exact:.6f}")
print(f"   sum over the {len(rho_chi)} zeros found: {ssum:.6f};  with the smooth tail above T ({tail:.6f}): {ssum + tail:.6f}")
OUT["invariant"] = {"closed_form": float(exact), "zero_sum": float(ssum), "tail": float(tail)}


def mode_sum_c(rho, t, chunk=400):
    f = np.zeros(len(t), dtype=complex)
    for i in range(0, len(rho), chunk):
        r = rho[i:i + chunk]
        f += (np.exp(np.outer(r - 0.5, t)) / r[:, None]).sum(axis=0)
    return f


def cvar(f):
    return float(np.mean(np.abs(f - f.mean()) ** 2))


def entropy(rho, lo, hi):
    a = 1.0 / np.abs(rho) ** 2
    e = 2 * (rho.real - 0.5)
    small = np.abs(e) < 1e-12
    g = np.where(small, 1.0, (np.exp(e * hi) - np.exp(e * lo)) / np.where(small, 1.0, e * (hi - lo)))
    p = a * g
    p = p / p.sum()
    q = p[p > 0]
    return float(-np.sum(q * np.log(q)))


WINDOWS = [(2, 4), (4, 6), (6, 8), (8, 10), (10, 12), (12, 14), (14, 16), (16, 18), (18, 20)]
rho_dh = None
if os.path.exists("ri_dh_results.json"):
    with open("ri_dh_results.json") as fj:
        zd = json.load(fj)["zeros"]
    if abs(zd["T"] - TTOP) < 1e-6:
        on = 0.5 + 1j * np.array(zd["on_line"])
        of = np.array(zd["off_sigma"]) + 1j * np.array(zd["off_gamma"])
        up = np.concatenate([on, of, 1 - of.real + 1j * of.imag])
        rho_dh = np.concatenate([up, np.conj(up)])
print(f"\nL(s, chi): {len(rho_chi)} zeros, all heights of both signs below {TTOP:g}.  "
      + (f"Combination: {len(rho_dh)} zeros counted the same way (from ri_dh_results.json)." if rho_dh is not None
         else "(ri_dh_results.json for the same T not found: combination columns left blank)"))
print("Entropy here is counted over zeros of both signs of the height for all three functions; for the combination this is")
print("the value of ri_dh.py (zeros above the axis only) plus log 2 = 0.6931.")
print("\n  window     L(chi)      L(chi)       L(chibar)    L(chibar)    |  combination   combination")
print("             Var         entropy H    Var          entropy H    |  Var           entropy H")
rows = []
for lo, hi in WINDOWS:
    t = np.linspace(lo, hi, 6000)
    va, vb = cvar(mode_sum_c(rho_chi, t)), cvar(mode_sum_c(rho_bar, t))
    Ha, Hb = entropy(rho_chi, lo, hi), entropy(rho_bar, lo, hi)
    vd, Hd = (np.nan, np.nan)
    if rho_dh is not None:
        vd, Hd = cvar(mode_sum_c(rho_dh, t)), entropy(rho_dh, lo, hi)
    print(f"  [{lo:2d},{hi:2d}] {va:10.5f} {Ha:11.4f} {vb:12.5f} {Hb:11.4f}      | {vd:10.5g} {Hd:12.4f}")
    rows.append([lo, hi, va, Ha, vb, Hb, float(vd), float(Hd)])
OUT["variance_entropy"] = rows
print(f"[{time.time() - T0:.0f} s]")
sys.stdout.flush()

# ---------------------------------------------------------------- C. primes
section("C. THE SAME FLUCTUATION FROM THE PRIMES ALONE (no zeros used)")
print("psi(x, chi) = sum over prime powers p^k <= x of chi(p^k) log p.   -L'/L has coefficients on prime powers only.")
sv = np.ones(NMAX + 1, dtype=bool)
sv[:2] = False
for i in range(2, int(NMAX ** 0.5) + 1):
    if sv[i]:
        sv[i * i::i] = False
pr = np.nonzero(sv)[0]
CHI = np.array([0, 1, 1j, -1j, -1])
c = np.zeros(NMAX + 1, dtype=complex)
plog, pw = [], []
for p in pr:
    q, k, l = int(p), 1, np.log(p)
    while q <= NMAX:
        c[q] = CHI[q % 5] * l
        if p != 5:
            plog.append(k * l)
            pw.append(l * l / q)
        q *= int(p)
        k += 1
psi = np.cumsum(c)
plog, pw = np.array(plog), np.array(pw)
order = np.argsort(plog)
plog, pw = plog[order], pw[order]
cw = np.concatenate([[0.0], np.cumsum(pw)])
rng = np.random.default_rng(20261105)
tmax = np.log(NMAX)
WA = [(lo, hi) for lo, hi in WINDOWS if hi <= tmax + 1e-9]
if WA[-1][1] < tmax - 0.3:
    WA.append((WA[-1][1], float(np.floor(tmax * 10) / 10)))
print(f"primes up to {NMAX:.3g}.   closed form of the variance: {exact:.5f}")
print("\n  window        Var of psi(x, chi)/sqrt(x),   Var from the zeros    ratio    correlation of the two")
print("                from the primes               found in part A                on the same points")
rows = []
for lo, hi in WA:
    t = np.sort(rng.uniform(lo, hi, 6000))
    x = np.exp(t)
    fa = psi[np.minimum(x.astype(np.int64), NMAX)] / np.sqrt(x)
    fz = -mode_sum_c(rho_chi, t)
    a0, z0 = fa - fa.mean(), fz - fz.mean()
    cc = float(np.real(np.vdot(z0, a0)) / np.sqrt(np.vdot(a0, a0).real * np.vdot(z0, z0).real))
    print(f"  [{lo:4.1f},{hi:4.1f}] {cvar(fa):20.5f} {cvar(fz):22.5f} {cvar(fa) / cvar(fz):10.3f} {cc:14.4f}")
    rows.append([lo, hi, cvar(fa), cvar(fz), cc])
OUT["primes"] = rows
print(f"[{time.time() - T0:.0f} s]")
sys.stdout.flush()

# ---------------------------------------------------------------- D. pair statistics
section("D. PAIR STATISTICS of the zeros of the components, against the primes and the unitary ramp")
B = 200
SKIP = 200
hann = 0.5 - 0.5 * np.cos(2 * np.pi * (np.arange(B) + 0.5) / B)
print("Predicted: K(bin) = sum over prime powers (p = 5 left out) with k log p / L in the bin of (log p)^2 / p^k,")
print(f"divided by L^2 * width, L = log(5 E / 2 pi).  Measured: zeros {SKIP + 1} onward of each component, unfolded with theta(t)/pi,")
print(f"blocks of {B} with a Hann taper, the two components pooled.  +- is the standard error from the scatter of the blocks.")
edges = np.round(np.arange(0.05, 1.0 + 1e-9, 0.05), 2)
tau = np.arange(0.05 + 0.00125, edges[-1], 0.0025)
nbin = len(edges) - 1
meas, pred, Ls = [], [], []
for g in (gA, gB):
    w = theta(g) / np.pi
    for i in range(SKIP, len(g) - B + 1, B):
        L = np.log(5 * 0.5 * (g[i] + g[i + B - 1]) / (2 * np.pi))
        ph = np.exp(2j * np.pi * np.outer(tau, w[i:i + B]))
        K = np.abs((ph * hann).sum(axis=1)) ** 2 / np.sum(hann ** 2)
        meas.append([K[(tau >= edges[j]) & (tau < edges[j + 1])].mean() for j in range(nbin)])
        pred.append([(cw[np.searchsorted(plog, edges[j + 1] * L)] - cw[np.searchsorted(plog, edges[j] * L)])
                     / (L * L * (edges[j + 1] - edges[j])) for j in range(nbin)])
        Ls.append(L)
meas, pred, Ls = np.array(meas), np.array(pred), np.array(Ls)
if len(meas) >= 4:
    m = meas.mean(axis=0)
    e = meas.std(axis=0, ddof=1) / np.sqrt(len(meas))
    p = pred.mean(axis=0)
    mid = 0.5 * (edges[:-1] + edges[1:])
    print(f"\n{len(meas)} blocks, L = {Ls.min():.2f} to {Ls.max():.2f}")
    print("     tau          zeros      +-     from primes   unitary ramp   zeros - primes   zeros - ramp   primes - ramp")
    for j in range(nbin):
        print(f"  {edges[j]:4.2f} to {edges[j + 1]:4.2f} {m[j]:9.4f} {e[j]:8.4f} {p[j]:12.4f} {mid[j]:12.3f} "
              f"{m[j] - p[j]:14.4f} {m[j] - mid[j]:14.4f} {p[j] - mid[j]:14.4f}")
    k = (edges[1:] <= 0.8 + 1e-9) & (p > 0) & (e > 0)
    chi_p = float(np.mean(((m[k] - p[k]) / e[k]) ** 2))
    chi_r = float(np.mean(((m[k] - mid[k]) / e[k]) ** 2))
    print(f"  bins below tau = 0.80 ({k.sum()} bins): rms(zeros - primes) = {np.sqrt(np.mean((m[k] - p[k]) ** 2)):.4f};  "
          f"rms(zeros - ramp) = {np.sqrt(np.mean((m[k] - mid[k]) ** 2)):.4f};  "
          f"rms(primes - ramp) = {np.sqrt(np.mean((p[k] - mid[k]) ** 2)):.4f};  mean standard error = {e[k].mean():.4f}")
    print(f"  mean of ((zeros - prediction) / error)^2 over those bins:  primes {chi_p:.2f};  unitary ramp {chi_r:.2f}   (1 = agreement within the error)")
    OUT["pairs"] = {"edges": edges.tolist(), "zeros": m.tolist(), "err": e.tolist(), "primes": p.tolist(),
                    "chi2_primes": chi_p, "chi2_ramp": chi_r, "blocks": int(len(meas)), "L": [float(Ls.min()), float(Ls.max())]}
else:
    print(f"\nonly {len(meas)} blocks at this T: part D needs T of 1000 or more")

with open("ri_lpair_results.json", "w") as fjs:
    json.dump(OUT, fjs, indent=1)
print(f"\nwrote ri_lpair_results.json   [{time.time() - T0:.0f} s]")
