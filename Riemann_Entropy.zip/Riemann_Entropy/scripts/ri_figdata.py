"""Numbers behind Figures 4, 5 (middle panel), 6 and 7, computed from the zeros already found.
No new zero search.  Reads, from this folder:
   ri_dh_results.json      zeros of the Davenport and Heilbronn function            (ri_dh.py, campaign 3)
   ri_lpair_results.json   zeros of L(s, chi) and L(s, chibar)                      (ri_lpair.py, campaign 4)
   zeros1                  Odlyzko's table of the zeros of the zeta function
  A. Entropy over modes and variance by window of log x, carried out to log x = TMAX (default 100),
     with the same definitions as ri_dh.py part B and ri_lpair.py part B.
  B. Share of the variance carried by each mode against log x, for the first NROW modes (Figure 6).
  C. Modulus of the zeta function, of L(s, chi) and of the combination across the critical strip (Figure 7).
Writes ri_figdata_results.json (tables) and ri_figdata_arrays.npz (the two maps).
Usage: python ri_figdata.py [TMAX]      (default 100)
"""
import json
import os
import sys
import time
import numpy as np

T0 = time.time()
TMAX = int(float(sys.argv[1])) if len(sys.argv) > 1 else 100
KAP = (np.sqrt(10 - 2 * np.sqrt(5)) - 2) / (np.sqrt(5) - 1)
BERN = [1 / 6, -1 / 30, 1 / 42, -1 / 30, 5 / 66, -691 / 2730, 7 / 6, -3617 / 510]
OUT = {}


def section(title):
    print()
    print("=" * 78)
    print(title)
    print("=" * 78)
    sys.stdout.flush()


def find(name):
    for d in (".", os.path.join("..", "results")):
        p = os.path.join(d, name)
        if os.path.exists(p):
            return p
    sys.exit(f"{name} not found in this folder or in ../results")


with open(find("ri_dh_results.json")) as fj:
    dh = json.load(fj)
with open(find("ri_lpair_results.json")) as fj:
    lp = json.load(fj)
on = np.array(dh["zeros"]["on_line"])
osig, ogam = np.array(dh["zeros"]["off_sigma"]), np.array(dh["zeros"]["off_gamma"])
rho_on = 0.5 + 1j * on
rho_off = np.concatenate([osig + 1j * ogam, 1 - osig + 1j * ogam])
rho_dh = np.concatenate([rho_on, rho_off])
NDH = len(rho_dh)
gchi, gbar = np.array(lp["zeros"]["chi"]), np.array(lp["zeros"]["chibar"])
rho_chi2 = np.concatenate([0.5 + 1j * gchi, 0.5 - 1j * gbar])      # zeros of L(s, chi) of both signs of the height
zz = np.loadtxt(find("zeros1"))
if len(zz) < NDH:
    sys.exit(f"zeros1 holds {len(zz)} zeros; {NDH} are needed")
rho_zeta = 0.5 + 1j * zz[:NDH]
print(f"Davenport and Heilbronn: {len(rho_on)} zeros on the line + 2 x {len(osig)} off it = {NDH}, heights below {dh['zeros']['T']:g}")
print(f"L(s, chi): {len(gchi)} zeros;  L(s, chibar): {len(gbar)} zeros;  zeta function: the first {NDH} zeros of zeros1")


def mode_sum(rho, t, chunk=400):
    f = np.zeros(len(t))
    for i in range(0, len(rho), chunk):
        r = rho[i:i + chunk]
        f += 2.0 * np.real(np.exp(np.outer(r - 0.5, t)) / r[:, None]).sum(axis=0)
    return f


def mode_sum_c(rho, t, chunk=400):
    """complex sum over the zeros of a component, as in ri_lpair.py"""
    f = np.zeros(len(t), dtype=complex)
    for i in range(0, len(rho), chunk):
        r = rho[i:i + chunk]
        f += (np.exp(np.outer(r - 0.5, t)) / r[:, None]).sum(axis=0)
    return f


def window_shares(rho, lo, hi):
    """shares of the modes averaged over the window, as in ri_dh.py"""
    a = 1.0 / np.abs(rho) ** 2
    e = 2 * (rho.real - 0.5)
    small = np.abs(e) < 1e-12
    g = np.where(small, 1.0, (np.exp(e * hi) - np.exp(e * lo)) / np.where(small, 1.0, e * (hi - lo)))
    p = a * g
    return p / p.sum()


def H_of(p):
    q = p[p > 0]
    return float(-np.sum(q * np.log(q)))


# ---------------------------------------------------------------- A. entropy and variance out to TMAX
section(f"A. ENTROPY OVER MODES and VARIANCE BY WINDOW, carried out to log x = {TMAX}")
print("Same definitions as ri_dh.py part B.  H: zeros above the real axis (Table 17).")
print("H, both signs: zeros of both signs of the height (Table 18); for the combination this is H + log 2.")
print("The first nine windows repeat campaign 3 and campaign 4.")
print("\n  window    combination:  share off line   entropy   entropy H    largest   held by the mode             | zeta:      zeta:      | L(chi):    L(chi): H")
print("            Var           predicted        H         both signs   share                                  | Var        entropy H  | Var        both signs")
rows = []
for lo in range(2, TMAX, 2):
    hi = lo + 2
    t = np.linspace(lo, hi, 6000)
    v = mode_sum(rho_dh, t).var()
    p = window_shares(rho_dh, lo, hi)
    H = H_of(p)
    k = int(np.argmax(p))
    zv = mode_sum(rho_zeta, t).var()
    zH = H_of(window_shares(rho_zeta, lo, hi))
    fc = mode_sum_c(rho_chi2, t)
    cv = np.mean(np.abs(fc - fc.mean()) ** 2)
    cH = H_of(window_shares(rho_chi2, lo, hi))
    print(f"  [{lo:2d},{hi:2d}] {v:13.5g} {p[len(rho_on):].sum():14.4f} {H:12.4f} {H + np.log(2):10.4f} {p[k]:11.4f}   "
          f"{rho_dh[k].real:.6f} + {rho_dh[k].imag:10.6f} i   | {zv:8.5f} {zH:10.4f}  | {cv:8.5f} {cH:10.4f}")
    rows.append([lo, hi, float(v), float(p[len(rho_on):].sum()), H, H + float(np.log(2)), float(p[k]),
                 float(rho_dh[k].real), float(rho_dh[k].imag), float(zv), zH, float(cv), cH])
    sys.stdout.flush()
OUT["entropy_by_window"] = {"columns": ["lo", "hi", "var_combination", "share_off_line", "H_combination", "H_combination_both_signs",
                                        "largest_share", "top_sigma", "top_gamma", "var_zeta", "H_zeta", "var_component", "H_component_both_signs"],
                            "rows": rows}
Hline = H_of(window_shares(0.5 + 1j * rho_dh.imag, 2, 4))
print(f"\nentropy of the combination with every zero held on the line (same heights): {Hline:.4f}, the same in every window")
r = np.array(rows)
print(f"entropy of the combination: {r[0, 4]:.4f} in the first window, largest {r[:, 4].max():.4f}, {r[-1, 4]:.4f} in the last")
print(f"entropy of the zeta function: {r[:, 10].min():.4f} to {r[:, 10].max():.4f};   of L(s, chi), both signs: {r[:, 12].min():.4f} to {r[:, 12].max():.4f}")
print(f"[{time.time() - T0:.0f} s]")
sys.stdout.flush()

# ---------------------------------------------------------------- B. share of each mode against log x
NROW = 200
section(f"B. SHARE OF EACH MODE against log x, first {NROW} modes in order of height (Figure 6)")
tg = np.linspace(2, TMAX, 10 * (TMAX - 2) + 1)


def shares(rho):
    """p_n(t) = |rho_n|^-2 e^(2 sigma_n t) / sum, at each t; modes in order of height"""
    rho = rho[np.argsort(rho.imag)]
    lw = -2 * np.log(np.abs(rho))[:, None] + 2 * (rho.real - 0.5)[:, None] * tg[None, :]
    lw -= lw.max(axis=0, keepdims=True)
    p = np.exp(lw)
    return rho, p / p.sum(axis=0, keepdims=True)


rz, pz = shares(rho_zeta)
rc, pc = shares(0.5 + 1j * gchi)
rd, pd = shares(rho_dh)
print("Shares are taken over all the zeros of each function above the real axis; the map shows the first rows.")
print(f"zeta function: share of mode 1 = {pz[0, 0]:.4f} at log x = {tg[0]:g} and {pz[0, -1]:.4f} at log x = {tg[-1]:g}")
print(f"L(s, chi):     share of mode 1 = {pc[0, 0]:.4f} at log x = {tg[0]:g} and {pc[0, -1]:.4f} at log x = {tg[-1]:g}")
print("\ncombination, at single values of log x:")
print("  log x   largest share   held by the mode             share of all modes off the line   entropy H at this log x")
offm = np.abs(rd.real - 0.5) > 1e-9
brow = []
for tv in range(10, TMAX + 1, 10):
    j = int(np.argmin(np.abs(tg - tv)))
    k = int(np.argmax(pd[:, j]))
    Hh = H_of(pd[:, j])
    print(f"  {tv:5d} {pd[k, j]:12.4f}      {rd[k].real:.6f} + {rd[k].imag:10.6f} i {pd[offm, j].sum():18.4f} {Hh:24.4f}")
    brow.append([tv, float(pd[k, j]), float(rd[k].real), float(rd[k].imag), float(pd[offm, j].sum()), Hh])
OUT["shares_at_log_x"] = {"columns": ["log_x", "largest_share", "top_sigma", "top_gamma", "share_off_line", "H"], "rows": brow}
print(f"[{time.time() - T0:.0f} s]")
sys.stdout.flush()

# ---------------------------------------------------------------- C. modulus across the strip
T1, T2 = 60.0, 125.0
section(f"C. MODULUS ACROSS THE CRITICAL STRIP, heights {T1:g} to {T2:g} (Figure 7)")


def hurwitz(s, a, N):
    """Hurwitz zeta by Euler and Maclaurin summation, as in ri_dh.py"""
    n = np.arange(N) + a
    S = np.exp(-np.outer(s, np.log(n))).sum(axis=1)
    b = N + a
    lb = np.log(b)
    S += np.exp((1 - s) * lb) / (s - 1) + 0.5 * np.exp(-s * lb)
    poch = s.copy()
    fact = 2.0
    for k in range(1, len(BERN) + 1):
        S += BERN[k - 1] / fact * poch * np.exp((-s - 2 * k + 1) * lb)
        poch = poch * (s + 2 * k - 1) * (s + 2 * k)
        fact *= (2 * k + 1) * (2 * k + 2)
    return S


NT = int(T2) + 60


def three(s, chunk=4000):
    """zeta(s), L(s, chi), Davenport and Heilbronn f(s)"""
    s = np.atleast_1d(np.asarray(s, dtype=complex))
    z, L, f = (np.empty(len(s), dtype=complex) for _ in range(3))
    for i in range(0, len(s), chunk):
        ss = s[i:i + chunk]
        h1, h2, h3, h4 = hurwitz(ss, 0.2, NT), hurwitz(ss, 0.4, NT), hurwitz(ss, 0.6, NT), hurwitz(ss, 0.8, NT)
        five = np.exp(-ss * np.log(5))
        z[i:i + chunk] = hurwitz(ss, 1.0, NT)
        L[i:i + chunk] = five * (h1 + 1j * h2 - 1j * h3 - h4)
        f[i:i + chunk] = five * (h1 + KAP * h2 - KAP * h3 - h4)
    return z, L, f


z0, L0, f0 = three(np.array([0.5 + 10j]))
print(f"check at s = 1/2 + 10i:  f = {f0[0]:.12f}   (ri_dh.py and mpmath: 1.667900783472+0.949827346451j)")
try:
    import mpmath as mp
    mp.mp.dps = 20
    s0 = mp.mpc(0.5, 10)
    zm = complex(mp.zeta(s0))
    Lm = complex(mp.power(5, -s0) * (mp.zeta(s0, 0.2) + 1j * mp.zeta(s0, 0.4) - 1j * mp.zeta(s0, 0.6) - mp.zeta(s0, 0.8)))
    print(f"                         zeta = {z0[0]:.12f}   (mpmath: {zm:.12f})")
    print(f"                         L(s, chi) = {L0[0]:.12f}   (mpmath: {Lm:.12f})")
except ImportError:
    print(f"                         zeta = {z0[0]:.12f};  L(s, chi) = {L0[0]:.12f}   (mpmath not installed, no comparison)")
sg = np.linspace(0.0, 1.0, 161)
hg = np.linspace(T1, T2, 1041)
Sg, Hg = np.meshgrid(sg, hg, indexing="ij")
mz, mL, mf = (np.abs(a).reshape(Sg.shape) for a in three((Sg + 1j * Hg).ravel()))
print(f"grid of {len(sg)} x {len(hg)} points, Re s from 0 to 1")
print("\nmodulus of each function at its own zeros in this range (zeros from the files read above):")
zin = zz[(zz > T1) & (zz < T2)]
cin = gchi[(gchi > T1) & (gchi < T2)]
din = on[(on > T1) & (on < T2)]
sel = (ogam > T1) & (ogam < T2)
print(f"   zeta function: {len(zin)} zeros on the line, largest |zeta| there = {np.abs(three(0.5 + 1j * zin)[0]).max():.1e}")
print(f"   L(s, chi):     {len(cin)} zeros on the line, largest |L| there = {np.abs(three(0.5 + 1j * cin)[1]).max():.1e}")
print(f"   combination:   {len(din)} zeros on the line, largest |f| there = {np.abs(three(0.5 + 1j * din)[2]).max():.1e}")
offl = []
for sgm, g in zip(osig[sel], ogam[sel]):
    a1 = abs(three(np.array([sgm + 1j * g]))[2][0])
    a2 = abs(three(np.array([1 - sgm + 1j * g]))[2][0])
    print(f"   combination, off the line: {sgm:.6f} + {g:.6f} i, |f| = {a1:.1e};  partner {1 - sgm:.6f} + {g:.6f} i, |f| = {a2:.1e}")
    offl.append([float(sgm), float(g), float(a1), float(a2)])
jl = int(np.argmin(np.abs(sg - 0.5)))
print("\nsmallest modulus on the grid, on the line Re s = 1/2 and away from it (|Re s - 1/2| > 0.1):")
far = np.abs(sg - 0.5) > 0.1
for name, m in (("zeta function", mz), ("L(s, chi)", mL), ("combination", mf)):
    print(f"   {name:14s} on the line {m[jl].min():.2e};   away from it {m[far].min():.2e}")
OUT["strip"] = {"T1": T1, "T2": T2, "zeros_zeta": zin.tolist(), "zeros_chi": cin.tolist(), "zeros_dh_on": din.tolist(), "zeros_dh_off": offl}

np.savez_compressed("ri_figdata_arrays.npz", t=tg, shares_zeta=pz[:NROW].astype(np.float32), shares_chi=pc[:NROW].astype(np.float32),
                    shares_dh=pd[:NROW].astype(np.float32), dh_sigma=rd[:NROW].real, dh_gamma=rd[:NROW].imag,
                    strip_sigma=sg, strip_height=hg, mod_zeta=mz.astype(np.float32), mod_chi=mL.astype(np.float32), mod_dh=mf.astype(np.float32))
with open("ri_figdata_results.json", "w") as fjs:
    json.dump(OUT, fjs, indent=1)
print(f"\nwrote ri_figdata_results.json and ri_figdata_arrays.npz   [{time.time() - T0:.0f} s]")
