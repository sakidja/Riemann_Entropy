"""The growth of the variance, term by term, and its rate.

Reads   ri_dh_results.json      zeros of the Davenport and Heilbronn function   (ri_dh.py, campaign 3)
        ri_lpair_results.json   zeros of L(s, chi)                              (ri_lpair.py, campaign 4)
Writes  ri_steps_results.json   every number that the figure shows
        figures/fig8_steps.png and .pdf

With t = log x and rho_n = sigma_n + i gamma_n, delta_n = sigma_n - 1/2, zeros above the real axis:
   term of mode n        a_n(t) = 2 e^(2 delta_n t) / |rho_n|^2        (the 2 counts the zero below the axis;
                                                                        for L(s, chi) both signs are listed, no 2)
   variance              V(t)   = sum_n a_n(t)
   share                 p_n(t) = a_n(t) / V(t)
   rate of growth        d log V / dt   = 2 <delta>          average of delta over the shares
   its rate of change    d2 log V / dt2 = 4 Var(delta)       variance of delta over the shares, never negative
Same definitions of the modes as ri_dh.py part B and ri_figdata.py part B.

Usage:  python ri_steps.py [TMAX]        (default 40, where the lead changes hands; a few seconds, no job needed)
"""
import json
import os
import sys
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

TMAX = int(sys.argv[1]) if len(sys.argv) > 1 else 40
HERE = os.path.dirname(os.path.abspath(__file__))
FLAT = os.path.exists(os.path.join(HERE, "ri_dh_results.json"))      # on Perlmutter the scripts and the results share one folder
R = HERE if FLAT else os.path.join(HERE, "..", "results")
F = os.path.join(HERE, "figures") if FLAT else os.path.join(HERE, "..", "figures")
os.makedirs(F, exist_ok=True)


def load(name):
    p = os.path.join(R, name)
    if not os.path.exists(p):
        sys.exit(f"{name} is not in {os.path.normpath(R)}")
    with open(p) as f:
        return json.load(f)


dh, lp = load("ri_dh_results.json"), load("ri_lpair_results.json")
on = np.array(dh["zeros"]["on_line"])
osig, ogam = np.array(dh["zeros"]["off_sigma"]), np.array(dh["zeros"]["off_gamma"])
rho_dh = np.concatenate([0.5 + 1j * on, osig + 1j * ogam, 1 - osig + 1j * ogam])
rho_dh = rho_dh[np.argsort(rho_dh.imag)]
rho_chi = np.concatenate([0.5 + 1j * np.array(lp["zeros"]["chi"]), 0.5 - 1j * np.array(lp["zeros"]["chibar"])])      # zeros of L(s, chi) of both signs of the height, as in ri_figdata.py
t = np.linspace(2, TMAX, 10 * (TMAX - 2) + 1)
print(f"Davenport and Heilbronn: {len(on)} zeros on the line + 2 x {len(osig)} off it, heights below {dh['zeros']['T']:g}")
print(f"L(s, chi): {len(rho_chi)} zeros of both signs of the height, all on the line; closed form of its variance {lp['invariant']['closed_form']:.4f}")


def rates(rho, both):
    """both = 2 when rho holds the zeros above the axis only, 1 when it holds both signs"""
    d = rho.real - 0.5
    la = np.log(both) - 2 * np.log(np.abs(rho))[:, None] + 2 * d[:, None] * t[None, :]      # log of each term
    m = la.max(axis=0)
    logV = m + np.log(np.exp(la - m).sum(axis=0))
    p = np.exp(la - logV)
    mean = (p * d[:, None]).sum(axis=0)
    var = (p * d[:, None] ** 2).sum(axis=0) - mean ** 2
    return la, logV, p, 2 * mean, 4 * var


la, logV, p, slope, curv = rates(rho_dh, 2.0)
_, logVc, _, slopec, _ = rates(rho_chi, 1.0)
lead = p.argmax(axis=0)
onmask = np.abs(rho_dh.real - 0.5) < 1e-9
log_on = np.log(np.exp(la[onmask] - la[onmask].max(axis=0)).sum(axis=0)) + la[onmask].max(axis=0)      # all the modes on the line together

print("\nA. THE LEAD, and where it passes from one mode to the next")
print("   from log x    leading mode                 delta      2 delta    its share there   row in Figure 6")
hand = []
k0 = 0
for k in range(1, len(t) + 1):
    if k == len(t) or lead[k] != lead[k0]:
        r = rho_dh[lead[k0]]
        hand.append({"from_log_x": float(t[k0]), "to_log_x": float(t[k - 1]), "sigma": float(r.real), "gamma": float(r.imag),
                     "delta": float(r.real - 0.5), "two_delta": float(2 * (r.real - 0.5)), "share_at_start": float(p[lead[k0], k0]), "row_in_figure_6": int(lead[k0] + 1)})
        print(f"   {t[k0]:8.1f}     {r.real:.6f} + {r.imag:10.6f} i   {r.real - 0.5:8.4f}   {2 * (r.real - 0.5):8.4f}   {p[lead[k0], k0]:8.4f}   {lead[k0] + 1:10d}")
        k0 = k

print("\nB. THE VARIANCE AND ITS RATE OF GROWTH, combination and one component")
print("   log x    V combination   d log V / dt = 2<delta>   4 Var(delta)   largest share  |  V of L(s, chi)   its rate")
tab = []
for tv in [2, 5] + list(range(10, TMAX + 1, 10)):
    j = int(np.argmin(np.abs(t - tv)))
    tab.append([float(t[j]), float(np.exp(logV[j])), float(slope[j]), float(curv[j]), float(p[:, j].max()), float(np.exp(logVc[j])), float(slopec[j])])
    print(f"   {t[j]:5.0f}   {np.exp(logV[j]):13.5g}   {slope[j]:14.4f}   {curv[j]:16.4f}   {p[:, j].max():10.4f}     |  {np.exp(logVc[j]):10.5f}   {slopec[j]:8.4f}")
print(f"\n   largest delta below height {dh['zeros']['T']:g}: {(rho_dh.real - 0.5).max():.6f}, so the rate ends at {2 * (rho_dh.real - 0.5).max():.4f}")
print(f"   smallest value of 4 Var(delta) on the grid: {curv.min():.2e} (never negative: the rate only goes up)")

leaders = sorted(set(int(i) for i in lead))
OUT = {"t": t.tolist(), "logV_combination": logV.tolist(), "slope_combination": slope.tolist(), "curvature_combination": curv.tolist(),
       "logV_component": logVc.tolist(), "slope_component": slopec.tolist(), "log_term_on_line_modes_together": log_on.tolist(),
       "leaders": [{"sigma": float(rho_dh[i].real), "gamma": float(rho_dh[i].imag), "log_term": la[i].tolist()} for i in leaders],
       "handovers": hand, "table": {"columns": ["log_x", "V_combination", "slope", "curvature", "largest_share", "V_component", "slope_component"], "rows": tab}}
with open(os.path.join(R, "ri_steps_results.json"), "w") as f:
    json.dump(OUT, f)
print("\nwrote ri_steps_results.json")

# ---------------------------------------------------------------- the figure, drawn from the file just written
with open(os.path.join(R, "ri_steps_results.json")) as f:
    D = json.load(f)
BLUE, ORANGE, AQUA, YELLOW, VIOLET = "#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#7a5cd6"
INK, INK2, GRID, SURF = "#0b0b0b", "#52514e", "#e4e3df", "#fcfcfb"
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9, "axes.edgecolor": INK2, "axes.labelcolor": INK,
                     "xtick.color": INK2, "ytick.color": INK2, "axes.spines.top": False, "axes.spines.right": False,
                     "axes.linewidth": 0.8, "figure.facecolor": SURF, "axes.facecolor": SURF, "savefig.facecolor": SURF,
                     "axes.titlesize": 10, "axes.titleweight": "bold", "axes.titlelocation": "left"})
tt = np.array(D["t"])
L10 = np.log(10.0)
offl = [m for m in D["leaders"] if abs(m["sigma"] - 0.5) > 1e-9]
cols = [YELLOW, VIOLET, AQUA, "#c2417c", "#7a7a7a"]
fig, (a1, a2) = plt.subplots(2, 1, figsize=(7.0, 6.6), sharex=True, gridspec_kw={"height_ratios": [1.25, 1], "hspace": 0.16})
fig.suptitle("The variance grows one mode at a time; its rate rises to 2δ of the leading mode", x=0.02, ha="left", fontsize=11, fontweight="bold", y=0.975)

a1.set_title("Variance and the terms that make it up")
for m, c in zip(offl, cols):
    a1.plot(tt, np.array(m["log_term"]) / L10, color=c, lw=1.6)
a1.plot(tt, np.array(D["logV_combination"]) / L10, color=ORANGE, lw=2.6, alpha=0.9)
a1.plot(tt, np.array(D["logV_component"]) / L10, color=BLUE, lw=2.0)
a1.plot(tt, np.array(D["log_term_on_line_modes_together"]) / L10, color=INK, lw=1.2, ls=(0, (3, 3)))
a1.set_ylabel("log10 of the variance")
ymax = D["logV_combination"][-1] / L10
a1.set_ylim(-5, ymax + 1.5)
a1.grid(axis="y", color=GRID, lw=0.8)
a1.set_axisbelow(True)
xr = tt[-1]
j = int(len(tt) * 0.62)
a1.text(tt[j], D["logV_combination"][j] / L10 + 0.9, "combination, total", color=ORANGE, fontsize=8.5, fontweight="bold", ha="right", va="bottom")
a1.text(xr * 0.99, -1.25, "L(s, χ), one component (blue): constant", color=BLUE, fontsize=8.5, ha="right", va="top")
a1.text(xr * 0.99, -0.45, "combination, all modes on the line together (dashed)", color=INK, fontsize=8.5, ha="right", va="bottom")
span = (ymax + 1.5 + 5)
for q, (m, c) in enumerate(zip(offl, cols)):
    a1.text(tt[0] + 0.5, ymax + 0.6 - 0.075 * span * q, f"term of the mode {m['sigma']:.4f} + {m['gamma']:.2f} i", color=c, fontsize=8.5, ha="left", va="top",
            bbox={"facecolor": SURF, "edgecolor": "none", "pad": 1.0})

a2.set_title("Rate of growth, d log V / d log x = 2⟨δ⟩")
for m, c in zip(offl, cols):
    a2.axhline(2 * (m["sigma"] - 0.5), color=c, lw=1.0, ls=(0, (2, 2)))
    a2.text(tt[-1] * 0.995, 2 * (m["sigma"] - 0.5) + 0.012, f"2δ = {2 * (m['sigma'] - 0.5):.3f}", color=c, fontsize=8.5, ha="right", va="bottom")
a2.plot(tt, D["slope_combination"], color=ORANGE, lw=2.6)
a2.plot(tt, D["slope_component"], color=BLUE, lw=2.0)
for h in D["handovers"][1:]:
    a2.axvline(h["from_log_x"], color=INK2, lw=0.7, ls=":")
    a1.axvline(h["from_log_x"], color=INK2, lw=0.7, ls=":")
    a2.text(h["from_log_x"] + 0.3, 0.05, f"lead passes to\n{h['sigma']:.3f} + {h['gamma']:.1f} i\nat log x = {h['from_log_x']:.1f}", color=INK2, fontsize=7.5, va="bottom", ha="left",
            bbox={"facecolor": SURF, "edgecolor": "none", "pad": 1.5})
a2.text(xr * 0.985, 0.02, "L(s, χ): zero", color=BLUE, fontsize=8.5, ha="right", va="bottom")
a2.set_ylim(-0.03, 2 * max(m["sigma"] - 0.5 for m in offl) + 0.1)
a2.set_xlim(tt[0], tt[-1])
a2.set_xlabel("log x")
a2.set_ylabel("rate of growth")
a2.grid(axis="y", color=GRID, lw=0.8)
a2.set_axisbelow(True)
fig.savefig(os.path.join(F, "fig8_steps.png"), dpi=300, bbox_inches="tight")
fig.savefig(os.path.join(F, "fig8_steps.pdf"), bbox_inches="tight")
print("wrote figures/fig8_steps.png and .pdf")
