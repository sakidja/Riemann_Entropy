"""Riemann zeros campaign 2: three runs that follow the first campaign.
  A. Two point probe: the ramp of the zeros rebuilt from the primes alone (squared prime sum).
  B. Entropy over modes with the true weights 1/|rho_n|^2, shares measured from the variance by window.
  C. Random walk tests on the true primes: psi(x) and the Moebius sum M(x) against free walks.
Usage: python ri_campaign2.py [NMAX]     (expects zeros1 in this folder; NMAX = sieve limit, default 1e8)
"""
import json
import sys
import time
import numpy as np

GE = 0.5772156649015329
OUT = {}
T0 = time.time()


def load_table(name):
    vals = []
    with open(name) as f:
        for line in f:
            try:
                vals.append(float(line.strip()))
            except ValueError:
                pass
    return np.array(vals)


def smooth_count(g):
    return (g / (2 * np.pi)) * np.log(g / (2 * np.pi * np.e)) + 7.0 / 8.0


def rotor_sum(gam, t, chunk=400):
    f = np.zeros(len(t))
    for i in range(0, len(gam), chunk):
        gg = gam[i:i + chunk]
        f += 2.0 * np.real(np.exp(1j * np.outer(gg, t)) / (0.5 + 1j * gg)[:, None]).sum(axis=0)
    return f


def section(title):
    print()
    print("=" * 78)
    print(title)
    print("=" * 78)
    sys.stdout.flush()


def primes_upto(n):
    s = np.ones(n + 1, dtype=bool)
    s[:2] = False
    for i in range(2, int(n ** 0.5) + 1):
        if s[i]:
            s[i * i::i] = False
    return np.nonzero(s)[0]


g_all = load_table("zeros1")
print(f"loaded {len(g_all)} zeros from zeros1, last = {g_all[-1]:.3f}")

# ---------------------------------------------------------------- A. two point probe
section("A. TWO POINT PROBE: the ramp of the zeros rebuilt from the primes alone")
print("Measured: power of the complex amplitude of the zeros, blocks of 200, as in campaign 1.")
print("Predicted: squared prime sum (diagonal terms), no zeros used:")
print("   K(bin) = sum over prime powers with k log p / L in the bin of (log p)^2 / p^k, divided by L^2 * width,")
print("   L = log(E / 2 pi) at the height E of the block.  The unitary ramp is K = tau.")
w_all = smooth_count(g_all)
B = 200
SKIP = 5                       # first 5 blocks (zeros 1 to 1000) left out: L changes too fast inside a block
tau = np.arange(0.0025, 1.5, 0.0025)
dt = tau[1] - tau[0]
hann = 0.5 - 0.5 * np.cos(2 * np.pi * (np.arange(B) + 0.5) / B)
blocks = list(range(SKIP * B, len(g_all) - B + 1, B))
Lmax = np.log(g_all[-1] / (2 * np.pi))
pmax = int(np.exp(1.5 * Lmax)) + 10
pr = primes_upto(pmax)
logs, wts = [], []
for p in pr:
    lp = np.log(p)
    k = 1
    while k * lp <= 1.5 * Lmax:
        logs.append(k * lp)
        wts.append(lp * lp / float(p) ** k)
        k += 1
logs = np.array(logs)
wts = np.array(wts)
order = np.argsort(logs)
logs, wts = logs[order], wts[order]
cw = np.concatenate([[0.0], np.cumsum(wts)])
print(f"{len(blocks)} blocks (zeros {SKIP * B + 1} to {blocks[-1] + B}); {len(pr)} primes up to {pmax}, {len(logs)} prime powers")


def run_probe(edges):
    Kraw = np.zeros(len(tau))
    Ktap = np.zeros(len(tau))
    pred = np.zeros(len(edges) - 1)
    for i in blocks:
        ph = np.exp(2j * np.pi * np.outer(tau, w_all[i:i + B]))
        Kraw += np.abs(ph.sum(axis=1)) ** 2 / B
        Ktap += np.abs((ph * hann).sum(axis=1)) ** 2 / np.sum(hann ** 2)
        L = np.log(0.5 * (g_all[i] + g_all[i + B - 1]) / (2 * np.pi))
        for j, (a, b) in enumerate(zip(edges[:-1], edges[1:])):
            s = cw[np.searchsorted(logs, b * L)] - cw[np.searchsorted(logs, a * L)]
            pred[j] += s / (L * L * (b - a))
    nb = len(blocks)
    rows = []
    for j, (a, b) in enumerate(zip(edges[:-1], edges[1:])):
        m = (tau >= a) & (tau < b)
        rows.append([a, b, Kraw[m].mean() / nb, Ktap[m].mean() / nb, pred[j] / nb, min(0.5 * (a + b), 1.0)])
    return rows


print("\nBins of campaign 1 (sharp = blocks cut sharply, as in campaign 1; tapered = Hann taper on each block)")
print("     tau         zeros sharp  zeros tapered  from primes   unitary ramp")
rows = run_probe([0.05, 0.15, 0.25, 0.35, 0.5, 0.7, 0.9, 1.1, 1.5])
for a, b, kr, kt, pp, rr in rows:
    print(f"  {a:4.2f} to {b:4.2f} {kr:12.4f} {kt:13.4f} {pp:13.4f} {rr:13.3f}")
OUT["probe_coarse"] = rows
print("The diagonal prime sum is valid below tau = 1.  Above it the sum keeps rising and the zeros level off.")
print("The sharp cut adds about 1/(2 pi^2 tau^2 B) at small tau; the taper removes it.")

print("\nFine bins of width 0.05, tapered blocks")
print("     tau         zeros     from primes   unitary ramp   zeros - ramp   primes - ramp")
fine = run_probe(list(np.round(np.arange(0.05, 1.0001, 0.05), 2)))
dz, dp = [], []
for a, b, kr, kt, pp, rr in fine:
    c = 0.5 * (a + b)
    dz.append(kt - c)
    dp.append(pp - c)
    print(f"  {a:4.2f} to {b:4.2f} {kt:10.4f} {pp:12.4f} {c:12.3f} {kt - c:14.4f} {pp - c:14.4f}")
dz, dp = np.array(dz), np.array(dp)
OUT["probe_fine"] = fine
for hi, lab in [(0.8, "bins below tau = 0.80"), (1.0, "all bins below tau = 1.00")]:
    m = np.array([r[1] <= hi + 1e-9 for r in fine])
    cc = np.corrcoef(dz[m], dp[m])[0, 1]
    rms = np.sqrt(np.mean((dz[m] - dp[m]) ** 2))
    print(f"{lab}: correlation of the two departures from the ramp = {cc:6.3f}; rms(zeros - primes) = {rms:.4f}; "
          f"rms(zeros - ramp) = {np.sqrt(np.mean(dz[m] ** 2)):.4f}")
    OUT["probe_" + lab] = [float(cc), float(rms)]
print(f"[{time.time() - T0:.0f} s]")

# ---------------------------------------------------------------- B. entropy with true weights
section("B. ENTROPY OVER MODES with the true weights a_n = 1/|rho_n|^2")
print("Shares on the line: p_n = a_n / sum a_m, constant in log x.  One mode m moved off the line by delta:")
print("   p_m(t) = a_m e^(2 delta t) / (S - a_m + a_m e^(2 delta t)),   half at t* = log((S - a_m)/a_m) / (2 delta).")
print("Measured share of the moved mode = (Var_moved - Var_line + 2 a_m) / Var_moved, from the variance by window.")
a_all = 1.0 / (0.25 + g_all ** 2)
S = a_all.sum()
p0 = a_all / S
H0 = -np.sum(p0 * np.log(p0))
print(f"N = {len(g_all)}: 2 S = {2 * S:.6f}; entropy on the line H0 = {H0:.4f} (log N = {np.log(len(g_all)):.4f}); "
      f"share of zero 1 on the line = {p0[0]:.4f}")
WINDOWS = [(6, 9), (9, 12), (12, 15), (15, 18), (18, 21), (21, 24), (24, 27), (27, 30)]
f0s = {}
for lo, hi in WINDOWS:
    t = np.linspace(lo, hi, 6000)
    f0s[(lo, hi)] = (t, rotor_sum(g_all, t))
print(f"[{time.time() - T0:.0f} s]")
OUT["entropy"] = {"H0": float(H0), "cases": []}


def entropy_with_share(m, pm):
    """entropy when mode m has share pm and the others keep their relative weights"""
    rest = np.delete(p0, m)
    rest = rest / rest.sum() * (1 - pm)
    rest = rest[rest > 0]
    h = -np.sum(rest * np.log(rest))
    if 0 < pm < 1:
        h += -pm * np.log(pm)
    return h


for m in [0, 9, 99]:
    for d in [0.05, 0.10, 0.20]:
        am = a_all[m]
        tstar = np.log((S - am) / am) / (2 * d)
        print(f"\nzero {m + 1} (gamma = {g_all[m]:.3f}, share on the line {p0[m]:.5f}), delta = {d:.2f}, predicted t* = {tstar:.2f}")
        print("  window    Var line   Var moved   share measured   share predicted   entropy measured   entropy predicted")
        case = {"zero": m + 1, "delta": d, "tstar": float(tstar), "rows": []}
        for lo, hi in WINDOWS:
            t, f0 = f0s[(lo, hi)]
            rho = 0.5 + 1j * g_all[m]
            base = 2.0 * np.real(np.exp(1j * g_all[m] * t) / rho)
            pert = 2.0 * np.real(np.exp((d + 1j * g_all[m]) * t) / (rho + d))
            v0 = f0.var()
            v1 = (f0 - base + pert).var()
            sm = (v1 - v0 + 2 * am) / v1
            sm = min(max(sm, 1e-12), 1 - 1e-12)
            em = am * (np.exp(2 * d * hi) - np.exp(2 * d * lo)) / (2 * d * (hi - lo))
            sp = em / (S - am + em)
            hm, hp = entropy_with_share(m, sm), entropy_with_share(m, sp)
            print(f"  [{lo:2d},{hi:2d}] {v0:10.5f} {v1:11.5f} {sm:13.4f} {sp:17.4f} {hm:17.4f} {hp:18.4f}")
            case["rows"].append([lo, hi, float(v0), float(v1), float(sm), float(sp), float(hm), float(hp)])
        OUT["entropy"]["cases"].append(case)
print(f"[{time.time() - T0:.0f} s]")

# ---------------------------------------------------------------- C. random walk
section("C. RANDOM WALK TESTS on the true primes (sieve, no zeros used)")
NMAX = int(float(sys.argv[1])) if len(sys.argv) > 1 else 10 ** 8
tmax = np.log(NMAX)
WIN = [(lo, lo + 3) for lo in range(6, int(tmax) - 2, 3)]
if WIN[-1][1] < tmax - 0.5:
    WIN.append((WIN[-1][1], float(np.floor(tmax * 10) / 10)))
print(f"sieve limit {NMAX:.3g}, log = {tmax:.2f}; windows in log x: {WIN}")
rng = np.random.default_rng(20261105)
NS = 200000


def sample_points(lo, hi):
    t = rng.uniform(lo, hi, NS)
    x = np.exp(t)
    return x, np.minimum(x.astype(np.int64), NMAX)


isp = np.ones(NMAX + 1, dtype=bool)
isp[:2] = False
for i in range(2, int(NMAX ** 0.5) + 1):
    if isp[i]:
        isp[i * i::i] = False
plist = np.nonzero(isp)[0]
print(f"{len(plist)} primes   [{time.time() - T0:.0f} s]")
sys.stdout.flush()

# C1. psi(x): true primes against random primes (each n prime with probability 1/log n)
lam = np.zeros(NMAX + 1, dtype=np.float32)
lam[plist] = np.log(plist)
for p in plist[plist <= int(NMAX ** 0.5)]:
    q = int(p) * int(p)
    lp = np.float32(np.log(p))
    while q <= NMAX:
        lam[q] = lp
        q *= int(p)
psi = np.cumsum(lam, dtype=np.float64)
del lam
pts = [sample_points(lo, hi) for lo, hi in WIN]
const = 2 + GE - np.log(4 * np.pi)
print("\nC1. Scaled prime fluctuation (psi(x) - x)/sqrt(x), sampled uniformly in log x")
print(f"    closed form for the variance, all zeros on the line: {const:.6f}")
true_rows = []
for (lo, hi), (x, ix) in zip(WIN, pts):
    f = (psi[ix] - x) / np.sqrt(x)
    true_rows.append([lo, hi, float(f.mean()), float(f.var()), float(np.abs(f).max())])
del psi
NR = 10
rand_var = np.zeros((NR, len(WIN)))
rand_max = np.zeros((NR, len(WIN)))
logn = np.log(np.maximum(np.arange(NMAX + 1, dtype=np.float32), 2))
for r in range(NR):
    hit = rng.random(NMAX + 1, dtype=np.float32) < 1.0 / logn
    hit[:2] = False
    walk = np.cumsum(np.where(hit, logn, np.float32(0)), dtype=np.float64)
    for j, (x, ix) in enumerate(pts):
        f = (walk[ix] - (x - 1.0)) / np.sqrt(x)          # x - 1 = expected value of the random sum
        rand_var[r, j] = np.mean(f ** 2)
        rand_max[r, j] = np.abs(f).max()
    del hit, walk
del logn
print(f"    window     mean      variance   largest |f|  |  random primes ({NR} runs): mean square   expected   largest |f|")
for j, (lo, hi, mu_, va, mx) in enumerate(true_rows):
    print(f"    [{lo:4.1f},{hi:4.1f}] {mu_:8.4f} {va:11.5f} {mx:10.4f}    | {rand_var[:, j].mean():26.3f} {0.5 * (lo + hi) - 2:12.2f} {rand_max[:, j].mean():11.3f}")
tv = np.array([r[3] for r in true_rows])
print(f"    true primes: mean of the variance over windows {tv.mean():.5f}, spread {tv.std():.5f}")
JF = max(j for j, (lo, hi) in enumerate(WIN) if hi - lo == 3)
print("    For random primes the expected mean square is log x - 2: it grows with the window. The true primes stay at one value.")
print(f"    ratio random / true in the last full window: {rand_var[:, JF].mean() / true_rows[JF][3]:.0f}")
OUT["psi_walk"] = {"true": true_rows, "random_var": rand_var.tolist(), "random_max": rand_max.tolist()}
print(f"[{time.time() - T0:.0f} s]")
sys.stdout.flush()

# C2. Moebius sum: true signs against random signs on the same squarefree integers
mu = np.ones(NMAX + 1, dtype=np.int8)
logsum = np.zeros(NMAX + 1, dtype=np.float32)
for p in plist[plist <= int(NMAX ** 0.5)]:
    p = int(p)
    mu[p::p] *= -1
    mu[p * p::p * p] = 0
    logsum[p::p] += np.float32(np.log(p))
big = logsum < np.log(np.maximum(np.arange(NMAX + 1, dtype=np.float32), 1)) - 0.5   # one prime factor above sqrt(NMAX) remains
mu[big] *= -1
del logsum, big
mu[0] = 0
M = np.cumsum(mu, dtype=np.int64)
sqf = (mu != 0)
print(f"\nC2. Moebius sum M(x)/sqrt(x), sampled uniformly in log x.  M({NMAX:.3g}) = {M[NMAX]}; "
      f"squarefree fraction {sqf.mean():.5f} (6/pi^2 = {6 / np.pi ** 2:.5f})")
true_rows = []
for (lo, hi), (x, ix) in zip(WIN, pts):
    f = M[ix] / np.sqrt(x)
    true_rows.append([lo, hi, float(f.mean()), float(f.var()), float(np.abs(f).max())])
overall = float(np.max(np.abs(M[400:]) / np.sqrt(np.arange(400, NMAX + 1))))
del M, mu
rand_var = np.zeros((NR, len(WIN)))
rand_max = np.zeros((NR, len(WIN)))
for r in range(NR):
    sg = (rng.integers(0, 2, NMAX + 1, dtype=np.int8) * 2 - 1) * sqf
    W = np.cumsum(sg, dtype=np.int64)
    for j, (x, ix) in enumerate(pts):
        f = W[ix] / np.sqrt(x)
        rand_var[r, j] = np.mean(f ** 2)
        rand_max[r, j] = np.abs(f).max()
    del sg, W
print(f"    window     mean      variance   largest |f|  |  random signs ({NR} runs): mean square   expected   largest |f|")
for j, (lo, hi, mu_, va, mx) in enumerate(true_rows):
    print(f"    [{lo:4.1f},{hi:4.1f}] {mu_:8.4f} {va:11.5f} {mx:10.4f}    | {rand_var[:, j].mean():25.3f} {6 / np.pi ** 2:12.3f} {rand_max[:, j].mean():11.3f}")
tv = np.array([r[3] for r in true_rows])
print(f"    true Moebius: mean of the variance over windows {tv.mean():.5f}, spread {tv.std():.5f}; "
      f"largest |M(x)|/sqrt(x) for 400 <= x <= {NMAX:.3g}: {overall:.4f}")
print(f"    A free walk on the squarefree integers has mean square 6/pi^2 = {6 / np.pi ** 2:.4f} in every window.")
OUT["moebius_walk"] = {"true": true_rows, "random_var": rand_var.tolist(), "random_max": rand_max.tolist(), "max_abs": overall}

with open("ri_campaign2_results.json", "w") as fjs:
    json.dump(OUT, fjs, indent=1, default=float)
print(f"\nwrote ri_campaign2_results.json   [{time.time() - T0:.0f} s]")
