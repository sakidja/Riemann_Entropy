"""The pair correlation of the zeros, measured, against the unitary class (free fermions) and no stiffness.

Reads   zeros1                        Odlyzko's table of the first 100,000 zeros (the table ri_campaign.py reads)
Writes  ri_paircorr_results.json      the measured pair correlation in bins of u, and the two reference curves
        figures/fig_paircorr.png and .pdf

Method. The zeros are unfolded with the smooth count of zeros, the same as in ri_campaign.py,
   w = (gamma / 2 pi) log(gamma / 2 pi e) + 7/8,
so that the mean spacing is 1. For every zero the other zeros at a separation u = w_j - w_i with 0 < u <= UMAX
are counted in bins of width DU. With N zeros and density 1 the count expected in a bin without any correlation
is N x DU, so
   R2(u) = count / (N x DU)
and the error on a bin is sqrt(count) / (N x DU); an empty bin is given the error of one count. Zeros within UMAX of the top of the table are not used as
the first of a pair, so that no pair is lost at the edge.
Reference curves:
   unitary class, the same function as free fermions in one dimension at zero temperature:  1 - (sin(pi u) / (pi u))^2
   no stiffness (independent points):                                                       1

Usage:  python ri_paircorr.py          (a few seconds, no job needed)
"""
import json
import os
import sys
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE = os.path.dirname(os.path.abspath(__file__))
FLAT = os.path.exists(os.path.join(HERE, "ri_dh_results.json"))      # on Perlmutter the scripts and the results share one folder
R = HERE if FLAT else os.path.join(HERE, "..", "results")
F = os.path.join(HERE, "figures") if FLAT else os.path.join(HERE, "..", "figures")
os.makedirs(F, exist_ok=True)
TABLE = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, "zeros1")
UMAX, DU = 3.0, 0.05


def load_table(name):
    vals = []
    with open(name) as f:
        for line in f:
            try:
                vals.append(float(line.strip()))
            except ValueError:
                pass
    return np.array(vals)


def smooth_count(g):
    return (g / (2 * np.pi)) * np.log(g / (2 * np.pi * np.e)) + 7.0 / 8.0


def unitary(u):
    u = np.asarray(u, dtype=float)
    return 1.0 - np.sinc(u) ** 2            # np.sinc(u) = sin(pi u) / (pi u)


if not os.path.exists(TABLE):
    sys.exit(f"the table of zeros was not found: {TABLE}\nusage: python ri_paircorr.py [path to zeros1]")
g = load_table(TABLE)
w = smooth_count(g)
print(f"loaded {len(g)} zeros from {os.path.basename(TABLE)}, last = {g[-1]:.3f}")
print(f"unfolded: mean spacing = {np.diff(w).mean():.5f}")

first = w[w < w[-1] - UMAX]                 # zeros used as the first of a pair
N = len(first)
edges = np.arange(0.0, UMAX + 0.5 * DU, DU)
cum = np.array([np.sum(np.searchsorted(w, first + e, side="right")) for e in edges], dtype=float)
count = np.diff(cum)
u = 0.5 * (edges[:-1] + edges[1:])
R2 = count / (N * DU)
err = np.sqrt(np.maximum(count, 1.0)) / (N * DU)        # an empty bin is given the error of one count
# the formula averaged over each bin, for the comparison with the measured bins
fine = np.linspace(0, UMAX, int(round(UMAX / DU)) * 200 + 1)
uni_bin = np.array([unitary(fine[(fine >= a) & (fine <= b)]).mean() for a, b in zip(edges[:-1], edges[1:])])

print(f"\n{N} zeros used as the first of a pair, bins of width {DU}")
print("pair correlation R2(u): zeros, unitary class (free fermions), no stiffness")
print("     u       zeros      error    unitary   no stiffness   (zeros - unitary) / error")
for k in range(len(u)):
    if k % 2 == 1 or u[k] < 0.3:
        print(f"  {u[k]:5.3f}   {R2[k]:8.4f}   {err[k]:7.4f}   {uni_bin[k]:8.4f}   {1.0:8.1f}   {(R2[k] - uni_bin[k]) / err[k]:12.2f}")
m = u < 1.0
print(f"\nmean of |zeros - unitary| over all bins: {np.mean(np.abs(R2 - uni_bin)):.4f}")
print(f"mean of |zeros - no stiffness| over all bins: {np.mean(np.abs(R2 - 1.0)):.4f}")
print(f"pairs missing below u = 1 against no stiffness (the hole): zeros {np.sum(1 - R2[m]) * DU:.4f}, unitary {np.sum(1 - uni_bin[m]) * DU:.4f}")

OUT = {"table": os.path.basename(TABLE), "n_zeros": int(len(g)), "n_first": int(N), "umax": UMAX, "du": DU,
       "u": u.tolist(), "R2": R2.tolist(), "err": err.tolist(), "unitary_bin": uni_bin.tolist(),
       "curve_u": fine.tolist(), "curve_unitary": unitary(fine).tolist()}
with open(os.path.join(R, "ri_paircorr_results.json"), "w") as f:
    json.dump(OUT, f)
print("\nwrote ri_paircorr_results.json")

# ---------------------------------------------------------------- the figure, drawn from the file just written
with open(os.path.join(R, "ri_paircorr_results.json")) as f:
    D = json.load(f)
BLUE, ORANGE = "#2a78d6", "#eb6834"
INK, INK2, GRID, SURF = "#0b0b0b", "#52514e", "#e4e3df", "#fcfcfb"
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9, "axes.edgecolor": INK2, "axes.labelcolor": INK,
                     "xtick.color": INK2, "ytick.color": INK2, "axes.spines.top": False, "axes.spines.right": False,
                     "axes.linewidth": 0.8, "figure.facecolor": SURF, "axes.facecolor": SURF, "savefig.facecolor": SURF,
                     "axes.titlesize": 10, "axes.titleweight": "bold", "axes.titlelocation": "left", "mathtext.fontset": "dejavusans"})
fig, a = plt.subplots(figsize=(7.0, 4.2))
fig.suptitle("The pair correlation of the zeros", x=0.02, ha="left", fontsize=11, fontweight="bold", y=0.985)
a.set_title(f"First {D['n_zeros']:,} zeros, unfolded to mean spacing 1, bins of {D['du']}")
a.axhline(1.0, color=INK2, lw=1.0, ls=":")
a.plot(D["curve_u"], D["curve_unitary"], color=BLUE, lw=1.8, zorder=3)
a.errorbar(D["u"], D["R2"], yerr=D["err"], fmt="o", color=ORANGE, ms=4.2, mec=SURF, mew=0.6, ecolor=ORANGE, elinewidth=0.9,
           capsize=0, zorder=5)
a.text(1.25, 0.52, "zeros (measured)", color=ORANGE, fontsize=8.5, ha="left", fontweight="bold")
a.text(1.25, 0.42, r"unitary class, free fermions:  $1-\left(\frac{\sin \pi u}{\pi u}\right)^{2}$", color=BLUE, fontsize=8.5,
       ha="left", fontweight="bold")
a.text(1.25, 0.32, "no stiffness: 1 at every u (dotted)", color=INK2, fontsize=8.5, ha="left")
a.set_xlim(0, D["umax"])
a.set_ylim(0, 1.25)
a.set_xlabel("separation of two zeros, u, in units of the mean spacing")
a.set_ylabel("pair correlation")
a.grid(axis="y", color=GRID, lw=0.8)
a.set_axisbelow(True)
fig.savefig(os.path.join(F, "fig_paircorr.png"), dpi=300, bbox_inches="tight")
fig.savefig(os.path.join(F, "fig_paircorr.pdf"), bbox_inches="tight")
plt.close(fig)
print("wrote figures/fig_paircorr.png and .pdf")
