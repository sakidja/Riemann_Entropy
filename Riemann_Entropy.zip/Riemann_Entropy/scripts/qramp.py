import sys
import numpy as np
from qiskit import QuantumCircuit
from qiskit.circuit.library import UnitaryGate
from qiskit.quantum_info import Statevector

NQ = 8                       # system qubits per block: 2**NQ zeros
NB = 2 ** NQ
SHOTS = 20000
rng = np.random.default_rng(7)

g = np.load("gammas.npy")
w = (g / (2 * np.pi)) * np.log(g / (2 * np.pi * np.e)) + 7.0 / 8.0   # unfolded zeros
blocks = [w[i:i + NB] for i in range(0, len(w) - NB + 1, NB)]


def ancilla_readout(ww, tau, pauli):
    """Hadamard test on U = diag(exp(2 pi i tau w_n)). pauli 'X' gives Re<U>, 'Y' gives Im<U>."""
    qc = QuantumCircuit(NQ + 1)
    anc = NQ
    qc.h(range(NQ))                      # equal weight on every zero
    qc.h(anc)
    ph = np.concatenate([np.ones(NB), np.exp(2j * np.pi * tau * ww)])
    qc.append(UnitaryGate(np.diag(ph)), range(NQ + 1))     # controlled U
    if pauli == "Y":
        qc.sdg(anc)
    qc.h(anc)
    p0 = Statevector(qc).probabilities([anc])[0]
    exact = 2 * p0 - 1
    samp = 2 * rng.binomial(SHOTS, p0) / SHOTS - 1
    return exact, samp


edges = [0.05, 0.15, 0.25, 0.35, 0.5, 0.7, 0.9, 1.1, 1.5, 2.0, 2.5]
PER_BIN = int(sys.argv[1]) if len(sys.argv) > 1 else 20     # tau points per bin
print(f"{len(blocks)} blocks of {NB} zeros, {NQ} system qubits + 1 ancilla, {SHOTS} shots per Pauli")
print("power of the sensed complex number, n * (<X>^2 + <Y>^2), averaged in bins of tau")
print("   tau      exact    sampled   no stiffness   unitary ramp")
for a, b in zip(edges[:-1], edges[1:]):
    ex, sa = [], []
    for tau in np.linspace(a, b, PER_BIN, endpoint=False):
        for ww in blocks:
            xe, xs = ancilla_readout(ww, tau, "X")
            ye, ys = ancilla_readout(ww, tau, "Y")
            ex.append(NB * (xe ** 2 + ye ** 2))
            # remove the shot noise floor from the squared estimates
            sa.append(NB * (xs ** 2 + ys ** 2 - (2 - xs ** 2 - ys ** 2) / (SHOTS - 1)))
    c = 0.5 * (a + b)
    print(f"{a:4.2f}-{b:4.2f} {np.mean(ex):8.4f} {np.mean(sa):9.4f} {1.0:10.1f} {min(c, 1.0):13.3f}")
