"""Numbers quoted in the text of the paper that are sums, means, ratios or counts taken from the job outputs.
No new computation on zeros or primes: this script only reads the result files of campaigns 1 to 4
(ri_campaign_results.json, ri_campaign2_results.json, ri_dh_results.json, ri_lpair_results.json) and prints each number.
Usage: python ri_derived.py
"""
import json
import os
import sys
import numpy as np


def load(name):
    for d in (".", os.path.join("..", "results")):
        p = os.path.join(d, name)
        if os.path.exists(p):
            with open(p) as f:
                return json.load(f)
    sys.exit(f"{name} not found in this folder or in ../results")


c1, c2, dh, lp = load("ri_campaign_results.json"), load("ri_campaign2_results.json"), load("ri_dh_results.json"), load("ri_lpair_results.json")
CLOSED = 2 + 0.5772156649015329 - np.log(4 * np.pi)

print("Section 3, invariant (campaign 1, part 1)")
for N in ("1000", "10000", "100000"):
    v = np.array([r[0] for r in c1["invariant"][N]["rows"]])
    print(f"   N = {N:>6s}: mean of the variance on the line over the eight windows {v.mean():.5f}, spread {v.std():.5f};  "
          f"2 sum 1/|rho|^2 over these zeros {c1['invariant'][N]['partial_sum']:.6f};  closed form {CLOSED:.6f}")
r = np.array(c1["invariant"]["100000"]["rows"])
print(f"   one mode with delta = 0.20: variance in the last window over the variance on the line = {r[-1, 3] / r[-1, 0]:.0f}")

print("\nSection 3, share of the moved mode (campaign 2, part B): measured against predicted")
d = np.array([abs(row[4] - row[5]) for case in c2["entropy"]["cases"] for row in case["rows"]])
print(f"   {len(d)} windows in {len(c2['entropy']['cases'])} cases: within 0.01 in {int((d <= 0.01).sum())}, largest difference {d.max():.3f}")
for case in c2["entropy"]["cases"]:
    cross = [f"[{int(row[0])},{int(row[1])}]" for row in case["rows"] if row[0] <= case["tstar"] < row[1]]
    below = [row for row in case["rows"] if row[4] < 0.5]
    above = [row for row in case["rows"] if row[4] >= 0.5]
    where = (f"measured share passes one half between [{int(below[-1][0])},{int(below[-1][1])}] and [{int(above[0][0])},{int(above[0][1])}]"
             if below and above else ("measured share above one half in every window" if above else "measured share below one half in every window"))
    print(f"   zero {case['zero']:3d}, delta = {case['delta']:.2f}: t* = {case['tstar']:6.2f}, in window {cross[0] if cross else 'outside 6 to 30'};  {where}")

print("\nSection 3, random walk (campaign 2, part C)")
tp, rv = np.array(c2["psi_walk"]["true"]), np.mean(np.array(c2["psi_walk"]["random_var"]), axis=0)
print(f"   true primes: mean of the variance over the windows {tp[:, 3].mean():.5f}, spread {tp[:, 3].std():.5f}")
print("   random primes over true primes, by window: " + "  ".join(f"{a / b:.0f}" for a, b in zip(rv, tp[:, 3])))
tm, rm = np.array(c2["moebius_walk"]["true"]), np.mean(np.array(c2["moebius_walk"]["random_var"]), axis=0)
print(f"   Moebius sum: mean of the variance over the windows {tm[:, 3].mean():.5f}, spread {tm[:, 3].std():.5f};  6/pi^2 over that mean = {6 / np.pi ** 2 / tm[:, 3].mean():.1f}")
print("   random signs over true Moebius, by window: " + "  ".join(f"{a / b:.0f}" for a, b in zip(rm, tm[:, 3])))
print(f"   largest |f|: true primes {tp[:, 4].min():.2f} to {tp[:, 4].max():.2f};  random primes {np.mean(c2['psi_walk']['random_max'], axis=0).min():.1f} to "
      f"{np.mean(c2['psi_walk']['random_max'], axis=0).max():.1f};  random signs {np.mean(c2['moebius_walk']['random_max'], axis=0).min():.1f} to "
      f"{np.mean(c2['moebius_walk']['random_max'], axis=0).max():.1f}")

print("\nSection 5.1, spacings (campaign 1, part 3)")
s = c1["stiffness"]["all 100,000"]["spacing"]
print(f"   first 100,000 zeros, spacings below 0.10: {s[0][1]:.5f};  without stiffness {1 - np.exp(-0.1):.4f};  ratio {(1 - np.exp(-0.1)) / s[0][1]:.0f}")

print("\nSection 5.2, count variance (campaign 1, part 3): mean for L = 16, 32, 64, 128, 256 against the predicted saturation")
print("   set                         L = 1    L = 4    L = 16   L = 64   L = 256   mean 16 to 256   predicted   difference   L = 256 over the variance")
for key in ("zeros 1 to 10,000", "all 100,000", "zeros3", "zeros4", "zeros5"):
    st = c1["stiffness"][key]
    nv = {row[0]: row[1] for row in st["numvar"]}
    m = np.mean([nv[L] for L in (16, 32, 64, 128, 256)])
    print(f"   {key:26s} {nv[1]:7.3f} {nv[4]:8.3f} {nv[16]:8.3f} {nv[64]:8.3f} {nv[256]:8.3f} {m:13.3f} {st['saturation_pred']:13.3f} {m - st['saturation_pred']:11.3f} {256 / nv[256]:14.0f}")

print("\nSection 6.1, restoring force (campaign 1, part 4), N = 100,000: stiffness measured over predicted")
print("   " + "  ".join(f"zero {int(w[0])}: {w[2] / w[3]:.3f}" for w in c1["force"]["100000"]["wells"]))

print("\nSection 8, Davenport and Heilbronn (campaign 3)")
ve = np.array(dh["variance_entropy"])
n_on, n_off = len(dh["zeros"]["on_line"]), len(dh["zeros"]["off_sigma"])
print(f"   zeros: {n_on} on the line + 2 x {n_off} off = {n_on + 2 * n_off};  one in {(n_on + 2 * n_off) / (2 * n_off):.1f} is off the line;  largest sigma {max(dh['zeros']['off_sigma']):.6f}")
print(f"   variance, last window over first window: {ve[-1, 3] / ve[0, 3]:.0f}")
dd = np.abs(ve[:, 4] - ve[:, 5])
print(f"   share off the line, measured against predicted: within 0.02 in {int((dd <= 0.02).sum())} of {len(dd)} windows, largest difference {dd.max():.3f}")
print(f"   entropy: {ve[0, 6]:.3f} in the first window, largest {ve[:, 6].max():.3f}, {ve[-1, 6]:.3f} in the last")
ar = np.array(dh["arithmetic"])
print(f"   arithmetic side over zeros, by window: " + "  ".join(f"{a / b:.3f}" for a, b in zip(ar[:, 2], ar[:, 3])) + f";  correlation {ar[:, 4].min():.3f} to {ar[:, 4].max():.3f}")

print("\nSection 8.1, the two components (campaign 4)")
v4 = np.array(lp["variance_entropy"])
print(f"   variance of a component by window: {v4[:, 2].min():.3f} to {v4[:, 2].max():.3f};  closed form {lp['invariant']['closed_form']:.6f};  "
      f"zero sum {lp['invariant']['zero_sum']:.6f} + tail {lp['invariant']['tail']:.6f} = {lp['invariant']['zero_sum'] + lp['invariant']['tail']:.6f}")
print(f"   entropy of a component: {v4[:, 3].min():.4f} to {v4[:, 3].max():.4f};  combination, both signs: {v4[0, 7]:.3f} to {v4[-1, 7]:.3f}")
p4 = np.array(lp["primes"])
print(f"   primes over zeros, by window: " + "  ".join(f"{a / b:.3f}" for a, b in zip(p4[:, 2], p4[:, 3])) + f";  correlation {p4[:, 4].min():.3f} to {p4[:, 4].max():.3f}")
print(f"   pair statistics: {lp['pairs']['blocks']} blocks, L = {lp['pairs']['L'][0]:.2f} to {lp['pairs']['L'][1]:.2f};  against the primes {lp['pairs']['chi2_primes']:.2f}, against the ramp {lp['pairs']['chi2_ramp']:.2f}")
