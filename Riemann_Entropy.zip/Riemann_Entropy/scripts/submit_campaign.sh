#!/bin/bash
#SBATCH -A m4675
#SBATCH -C cpu
#SBATCH -q debug
#SBATCH -N 1
#SBATCH -t 00:30:00
#SBATCH -J ri_campaign
#SBATCH -o ri_campaign_%j.out
#SBATCH -e ri_campaign_%j.err

module load python
source $SCRATCH/qiskit-env/bin/activate
cd "$SLURM_SUBMIT_DIR"

echo "===== ri_campaign.py ====="
python ri_campaign.py
echo
echo "===== qramp.py, 100 tau points per bin ====="
python qramp.py 100
