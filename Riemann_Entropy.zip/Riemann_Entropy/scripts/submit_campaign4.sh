#!/bin/bash
#SBATCH -A m4675
#SBATCH -C cpu
#SBATCH -q debug
#SBATCH -N 1
#SBATCH -t 00:30:00
#SBATCH -J ri_campaign4
#SBATCH -o ri_campaign4_%j.out
#SBATCH -e ri_campaign4_%j.err

module load python
source $SCRATCH/qiskit-env/bin/activate
cd /pscratch/sd/r/rsakidja/quantum/SU2/RI

echo "===== ri_lpair.py, zeros up to T = 2000, primes to 1e6 ====="
python ri_lpair.py 2000 1e6
