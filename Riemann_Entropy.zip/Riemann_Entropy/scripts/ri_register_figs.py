"""Figures 10 and 11 (the ramp, the entropy): the quantum register of Section 7, drawn from the job outputs.

Reads   ri_campaign5_<job>.out   table printed by qtest1.py: one mode off the line by delta (Table 17)
        ri_campaign_<job>.out    table printed by qramp.py: the power from X and Y in bins of tau (Table 16)
Writes  ri_register_figs_results.json   the numbers read from the two outputs, and the curves of the theorem
        figures/fig11_register_entropy.png and .pdf
        figures/fig10_register_ramp.png and .pdf

Points are the values the jobs printed. The curves in Figure 10 are the entropy theorem of Section 1 for
N modes of equal amplitude with one mode at delta:
   p_1(t) = e^(2 delta t) / (N - 1 + e^(2 delta t)),   the other N - 1 modes share the rest equally
   H(t)   = - p_1 log p_1 - (1 - p_1) log((1 - p_1) / (N - 1))
   P(t)   = (N - 1 + e^(2 delta t)) / (N e^(2 delta t))        success probability of the post selection
   t*     = log(N - 1) / (2 delta)                             where p_1 = 1/2
Nothing else is computed here.

Usage:  python ri_register_figs.py        (a second, no job needed)
"""
import glob
import json
import os
import re
import sys
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE = os.path.dirname(os.path.abspath(__file__))
FLAT = os.path.exists(os.path.join(HERE, "ri_dh_results.json"))      # on Perlmutter the scripts and the results share one folder
R = HERE if FLAT else os.path.join(HERE, "..", "results")
F = os.path.join(HERE, "figures") if FLAT else os.path.join(HERE, "..", "figures")
os.makedirs(F, exist_ok=True)
N = 256


def find_table(pattern, header):
    """the lines that follow `header` in the newest output file that holds it"""
    files = sorted(glob.glob(os.path.join(R, pattern)), key=os.path.getmtime, reverse=True)
    for fn in files:
        with open(fn) as f:
            lines = f.read().split("\n")
        for i, l in enumerate(lines):
            if header in l:
                return os.path.basename(fn), lines[i + 1:]
    sys.exit(f"no file {pattern} in {os.path.normpath(R)} holds the line '{header}'")


# ---- Table 17: one mode off the line
f16, body = find_table("ri_campaign5_*.out", "one mode off the line by delta")
rows16 = []
for l in body[1:]:
    p = l.split()
    if len(p) != 4:
        break
    rows16.append([float(x) for x in p])
rows16 = np.array(rows16)
print(f"Table 17 from {f16}: {len(rows16)} rows, delta = {sorted(set(rows16[:, 0]))}, log x = {sorted(set(rows16[:, 1]))}")

# ---- Table 16: the power from X and Y
f15, body = find_table("ri_campaign_[0-9]*.out", "power of the sensed complex number")
rows15 = []
for l in body[1:]:
    m = re.match(r"\s*([0-9.]+)-([0-9.]+)\s+([0-9.]+)\s+([0-9.]+)\s+([0-9.]+)\s+([0-9.]+)", l)
    if not m:
        break
    rows15.append([float(x) for x in m.groups()])
rows15 = np.array(rows15)
print(f"Table 16 from {f15}: {len(rows15)} bins of tau")


def theorem(delta, t):
    e = np.exp(2 * delta * t)
    p1 = e / (N - 1 + e)
    q = np.clip(1 - p1, 1e-300, 1)
    H = -p1 * np.log(p1) - q * np.log(q / (N - 1))
    P = (N - 1 + e) / (N * e)
    return H, P


tt = np.linspace(0, 26, 521)
deltas = sorted(set(rows16[:, 0]))
print("\ncheck of the printed values against the theorem")
print(" delta   log x   entropy: job    theorem     success: job     theorem")
worst = 0.0
for d, t, ps, H in rows16:
    Ht, Pt = theorem(d, np.array([t]))
    worst = max(worst, abs(H - Ht[0]), abs(ps - Pt[0]))
    print(f"  {d:.2f}   {t:5.1f}   {H:12.4f}   {Ht[0]:8.4f}   {ps:14.6f}   {Pt[0]:10.6f}")
print(f" largest difference: {worst:.1e}")

OUT = {"N": N, "table16": {"file": f16, "columns": ["delta", "log_x", "p_success", "entropy"], "rows": rows16.tolist()},
       "table15": {"file": f15, "columns": ["tau_lo", "tau_hi", "exact", "sampled", "no_stiffness", "unitary_ramp"], "rows": rows15.tolist()},
       "theorem": {"t": tt.tolist(), "curves": [{"delta": d, "H": theorem(d, tt)[0].tolist(), "P": theorem(d, tt)[1].tolist(),
                                                "t_star": (float(np.log(N - 1) / (2 * d)) if d > 0 else None)} for d in deltas]}}
with open(os.path.join(R, "ri_register_figs_results.json"), "w") as f:
    json.dump(OUT, f)
print("\nwrote ri_register_figs_results.json")

# ---------------------------------------------------------------- the figures, drawn from the file just written
with open(os.path.join(R, "ri_register_figs_results.json")) as f:
    D = json.load(f)
BLUE, ORANGE, AQUA, YELLOW, VIOLET = "#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#7a5cd6"
INK, INK2, GRID, SURF = "#0b0b0b", "#52514e", "#e4e3df", "#fcfcfb"
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9, "axes.edgecolor": INK2, "axes.labelcolor": INK,
                     "xtick.color": INK2, "ytick.color": INK2, "axes.spines.top": False, "axes.spines.right": False,
                     "axes.linewidth": 0.8, "figure.facecolor": SURF, "axes.facecolor": SURF, "savefig.facecolor": SURF,
                     "axes.titlesize": 10, "axes.titleweight": "bold", "axes.titlelocation": "left"})
T16 = np.array(D["table16"]["rows"])
t = np.array(D["theorem"]["t"])
cols = [BLUE, AQUA, YELLOW, ORANGE, VIOLET]
marks = ["o", "D", "^", "s", "v"]

fig, (a1, a2) = plt.subplots(2, 1, figsize=(7.0, 6.6), sharex=True, gridspec_kw={"height_ratios": [1.25, 1], "hspace": 0.18})
fig.suptitle("One mode off the line: the register loses its entropy where the theorem says", x=0.02, ha="left", fontsize=11, fontweight="bold", y=0.975)
a1.set_title("Entropy over modes (register of 256 zeros)")
a2.set_title("Success probability of the post selection")
for k, c in enumerate(D["theorem"]["curves"]):
    d = c["delta"]
    col, mk = cols[k % len(cols)], marks[k % len(marks)]
    sel = T16[np.abs(T16[:, 0] - d) < 1e-9]
    a1.plot(t, c["H"], color=col, lw=1.8)
    a1.plot(sel[:, 1], sel[:, 3], mk, color=col, ms=6.5, mec=SURF, mew=1.0, ls="none", zorder=5)
    a2.plot(t, c["P"], color=col, lw=1.8)
    a2.plot(sel[:, 1], sel[:, 2], mk, color=col, ms=6.5, mec=SURF, mew=1.0, ls="none", zorder=5)
    lab = "δ = 0, on the line" if d == 0 else f"δ = {d:.2f}"
    a2.text(t[-1] + 0.3, max(c["P"][-1], 1.0 / N), lab, color=col, fontsize=8.5, va="center", ha="left", fontweight="bold")
    if c["t_star"] is not None and c["t_star"] < t[-1]:
        for a in (a1, a2):
            a.axvline(c["t_star"], color=col, lw=0.9, ls=(0, (2, 2)))
        a1.text(c["t_star"] + 0.3, 0.35, f"t* = {c['t_star']:.1f}\nfor δ = {d:.2f}", color=col, fontsize=8, va="bottom", ha="left")
a1.axhline(np.log(D["N"]), color=INK2, lw=0.7, ls=":")
a1.text(0.3, np.log(D["N"]) + 0.12, f"log {D['N']} = {np.log(D['N']):.3f}", color=INK2, fontsize=8, va="bottom")
a1.set_ylim(0, 6.2)
a1.set_ylabel("entropy over modes, H")
a1.grid(axis="y", color=GRID, lw=0.8)
a1.set_axisbelow(True)
a1.text(0.3, 0.35, "lines: the entropy theorem of Section 1\npoints: the circuit (job output)", color=INK2, fontsize=8, va="bottom", ha="left")
a2.set_yscale("log")
a2.axhline(1.0 / D["N"], color=INK2, lw=0.7, ls=":")
a2.text(0.3, 1.0 / D["N"] * 1.15, f"1/{D['N']}: the one surviving mode", color=INK2, fontsize=8, va="bottom")
a2.set_ylim(2e-3, 1.6)
a2.set_xlim(0, t[-1])
a2.set_xlabel("log x")
a2.set_ylabel("success probability")
a2.grid(axis="y", color=GRID, lw=0.8)
a2.set_axisbelow(True)
fig.savefig(os.path.join(F, "fig11_register_entropy.png"), dpi=300, bbox_inches="tight")
fig.savefig(os.path.join(F, "fig11_register_entropy.pdf"), bbox_inches="tight")
plt.close(fig)
print("wrote figures/fig11_register_entropy.png and .pdf")

T15 = np.array(D["table15"]["rows"])
xc = 0.5 * (T15[:, 0] + T15[:, 1])
xe = 0.5 * (T15[:, 1] - T15[:, 0])
fig, a = plt.subplots(figsize=(7.0, 4.2))
fig.suptitle("The ramp read from one ancilla", x=0.02, ha="left", fontsize=11, fontweight="bold", y=0.985)
a.set_title("Power N(⟨X⟩² + ⟨Y⟩²) in bins of τ, 7 blocks of 256 zeros")
tau = np.linspace(0, 2.6, 261)
a.plot(tau, np.minimum(tau, 1.0), color=INK, lw=1.6, ls=(0, (5, 2)))
a.axhline(1.0, color=INK2, lw=0.7, ls=":")
a.errorbar(xc, T15[:, 2], xerr=xe, fmt="none", ecolor=BLUE, elinewidth=2.2, alpha=0.55, zorder=3)
a.plot(xc, T15[:, 3], "o", color=ORANGE, ms=6.5, mec=SURF, mew=1.0, ls="none", zorder=5)
a.text(0.52, 0.40, "exact, bar spans the bin", color=BLUE, fontsize=8.5, ha="left", fontweight="bold")
a.text(0.52, 0.30, "sampled, 20,000 shots for each Pauli", color=ORANGE, fontsize=8.5, ha="left", fontweight="bold")
a.text(0.52, 0.20, "unitary ramp (dashed)", color=INK, fontsize=8.5, ha="left")
a.text(2.58, 0.94, "no stiffness: 1 at every τ (dotted)", color=INK2, fontsize=8, ha="right", va="top")
a.set_xlim(0, 2.6)
a.set_ylim(0, 1.3)
a.set_xlabel("τ")
a.set_ylabel("power")
a.grid(axis="y", color=GRID, lw=0.8)
a.set_axisbelow(True)
fig.savefig(os.path.join(F, "fig10_register_ramp.png"), dpi=300, bbox_inches="tight")
fig.savefig(os.path.join(F, "fig10_register_ramp.pdf"), bbox_inches="tight")
plt.close(fig)
print("wrote figures/fig10_register_ramp.png and .pdf")
