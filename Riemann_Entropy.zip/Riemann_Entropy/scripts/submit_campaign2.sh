#!/bin/bash
#SBATCH -A m4675
#SBATCH -C cpu
#SBATCH -q debug
#SBATCH -N 1
#SBATCH -t 00:30:00
#SBATCH -J ri_campaign2
#SBATCH -o ri_campaign2_%j.out
#SBATCH -e ri_campaign2_%j.err

module load python
source $SCRATCH/qiskit-env/bin/activate
cd /pscratch/sd/r/rsakidja/quantum/SU2/RI

echo "===== ri_campaign2.py, sieve to 1e9 ====="
python ri_campaign2.py 1e9
