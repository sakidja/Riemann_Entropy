#!/bin/bash
# Odlyzko's tables of zeros of the Riemann zeta function
for f in zeros1 zeros3 zeros4 zeros5; do
  wget https://www-users.cse.umn.edu/~odlyzko/zeta_tables/$f
done
