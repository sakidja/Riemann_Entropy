"""Figures of the paper.  This script only draws: every number it plots is read from a result file
written by a job (campaigns 1 to 5).  Nothing is computed here.
   Figure 1   ri_campaign_results.json, ri_campaign2_results.json, ri_dh_results.json
   Figure 2   ri_probe_height_results.json
   Figure 3   ri_dh_results.json
   Figure 4   ri_figdata_results.json
   Figure 5   ri_lpair_results.json, ri_figdata_results.json
   Figure 6   ri_figdata_arrays.npz
   Figure 7   ri_figdata_arrays.npz, ri_figdata_results.json
Usage:  python make_figures.py
   in the folder of the runs (results next to the scripts): writes ./figures
   in the repository (scripts folder): reads ../results, writes ../figures
"""
import json
import os
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE = os.path.dirname(os.path.abspath(__file__))
FLAT = os.path.exists(os.path.join(HERE, "ri_campaign_results.json"))      # on Perlmutter the scripts and the results share one folder
R = HERE if FLAT else os.path.join(HERE, "..", "results")
F = os.path.join(HERE, "figures") if FLAT else os.path.join(HERE, "..", "figures")
os.makedirs(F, exist_ok=True)
BLUE, ORANGE, AQUA, YELLOW = "#2a78d6", "#eb6834", "#1baf7a", "#eda100"
INK, INK2, GRID, SURF = "#0b0b0b", "#52514e", "#e4e3df", "#fcfcfb"
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9, "axes.edgecolor": INK2, "axes.labelcolor": INK,
                     "xtick.color": INK2, "ytick.color": INK2, "axes.spines.top": False, "axes.spines.right": False,
                     "axes.linewidth": 0.8, "figure.facecolor": SURF, "axes.facecolor": SURF, "savefig.facecolor": SURF,
                     "axes.titlesize": 10, "axes.titleweight": "bold", "axes.titlelocation": "left"})


def need(name):
    p = os.path.join(R, name)
    if not os.path.exists(p):
        raise SystemExit(f"{name} is not in {os.path.normpath(R)}. It is written by a job: see the README for the script that writes it.")
    return p


def load(name):
    with open(need(name)) as f:
        return json.load(f)


def save(fig, name):
    fig.savefig(os.path.join(F, name + ".png"), dpi=300, bbox_inches="tight")
    fig.savefig(os.path.join(F, name + ".pdf"), bbox_inches="tight")
    plt.close(fig)
    print("wrote", name)


c1, c2, ph, dh = load("ri_campaign_results.json"), load("ri_campaign2_results.json"), load("ri_probe_height_results.json"), load("ri_dh_results.json")
lp, fd = load("ri_lpair_results.json"), load("ri_figdata_results.json")
ARR = np.load(need("ri_figdata_arrays.npz"))
EW = np.array(fd["entropy_by_window"]["rows"])      # lo, hi, var comb, share off, H comb, H comb both signs, largest share, top sigma, top gamma, var zeta, H zeta, var comp, H comp both signs
xe = 0.5 * (EW[:, 0] + EW[:, 1])
TMAX = float(EW[-1, 1])
CLOSED = 2 + 0.5772156649015329 - np.log(4 * np.pi)

# ------------------------------------------------ Figure 1: variance by window
inv = c1["invariant"]["100000"]
xz = [0.5 * (a + b) for a, b in inv["windows"]]
vz = [r[0] for r in inv["rows"]]
tp = c2["psi_walk"]["true"]
xp = [0.5 * (r[0] + r[1]) for r in tp]
vp = [r[3] for r in tp]
vr = np.mean(np.array(c2["psi_walk"]["random_var"]), axis=0)
ve = dh["variance_entropy"]
xd = [0.5 * (r[0] + r[1]) for r in ve]
vd = [r[3] for r in ve]
fig, ax = plt.subplots(figsize=(6.6, 3.9))
ax.axhline(CLOSED, color=INK2, lw=0.8, ls=(0, (4, 3)))
ax.plot(xd, vd, color=ORANGE, lw=2, marker="s", ms=5, mec=SURF, mew=1)
ax.plot(xp, vr, color=YELLOW, lw=2, marker="^", ms=6, mec=SURF, mew=1)
ax.plot(xz, vz, color=BLUE, lw=2, marker="o", ms=5, mec=SURF, mew=1)
ax.plot(xp, vp, color=AQUA, lw=0, marker="D", ms=5, mec=SURF, mew=1)
ax.set_yscale("log")
ax.set_xlim(1, 37)
ax.set_ylim(0.02, 300)
ax.set_xlabel("log x (center of the window)")
ax.set_ylabel("variance of the scaled fluctuation")
ax.grid(axis="y", color=GRID, lw=0.6)
ax.set_axisbelow(True)
ax.text(xd[-1] + 0.5, vd[-1], "Davenport and Heilbronn\n(same symmetry, no primes)", color=INK, va="center", fontsize=8)
ax.text(xp[-1] + 0.5, vr[-1], "random primes", color=INK, va="center", fontsize=8)
ax.text(xz[-2], vz[-2] * 1.3, "zeta zeros", color=INK, va="bottom", ha="center", fontsize=8)
ax.text(xp[1], vp[1] * 0.62, "true primes (sieve)", color=INK, va="top", ha="center", fontsize=8)
ax.text(1.4, CLOSED * 1.18, "closed form 0.046191", color=INK2, fontsize=7.5)
ax.set_title("The variance is one number with the lock, and grows without it")
save(fig, "fig1_variance")

# ------------------------------------------------ Figure 4: entropy over modes, out to the last window of ri_figdata.py
fig, ax = plt.subplots(figsize=(6.6, 3.4))
ax.plot(xe, EW[:, 10], color=BLUE, lw=2)
ax.plot(xe, EW[:, 4], color=ORANGE, lw=2)
ax.plot(xe[::4], EW[::4, 10], ls="", marker="o", ms=4.5, color=BLUE, mec=SURF, mew=1)
ax.plot(xe[::4], EW[::4, 4], ls="", marker="s", ms=4.5, color=ORANGE, mec=SURF, mew=1)
ax.set_xlim(0, TMAX * 1.02)
ax.set_ylim(0, 4.6)
ax.set_xlabel("log x (center of the window)")
ax.set_ylabel("entropy over modes, H")
ax.grid(axis="y", color=GRID, lw=0.6)
ax.set_axisbelow(True)
ax.text(TMAX * 0.985, EW[-1, 10] - 0.16, f"zeta function: {EW[-1, 10]:.3f} in every window", color=INK, va="top", ha="right", fontsize=8)
ax.text(TMAX * 0.985, EW[-1, 4] + 0.2, f"Davenport and Heilbronn:\n{EW[0, 4]:.2f}, then {EW[:, 4].max():.2f}, down to {EW[-1, 4]:.2f}", color=INK, va="bottom", ha="right", fontsize=8)
ax.set_title("The entropy over modes is conserved only with every zero on the line")
save(fig, "fig4_entropy")

# ------------------------------------------------ Figure 3: zeros of the Davenport and Heilbronn function
z = dh["zeros"]
on = np.array(z["on_line"])
os_, og = np.array(z["off_sigma"]), np.array(z["off_gamma"])
fig, ax = plt.subplots(figsize=(6.6, 3.0))
ax.axhline(0.5, color=GRID, lw=0.8)
ax.plot(on, np.full(len(on), 0.5), ls="", marker="|", ms=2.6, mew=0.35, color=BLUE)
ax.plot(og, os_, ls="", marker="o", ms=4.2, color=ORANGE, mec=SURF, mew=0.6)
ax.plot(og, 1 - os_, ls="", marker="o", ms=4.2, color=ORANGE, mec=SURF, mew=0.6)
ax.set_xlim(0, 2000)
ax.set_ylim(0, 1)
ax.set_yticks([0, 0.25, 0.5, 0.75, 1])
ax.set_xlabel("height of the zero, Im s")
ax.set_ylabel("Re s")
ax.text(2010, 0.5, f"{len(on):,} on the line", color=INK, va="center", fontsize=8)
ax.text(2010, 0.86, f"{len(os_)} pairs off the line", color=INK, va="center", fontsize=8)
ax.set_title("Davenport and Heilbronn function: one zero in twelve leaves the line")
save(fig, "fig3_dh_zeros")

# ------------------------------------------------ Figure 2: pair statistics from the primes alone
keys = [("zeros1, zeros 1,001 to 10,000", "zeros 1,001 to 10,000"), ("zeros1, zeros 10,001 to 100,000", "zeros 10,001 to 100,000"),
        ("zeros3", "near zero $10^{12}$"), ("zeros4", "near zero $10^{21}$"), ("zeros5", "near zero $10^{22}$")]
fig, axs = plt.subplots(1, 5, figsize=(11.5, 2.9), sharey=True)
for ax, (k, lab) in zip(axs, keys):
    d = ph[k]
    e = np.array(d["edges"])
    mid = 0.5 * (e[:-1] + e[1:])
    ax.plot([0, 1], [0, 1], color=INK2, lw=0.9, ls=(0, (4, 3)))
    ax.plot(mid, d["primes"], color=AQUA, lw=2)
    ax.errorbar(mid, d["zeros"], yerr=d["err"], ls="", marker="o", ms=3.6, color=BLUE, mec=SURF, mew=0.5, elinewidth=0.9, capsize=0)
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1.05)
    ax.set_xticks([0, 0.5, 1])
    ax.set_title(lab, fontsize=8.5, fontweight="normal")
    ax.text(0.97, 0.05, f"primes {d['chi2_primes']:.2f}\nramp {d['chi2_ramp']:.2f}", transform=ax.transAxes, ha="right", va="bottom", fontsize=7.5, color=INK2)
    ax.grid(axis="y", color=GRID, lw=0.6)
    ax.set_axisbelow(True)
    ax.set_xlabel("τ")
axs[0].set_ylabel("form factor K(τ)")
h = [plt.Line2D([], [], ls="", marker="o", ms=4, color=BLUE), plt.Line2D([], [], color=AQUA, lw=2), plt.Line2D([], [], color=INK2, lw=0.9, ls=(0, (4, 3)))]
fig.legend(h, ["zeros (measured, with standard error)", "sum over primes, no zero used", "unitary ramp"], loc="upper center", ncol=3, frameon=False, fontsize=8.5, bbox_to_anchor=(0.5, 1.08))
fig.text(0.5, -0.06, "Numbers in each panel: mean of ((zeros − prediction) / error)², 1 = agreement within the error.", ha="center", fontsize=8, color=INK2)
save(fig, "fig2_pairs")

# ------------------------------------------------ Figure 5: the two components and their combination
from matplotlib.colors import LinearSegmentedColormap, LogNorm
MAGENTA = "#e87ba4"
pr4 = np.array(lp["primes"])
xq = 0.5 * (pr4[:, 0] + pr4[:, 1])
fig, axs = plt.subplots(1, 3, figsize=(11.5, 3.5))
ax = axs[0]
ax.axhline(lp["invariant"]["closed_form"], color=INK2, lw=0.8, ls=(0, (4, 3)))
ax.plot(xe, EW[:, 2], color=ORANGE, lw=2)
ax.plot(xe, EW[:, 11], color=MAGENTA, lw=2)
ax.plot(xq, pr4[:, 2], color=AQUA, lw=0, marker="D", ms=5, mec=SURF, mew=1)
ax.set_yscale("log")
ax.set_ylim(1e-3, EW[:, 2].max() * 30)
ax.set_xlim(0, TMAX * 1.02)
ax.set_xlabel("log x (center of the window)")
ax.set_ylabel("variance of the scaled fluctuation")
ax.set_title("Variance", fontsize=9.5)
ax.text(TMAX * 0.93, EW[-1, 2], "combination", color=INK, ha="right", va="top", fontsize=8)
ax.text(TMAX * 0.98, EW[-1, 11] * 8, "each component (zeros)", color=INK, ha="right", fontsize=8)
ax.text(xq[0], 0.0035, "diamonds: from its primes alone", color=INK, ha="left", fontsize=8)
ax = axs[1]
ax.axhline(np.log(2), color=INK2, lw=0.8, ls=(0, (4, 3)))
ax.plot(xe, EW[:, 12], color=MAGENTA, lw=2)
ax.plot(xe, EW[:, 5], color=ORANGE, lw=2)
ax.set_ylim(0, 4.4)
ax.set_xlim(0, TMAX * 1.02)
ax.set_xlabel("log x (center of the window)")
ax.set_ylabel("entropy over modes, H (zeros of both signs)")
ax.set_title("Entropy over modes", fontsize=9.5)
ax.text(TMAX * 0.98, EW[-1, 12] + 0.12, f"each component: {EW[-1, 12]:.3f}", color=INK, ha="right", fontsize=8)
ax.text(TMAX * 0.98, EW[-1, 5] + 0.3, f"combination: {EW[0, 5]:.2f} down to {EW[-1, 5]:.2f}", color=INK, ha="right", fontsize=8)
ax.text(TMAX * 0.02, np.log(2) - 0.08, "log 2: one mode and its mirror image below the axis", color=INK2, va="top", fontsize=7.5)
ax = axs[2]
pq = lp["pairs"]
e = np.array(pq["edges"])
mid = 0.5 * (e[:-1] + e[1:])
ax.plot([0, 1], [0, 1], color=INK2, lw=0.9, ls=(0, (4, 3)))
ax.plot(mid, pq["primes"], color=AQUA, lw=2)
ax.errorbar(mid, pq["zeros"], yerr=pq["err"], ls="", marker="o", ms=3.8, color=MAGENTA, mec=SURF, mew=0.5, elinewidth=0.9)
ax.set_xlim(0, 1)
ax.set_ylim(0, 1.2)
ax.set_xlabel("τ")
ax.set_ylabel("form factor K(τ)")
ax.set_title("Pair statistics of the components", fontsize=9.5)
ax.text(0.97, 0.05, f"primes {pq['chi2_primes']:.2f}\nramp {pq['chi2_ramp']:.2f}", transform=ax.transAxes, ha="right", va="bottom", fontsize=7.5, color=INK2)
ax.text(0.04, 1.1, "points: zeros   line: its primes   dashed: ramp", fontsize=7.5, color=INK2)
for ax in axs:
    ax.grid(axis="y", color=GRID, lw=0.6)
    ax.set_axisbelow(True)
fig.suptitle("The lock is present in each component and lost in their combination", x=0.06, ha="left", fontsize=10, fontweight="bold", y=1.02)
fig.tight_layout()
save(fig, "fig5_components")

# ------------------------------------------------ Figure 6 (heat map): share of each mode against log x
SEQ = LinearSegmentedColormap.from_list("blue_seq", [SURF, "#cde2fb", "#86b6ef", "#3987e5", "#1c5cab", "#0d366b"])
t = ARR["t"]
panels = [("Zeta function", ARR["shares_zeta"]), ("L(s, χ), one component", ARR["shares_chi"]), ("Combination (Davenport and Heilbronn)", ARR["shares_dh"])]
NROW = panels[0][1].shape[0]
fig, axs = plt.subplots(1, 3, figsize=(12.2, 4.2), sharey=True)
for ax, (lab, p) in zip(axs, panels):
    im = ax.imshow(p, aspect="auto", origin="lower", extent=[t[0], t[-1], 0.5, NROW + 0.5], cmap=SEQ,
                   norm=LogNorm(vmin=1e-4, vmax=1), interpolation="nearest")
    ax.set_title(lab, fontsize=9.5)
    ax.set_xlabel("log x")
    for sp in ax.spines.values():
        sp.set_visible(False)
top = int(np.argmax(ARR["shares_dh"][:, -1]))
axs[2].annotate(f"mode at {ARR['dh_sigma'][top]:.3f} + {ARR['dh_gamma'][top]:.1f} i", xy=(t[-1] * 0.97, top + 1), xytext=(t[-1] * 0.3, top + 16),
                fontsize=8, color=INK, arrowprops=dict(arrowstyle="-", color=INK2, lw=0.7))
axs[0].set_ylabel(f"mode number, in order of height (first {NROW})")
cb = fig.colorbar(im, ax=axs.tolist(), fraction=0.025, pad=0.015)
cb.set_label("share of the variance carried by the mode")
cb.outline.set_visible(False)
fig.suptitle("Where the variance sits, mode by mode", x=0.07, ha="left", fontsize=10, fontweight="bold", y=1.0)
save(fig, "fig6_mode_shares")

# ------------------------------------------------ Figure 7 (heat map): modulus across the critical strip
T1, T2 = fd["strip"]["T1"], fd["strip"]["T2"]
maps = [("Zeta function", ARR["mod_zeta"]), ("L(s, χ), one component", ARR["mod_chi"]), ("Combination (Davenport and Heilbronn)", ARR["mod_dh"])]
SEQR = LinearSegmentedColormap.from_list("blue_seq_r", ["#0d366b", "#1c5cab", "#3987e5", "#86b6ef", "#cde2fb", SURF])
fig, axs = plt.subplots(3, 1, figsize=(8.6, 6.0), sharex=True)
for ax, (lab, A) in zip(axs, maps):
    im = ax.imshow(A, aspect="auto", origin="lower", extent=[T1, T2, 0, 1], cmap=SEQR, norm=LogNorm(vmin=0.02, vmax=5), interpolation="bilinear")
    ax.axhline(0.5, color=INK, lw=0.5, ls=(0, (2, 3)))
    ax.set_yticks([0, 0.5, 1])
    ax.set_ylabel("Re s")
    ax.set_title(lab, fontsize=9.5)
    for sp in ax.spines.values():
        sp.set_visible(False)
for sgm, g, _, _ in fd["strip"]["zeros_dh_off"]:
    axs[2].annotate(f"{sgm:.3f} + {g:.1f} i", xy=(g, sgm), xytext=(g + 1.2, 0.93), fontsize=7.5, color=INK, va="top",
                    arrowprops=dict(arrowstyle="-", color=INK, lw=0.6))
axs[2].set_xlabel("height, Im s")
cb = fig.colorbar(im, ax=axs.tolist(), fraction=0.03, pad=0.02)
cb.set_label("|f(s)|  (dark = near zero)")
cb.outline.set_visible(False)
fig.suptitle("The zeros in the strip: on the line with the primes, off it without", x=0.07, ha="left", fontsize=10, fontweight="bold", y=0.97)
save(fig, "fig7_strip")
