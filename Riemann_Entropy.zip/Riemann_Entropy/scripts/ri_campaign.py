"""Riemann zeros campaign: invariant, primes by interference, stiffness (direct and reciprocal), restoring force.
Usage: python ri_campaign.py            (expects zeros1 in this folder; zeros3, zeros4, zeros5 optional)
"""
import json
import os
import numpy as np

GE = 0.5772156649015329
OUT = {}


def load_table(name):
    vals = []
    with open(name) as f:
        for line in f:
            try:
                vals.append(float(line.strip()))
            except ValueError:
                pass
    return np.array(vals)


def smooth_count(g):
    return (g / (2 * np.pi)) * np.log(g / (2 * np.pi * np.e)) + 7.0 / 8.0


def height_of_index(n):
    e = 2 * np.pi * n / np.log(n)
    for _ in range(100):
        e = e - (smooth_count(e) - n) / (np.log(e / (2 * np.pi)) / (2 * np.pi))
    return e


def rotor_sum(gam, t, chunk=400):
    f = np.zeros(len(t))
    for i in range(0, len(gam), chunk):
        gg = gam[i:i + chunk]
        f += 2.0 * np.real(np.exp(1j * np.outer(gg, t)) / (0.5 + 1j * gg)[:, None]).sum(axis=0)
    return f


def section(title):
    print()
    print("=" * 78)
    print(title)
    print("=" * 78)


g_all = load_table("zeros1")
print(f"loaded {len(g_all)} zeros from zeros1, last = {g_all[-1]:.3f}")
SIZES = [n for n in [1000, 10000, 100000] if n <= len(g_all)]

# ---------------------------------------------------------------- 1. invariant
section("1. INVARIANT: variance of the scaled prime fluctuation, by window in log x")
const = 2 + GE - np.log(4 * np.pi)
print(f"closed form for all zeros on the line: 2 + gamma_E - log(4 pi) = {const:.6f}")
WINDOWS = [(6, 9), (9, 12), (12, 15), (15, 18), (18, 21), (21, 24), (24, 27), (27, 30)]
DELTAS = [0.05, 0.1, 0.2]
OUT["invariant"] = {}
for N in SIZES:
    g = g_all[:N]
    tail = 2 * np.sum(1.0 / (0.25 + g ** 2))
    print(f"\nN = {N}   (2 sum 1/|rho|^2 over these zeros = {tail:.6f})")
    print("window      on line " + "".join(f"   d={d:4.2f}   " for d in DELTAS) + "  growth factors per window (d=0.05, 0.10, 0.20)")
    prev = None
    rows = []
    for lo, hi in WINDOWS:
        t = np.linspace(lo, hi, 6000)
        f0 = rotor_sum(g, t)
        rho1 = 0.5 + 1j * g[0]
        base1 = 2.0 * np.real(np.exp(1j * g[0] * t) / rho1)
        row = [f0.var()]
        exc = []
        for d in DELTAS:
            pert = 2.0 * np.real(np.exp((d + 1j * g[0]) * t) / (rho1 + d))
            v = (f0 - base1 + pert).var()
            row.append(v)
            exc.append(pert.var())
        gf = "" if prev is None else "   " + "  ".join(f"{a / b:6.3f}" for a, b in zip(exc, prev))
        prev = exc
        rows.append(row)
        print(f"[{lo:2d},{hi:2d}] " + "".join(f"{v:12.5f}" for v in row) + gf)
    on = np.array([r[0] for r in rows])
    print(f"on line: mean {on.mean():.5f}, spread (std over windows) {on.std():.5f}; predicted growth factors: "
          + "  ".join(f"{np.exp(6 * d):6.3f}" for d in DELTAS))
    OUT["invariant"][N] = {"windows": WINDOWS, "rows": rows, "partial_sum": tail}

# ---------------------------------------------------------------- 2. primes by interference
section("2. PRIMES BY INTERFERENCE: S(log n) = sum cos(gamma log n), all n from 2 to 60")
OUT["primes"] = {}
for N in SIZES:
    g = g_all[:N]
    T = g[-1]
    rel, bg = [], []
    lines = []
    for n in range(2, 61):
        p, k, m = None, 0, n
        for q in range(2, n + 1):
            if m % q == 0:
                while m % q == 0:
                    m //= q
                    k += 1
                p = q if m == 1 else None
                break
        S = np.cos(g * np.log(n)).sum()
        if p:
            pred = -(T / (2 * np.pi)) * np.log(p) / np.sqrt(n)
            rel.append(S / pred)
            lines.append((n, S, pred))
        else:
            bg.append(S)
    rel, bg = np.array(rel), np.array(bg)
    print(f"\nN = {N}: {len(rel)} prime powers, {len(bg)} other integers")
    print(f"  measured / predicted at prime powers: mean {rel.mean():.4f}, std {rel.std():.4f}, min {rel.min():.4f}, max {rel.max():.4f}")
    print(f"  at the other integers: rms {np.sqrt(np.mean(bg ** 2)):.3f}, max |S| {np.abs(bg).max():.3f}")
    print(f"  smallest spike / largest background: {min(abs(s) for _, s, _ in lines) / np.abs(bg).max():.1f}")
    OUT["primes"][N] = {"ratio_mean": rel.mean(), "ratio_std": rel.std(), "bg_rms": float(np.sqrt(np.mean(bg ** 2)))}


# ---------------------------------------------------------------- 3 to 5: stiffness statistics on several sets
def stiffness_report(w, label, E):
    """w: unfolded positions (mean spacing 1). E: height, for the saturation level."""
    s = np.diff(w)
    n = len(s)
    print(f"\n--- {label}: {len(w)} zeros, height about {E:.4g}, mean spacing {s.mean():.4f}, smallest {s.min():.4f}")
    ss = np.linspace(0, 4, 40001)
    wig = (32 / np.pi ** 2) * ss ** 2 * np.exp(-4 * ss ** 2 / np.pi)
    cdf = np.cumsum(wig) * (ss[1] - ss[0])
    print("  spacing below s:   zeros (+- error)   no stiffness   unitary s^2 law")
    res = {"spacing": [], "numvar": [], "form": []}
    for x in [0.1, 0.25, 0.5, 0.75]:
        fr = np.mean(s < x)
        er = np.sqrt(max(fr * (1 - fr), 1e-12) / n)
        u = cdf[np.searchsorted(ss, x)]
        print(f"  {x:5.2f}        {fr:8.5f} +- {er:7.5f} {1 - np.exp(-x):12.4f} {u:14.4f}")
        res["spacing"].append([x, fr, er])
    sat = (np.log(np.log(E / (2 * np.pi))) + 1.4009) / np.pi ** 2
    print(f"  count variance in a window of L spacings (saturation level from the primes, Berry: {sat:.4f})")
    print("       L      zeros   no stiffness   unitary log law")
    for L in [0.5, 1, 2, 4, 8, 16, 32, 64, 128, 256]:
        if L > len(w) / 20:
            break
        starts = np.arange(w[0], w[-1] - L, 0.25)
        cnt = np.searchsorted(w, starts + L) - np.searchsorted(w, starts)
        gue = (np.log(2 * np.pi * L) + GE + 1) / np.pi ** 2
        print(f"  {L:7.1f} {cnt.var():9.4f} {L:10.1f} {gue:14.4f}")
        res["numvar"].append([L, float(cnt.var()), gue])
    res["saturation_pred"] = sat
    B = 200
    tau = np.linspace(0.005, 2.5, 5000)
    K = np.zeros(len(tau))
    Ksq = np.zeros(len(tau))
    nb = 0
    for i in range(0, len(w) - B + 1, B):
        a = np.abs(np.exp(2j * np.pi * np.outer(tau, w[i:i + B])).sum(axis=1)) ** 2 / B
        K += a
        nb += 1
    K /= nb
    print(f"  power of the complex amplitude in reciprocal space ({nb} blocks of {B})")
    print("     tau        zeros   no stiffness   unitary ramp")
    edges = [0.05, 0.15, 0.25, 0.35, 0.5, 0.7, 0.9, 1.1, 1.5, 2.0, 2.5]
    for a, b in zip(edges[:-1], edges[1:]):
        m = (tau >= a) & (tau < b)
        c = 0.5 * (a + b)
        print(f"  {a:4.2f} to {b:4.2f} {K[m].mean():9.4f} {1.0:10.1f} {min(c, 1.0):13.3f}")
        res["form"].append([a, b, float(K[m].mean())])
    return res


section("3. STIFFNESS: spacing, count variance (saturation), reciprocal space ramp")
OUT["stiffness"] = {}
w_all = smooth_count(g_all)
sets = [("zeros 1 to 10,000", 0, 10000)]
if len(g_all) >= 100000:
    sets += [("zeros 45,001 to 55,000", 45000, 55000), ("zeros 90,001 to 100,000", 90000, 100000),
             ("all 100,000", 0, 100000)]
for label, i0, i1 in sets:
    i1 = min(i1, len(g_all))
    OUT["stiffness"][label] = stiffness_report(w_all[i0:i1], label, g_all[(i0 + i1) // 2])
for name, idx in [("zeros3", 1e12), ("zeros4", 1e21), ("zeros5", 1e22)]:
    if os.path.exists(name):
        v = load_table(name)
        E = height_of_index(idx)
        w = (v - v[0]) * np.log(E / (2 * np.pi)) / (2 * np.pi)
        OUT["stiffness"][name] = stiffness_report(w, f"{name}: zeros near number {idx:.0e}", E)
    else:
        print(f"\n({name} not found, skipped)")

# ---------------------------------------------------------------- 6. restoring force
section("4. RESTORING FORCE: zeros moved by hand, error of the prime count against the true primes")
LO, HI, NX = 6.0, 12.0, 24000
t = np.linspace(LO, HI, NX)
x = np.exp(t)
M = int(x[-1]) + 1
sieve = np.ones(M + 1, bool)
sieve[:2] = False
for i in range(2, int(M ** 0.5) + 1):
    if sieve[i]:
        sieve[i * i::i] = False
lam = np.zeros(M + 1)
for p in np.nonzero(sieve)[0]:
    q = p
    while q <= M:
        lam[q] = np.log(p)
        q *= p
psi_true = np.cumsum(lam)[np.floor(x).astype(int)]
base = x - np.log(2 * np.pi) - 0.5 * np.log(1 - x ** -2.0)
t2 = np.mean(t ** 2)
OUT["force"] = {}
for N in SIZES:
    g = g_all[:N]
    full = rotor_sum(g, t)

    def mse(idx, newg):
        f = full - rotor_sum(g[idx], t) + rotor_sum(np.asarray(newg, float), t)
        return np.mean(((base - np.sqrt(x) * f - psi_true) / np.sqrt(x)) ** 2)

    E0 = mse([0], [g[0]])
    print(f"\nN = {N}: error with every zero in place = {E0:.7f}")
    print("  zero    gamma      stiffness measured   stiffness predicted   ratio   minimum at")
    rows = []
    for k in [0, 2, 9, 29, 99, 299, 999]:
        if k >= N - 1:
            break
        aa = np.array([-0.02, -0.01, 0.0, 0.01, 0.02])
        ee = np.array([mse([k], [g[k] + a]) for a in aa])
        c2, c1, c0 = np.polyfit(aa, ee, 2)
        Kp = (2.0 / (0.25 + g[k] ** 2)) * t2
        print(f"  {k + 1:5d} {g[k]:9.3f} {c2:18.6f} {Kp:20.6f} {c2 / Kp:8.4f} {-c1 / (2 * c2):+10.5f}")
        rows.append([k + 1, g[k], c2, Kp])
    print("  pairs moved by the same distance: together / apart / same way (added error)")
    print("  pair          sep     fraction   together      apart    same way   together over apart")
    close = int(np.argmin(np.diff(smooth_count(g))))
    prs = []
    for k in sorted(set([9, 99, close])):
        if k >= N - 1:
            continue
        sep = g[k + 1] - g[k]
        for fr in [0.1, 0.3, 0.5]:
            a = fr * sep
            tog = mse([k, k + 1], [g[k] + a, g[k + 1] - a]) - E0
            apa = mse([k, k + 1], [g[k] - a, g[k + 1] + a]) - E0
            sam = mse([k, k + 1], [g[k] + a, g[k + 1] + a]) - E0
            tag = " (closest pair)" if k == close else ""
            print(f"  {k + 1:5d},{k + 2:<5d} {sep:7.4f} {fr:8.2f} {tog:12.3e} {apa:10.3e} {sam:10.3e} {tog / apa:10.3f}{tag}")
            prs.append([k + 1, sep, fr, tog, apa, sam])
    OUT["force"][N] = {"E0": E0, "wells": rows, "pairs": prs}

with open("ri_campaign_results.json", "w") as f:
    json.dump(OUT, f, indent=1, default=lambda o: float(o) if isinstance(o, (np.floating, np.integer)) else str(o))
print("\nsaved ri_campaign_results.json")
