#!/bin/bash
#SBATCH -A m4675
#SBATCH -C cpu
#SBATCH -q debug
#SBATCH -N 1
#SBATCH -t 00:30:00
#SBATCH -J ri_campaign3
#SBATCH -o ri_campaign3_%j.out
#SBATCH -e ri_campaign3_%j.err

module load python
source $SCRATCH/qiskit-env/bin/activate
cd "$SLURM_SUBMIT_DIR"

echo "===== ri_probe_height.py, sieve to 1e9 ====="
python ri_probe_height.py 1e9
echo
echo "===== ri_dh.py, zeros up to T = 2000, arithmetic side to 1e6 ====="
python ri_dh.py 2000 1e6
