"""Write gammas.npy: the first N zeros of the zeta function (imaginary parts), from mpmath.
Usage: python make_gammas.py 2000     (about 8 minutes for 2000 zeros)
The campaign itself reads Odlyzko's tables (zeros1, zeros3, zeros4, zeros5) and does not need this file.
"""
import sys
import numpy as np
import mpmath as mp

N = int(sys.argv[1]) if len(sys.argv) > 1 else 2000
mp.mp.dps = 20
g = np.array([float(mp.im(mp.zetazero(n))) for n in range(1, N + 1)])
np.save("gammas.npy", g)
print(len(g), "zeros saved, last =", g[-1])
