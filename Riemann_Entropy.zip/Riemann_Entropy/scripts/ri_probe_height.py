"""Two point probe at greater height: the ramp of the zeros rebuilt from the primes alone,
for the first 100,000 zeros (zeros1) and for the zeros near number 1e12, 1e21, 1e22 (zeros3, zeros4, zeros5).
The prime sum reaches tau = log(NMAX) / log(E / 2 pi), so each set is compared up to that tau only.
Usage: python ri_probe_height.py [NMAX]      (NMAX = sieve limit, default 1e9)
"""
import json
import os
import sys
import time
import numpy as np

T0 = time.time()
NMAX = int(float(sys.argv[1])) if len(sys.argv) > 1 else 10 ** 9
B = 200
OUT = {}


def load_table(name):
    vals = []
    with open(name) as f:
        for line in f:
            try:
                vals.append(float(line.strip()))
            except ValueError:
                pass
    return np.array(vals)


def smooth_count(g):
    return (g / (2 * np.pi)) * np.log(g / (2 * np.pi * np.e)) + 7.0 / 8.0


def height_of_index(n):
    e = 2 * np.pi * n / np.log(n)
    for _ in range(100):
        e = e - (smooth_count(e) - n) / (np.log(e / (2 * np.pi)) / (2 * np.pi))
    return e


# ---------------------------------------------------------------- primes
s = np.ones(NMAX + 1, dtype=bool)
s[:2] = False
for i in range(2, int(NMAX ** 0.5) + 1):
    if s[i]:
        s[i * i::i] = False
pr = np.nonzero(s)[0]
del s
lp = np.log(pr)
logs = [lp]
wts = [lp * lp / pr]
for p, l in zip(pr[pr <= int(NMAX ** 0.5)], lp):
    k, q = 2, int(p) * int(p)
    while q <= NMAX:
        logs.append(np.array([k * l]))
        wts.append(np.array([l * l / q]))
        k += 1
        q *= int(p)
logs = np.concatenate(logs)
wts = np.concatenate(wts)
order = np.argsort(logs)
logs, wts = logs[order], wts[order]
cw = np.concatenate([[0.0], np.cumsum(wts)])
TMAX = np.log(NMAX)
print(f"{len(pr)} primes up to {NMAX:.3g}, {len(logs)} prime powers, log = {TMAX:.3f}   [{time.time() - T0:.0f} s]")
print("Predicted: K(bin) = sum over prime powers with k log p / L in the bin of (log p)^2 / p^k, divided by L^2 * width,")
print("           L = log(E / 2 pi).  No zero enters.  Measured: power of the complex amplitude of the zeros,")
print(f"           blocks of {B} with a Hann taper.  +- is the standard error from the scatter of the blocks.")
sys.stdout.flush()
hann = 0.5 - 0.5 * np.cos(2 * np.pi * (np.arange(B) + 0.5) / B)


def probe(label, w, Lblock, key):
    """w: unfolded zeros; Lblock(i): L for the block starting at index i."""
    starts = list(range(0, len(w) - B + 1, B))
    Ls = np.array([Lblock(i) for i in starts])
    tau_max = TMAX / Ls.max()
    top = np.floor(tau_max * 20) / 20
    if top - tau_max > -0.004:
        top -= 0.05
    top = min(top, 1.0)          # the sum of these terms is valid below tau = 1
    edges = np.round(np.arange(0.05, top + 1e-9, 0.05), 2)
    if len(edges) < 3:
        print(f"\n--- {label}: the prime sum reaches only tau = {tau_max:.3f}; skipped")
        return
    tau = np.arange(0.05 + 0.00125, edges[-1], 0.0025)
    nbin = len(edges) - 1
    meas = np.zeros((len(starts), nbin))
    pred = np.zeros((len(starts), nbin))
    for b, i in enumerate(starts):
        ph = np.exp(2j * np.pi * np.outer(tau, w[i:i + B]))
        K = np.abs((ph * hann).sum(axis=1)) ** 2 / np.sum(hann ** 2)
        L = Ls[b]
        for j in range(nbin):
            a, c = edges[j], edges[j + 1]
            meas[b, j] = K[(tau >= a) & (tau < c)].mean()
            pred[b, j] = (cw[np.searchsorted(logs, c * L)] - cw[np.searchsorted(logs, a * L)]) / (L * L * (c - a))
    m = meas.mean(axis=0)
    e = meas.std(axis=0, ddof=1) / np.sqrt(len(starts))
    p = pred.mean(axis=0)
    mid = 0.5 * (edges[:-1] + edges[1:])
    print(f"\n--- {label}: {len(starts)} blocks, L = {Ls.min():.2f} to {Ls.max():.2f}, prime sum reaches tau = {tau_max:.3f}")
    print("     tau          zeros      +-     from primes   unitary ramp   zeros - primes   zeros - ramp   primes - ramp")
    for j in range(nbin):
        print(f"  {edges[j]:4.2f} to {edges[j + 1]:4.2f} {m[j]:9.4f} {e[j]:8.4f} {p[j]:12.4f} {mid[j]:12.3f} "
              f"{m[j] - p[j]:14.4f} {m[j] - mid[j]:14.4f} {p[j] - mid[j]:14.4f}")
    k = (edges[1:] <= 0.8 + 1e-9) & (p > 0) & (e > 0)      # bins that hold no prime power are left out
    chi_p = np.mean(((m[k] - p[k]) / e[k]) ** 2)
    chi_r = np.mean(((m[k] - mid[k]) / e[k]) ** 2)
    print(f"  bins below tau = 0.80 ({k.sum()} bins): rms(zeros - primes) = {np.sqrt(np.mean((m[k] - p[k]) ** 2)):.4f};  "
          f"rms(zeros - ramp) = {np.sqrt(np.mean((m[k] - mid[k]) ** 2)):.4f};  "
          f"rms(primes - ramp) = {np.sqrt(np.mean((p[k] - mid[k]) ** 2)):.4f};  mean standard error = {e[k].mean():.4f}")
    print(f"  mean of ((zeros - prediction) / error)^2 over those bins:  primes {chi_p:.2f};  unitary ramp {chi_r:.2f}   (1 = agreement within the error)")
    OUT[key] = {"edges": edges.tolist(), "zeros": m.tolist(), "err": e.tolist(), "primes": p.tolist(),
                "chi2_primes": float(chi_p), "chi2_ramp": float(chi_r), "L": [float(Ls.min()), float(Ls.max())]}
    sys.stdout.flush()


if os.path.exists("zeros1"):
    g = load_table("zeros1")
    w = smooth_count(g)
    sets = [("zeros1, zeros 1,001 to 10,000", 1000, 10000), ("zeros1, zeros 10,001 to 100,000", 10000, 100000)]
    for label, i0, i1 in sets:
        i1 = min(i1, len(g))
        if i1 - i0 >= 5 * B:
            gg = g[i0:i1]
            probe(label, w[i0:i1], lambda i, gg=gg: np.log(0.5 * (gg[i] + gg[i + B - 1]) / (2 * np.pi)), label)
for name, idx in [("zeros3", 1e12), ("zeros4", 1e21), ("zeros5", 1e22)]:
    if os.path.exists(name):
        v = load_table(name)
        E = height_of_index(idx)
        L = np.log(E / (2 * np.pi))
        w = (v - v[0]) * L / (2 * np.pi)
        probe(f"{name}: zeros near number {idx:.0e}, height {E:.4g}", w, lambda i, L=L: L, name)
    else:
        print(f"\n({name} not found, skipped)")

with open("ri_probe_height_results.json", "w") as f:
    json.dump(OUT, f, indent=1)
print(f"\nwrote ri_probe_height_results.json   [{time.time() - T0:.0f} s]")
