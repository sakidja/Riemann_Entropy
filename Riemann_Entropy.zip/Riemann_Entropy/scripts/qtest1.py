import numpy as np
from qiskit import QuantumCircuit
from qiskit.circuit.library import UnitaryGate
from qiskit.quantum_info import Statevector

NQ = 8                      # system qubits: 2**NQ zeros in one register
N = 2 ** NQ
SHOTS = 20000
rng = np.random.default_rng(1)
gammas = np.load("gammas.npy")[:N]
T = gammas[-1]


def hadamard_test(t):
    """Re <psi| U(t) |psi>, U = diag(exp(i gamma_n t)), |psi> = equal weight over all zeros."""
    qc = QuantumCircuit(NQ + 1)
    anc = NQ
    qc.h(range(NQ))          # equal weight: every mode has the same amplitude
    qc.h(anc)
    phases = np.concatenate([np.ones(N), np.exp(1j * gammas * t)])   # controlled U
    qc.append(UnitaryGate(np.diag(phases)), range(NQ + 1))
    qc.h(anc)
    p0 = Statevector(qc).probabilities([anc])[0]
    exact = 2 * p0 - 1
    sampled = 2 * rng.binomial(SHOTS, p0) / SHOTS - 1
    return exact, sampled


print(f"{NQ} system qubits + 1 ancilla, {N} zeros, T = {T:.1f}, {SHOTS} shots")
print("background rms expected:", 1 / np.sqrt(2 * N))
print("n                       exact    sampled   predicted")
for n in [2, 3, 4, 5, 7, 8, 9, 11, 13, 6, 10, 12]:
    p, k = None, 0
    for q in [2, 3, 5, 7, 11, 13]:
        m, kk = n, 0
        while m % q == 0:
            m //= q
            kk += 1
        if m == 1:
            p, k = q, kk
    pred = -(T / (2 * np.pi * N)) * np.log(p) / np.sqrt(n) if p else 0.0
    ex, sa = hadamard_test(np.log(n))
    tag = f"{n} = {p}^{k}" if p else f"{n} (not a prime power)"
    print(f"{tag:22s} {ex:8.4f} {sa:9.4f} {pred:10.4f}")

# Part 2: one mode off the line. exp(delta t) is not unitary, so it can only be
# done by post selection: D = diag(exp(delta_n t)) / exp(delta t), a contraction.
print()
print("one mode off the line by delta: success probability and mode entropy (max = log N = %.3f)" % np.log(N))
print("delta    t=log x   p_success    entropy")
for delta in [0.0, 0.05, 0.1, 0.2]:
    for t in [6.0, 12.0, 18.0, 24.0]:
        d = np.zeros(N)
        d[0] = delta
        amp = np.exp((d - delta) * t) / np.sqrt(N)      # post selected, unnormalized
        ps = np.sum(amp ** 2)
        pop = amp ** 2 / ps
        H = -np.sum(pop * np.log(pop + 1e-300))
        print(f"{delta:5.2f} {t:8.1f} {ps:12.6f} {H:10.4f}")
