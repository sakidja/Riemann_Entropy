"""Schematic of the Hadamard test circuit of Section 7 (the register and the readout).

This script draws a diagram. It reads no file and computes no number.
The circuit drawn is the one built in qtest1.py and qramp.py:
   h on the 8 register qubits            equal amplitude on the 256 zeros
   h on the ancilla
   controlled U(t) = diag(e^(i gamma_n t)), the ancilla as control
   X reading:  h on the ancilla, then measure
   Y reading:  sdg on the ancilla, then h, then measure

Writes  figures/fig_circuit_hadamard.png and .pdf

Usage:  python ri_circuit_fig.py
"""
import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Arc

HERE = os.path.dirname(os.path.abspath(__file__))
FLAT = os.path.exists(os.path.join(HERE, "ri_dh_results.json"))      # on Perlmutter the scripts and the results share one folder
F = os.path.join(HERE, "figures") if FLAT else os.path.join(HERE, "..", "figures")
os.makedirs(F, exist_ok=True)

BLUE, ORANGE, AQUA = "#2a78d6", "#eb6834", "#1baf7a"
INK, INK2, SURF = "#0b0b0b", "#52514e", "#fcfcfb"
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 10, "figure.facecolor": SURF, "savefig.facecolor": SURF,
                     "mathtext.fontset": "dejavusans"})

fig, ax = plt.subplots(figsize=(8.6, 4.5))
ax.set_xlim(0, 12.2)
ax.set_ylim(-0.9, 6.5)
ax.axis("off")

X0, X1 = 1.75, 11.6                       # the wires run from X0 to X1
YA = 5.5                                  # the ancilla
YR = [4.0, 3.3, 2.25, 1.2, 0.5]           # the register: q0, q1, dots, q6, q7
NAMES = ["$q_0$", "$q_1$", None, "$q_6$", "$q_7$"]


def gate(x, y, text, color, w=0.62, h=0.5, fs=11):
    ax.add_patch(FancyBboxPatch((x - w / 2, y - h / 2), w, h, boxstyle="round,pad=0.02,rounding_size=0.06",
                                fc=color, ec=INK, lw=1.0, zorder=3))
    ax.text(x, y, text, ha="center", va="center", fontsize=fs, color="white", fontweight="bold", zorder=4)


# wires and their labels
ax.plot([X0, X1], [YA, YA], color=INK, lw=1.2, zorder=1)
ax.text(X0 - 0.15, YA, r"ancilla  $|0\rangle$", ha="right", va="center", fontsize=10.5, color=INK)
for y, name in zip(YR, NAMES):
    if name is None:
        ax.text(X0 - 0.35, y, "⋮", ha="center", va="center", fontsize=14, color=INK2)
        ax.text(2.5, y, "⋮", ha="center", va="center", fontsize=14, color=INK2)
        continue
    ax.plot([X0, X1], [y, y], color=INK, lw=1.2, zorder=1)
    ax.text(X0 - 0.15, y, name + r"  $|0\rangle$", ha="right", va="center", fontsize=10.5, color=INK)

# state preparation
gate(2.5, YA, "H", BLUE)
for y, name in zip(YR, NAMES):
    if name is not None:
        gate(2.5, y, "H", BLUE)
ax.text(2.5, -0.35, "equal amplitude\non the 256 zeros", ha="center", va="top", fontsize=8.5, color=INK2)

# controlled U(t)
XU, WU = 5.6, 1.9
ax.add_patch(FancyBboxPatch((XU - WU / 2, YR[-1] - 0.38), WU, YR[0] - YR[-1] + 0.76, boxstyle="round,pad=0.02,rounding_size=0.08",
                            fc=ORANGE, ec=INK, lw=1.0, zorder=3))
ax.text(XU, 0.5 * (YR[0] + YR[-1]), r"$U(t)$", ha="center", va="center", fontsize=17, color="white", fontweight="bold", zorder=4)
ax.plot([XU, XU], [YR[0] + 0.40, YA], color=INK, lw=1.2, zorder=2)
ax.plot([XU], [YA], "o", color=INK, ms=7, zorder=4)
ax.text(XU, -0.35, r"$U(t)=\mathrm{diag}\left(e^{i\gamma_n t}\right)$" + "\ncontrolled by the ancilla", ha="center", va="top",
        fontsize=8.5, color=INK2)

# readout of the ancilla
XB, WB, HB = 8.45, 3.15, 1.05
ax.add_patch(FancyBboxPatch((XB - WB / 2, YA - HB / 2), WB, HB, boxstyle="round,pad=0.02,rounding_size=0.08",
                            fc=AQUA, ec=INK, lw=1.0, zorder=3))
ax.text(XB, YA + 0.24, r"X reading:  $H$", ha="center", va="center", fontsize=9.5, color="white", fontweight="bold", zorder=4)
ax.text(XB, YA - 0.24, r"Y reading:  $S^{\dagger}$, then $H$", ha="center", va="center", fontsize=9.5, color="white",
        fontweight="bold", zorder=4)

# the measurement
XM, WM, HM = 10.95, 0.8, 0.62
ax.add_patch(FancyBboxPatch((XM - WM / 2, YA - HM / 2), WM, HM, boxstyle="round,pad=0.02,rounding_size=0.06",
                            fc=SURF, ec=INK, lw=1.0, zorder=3))
ax.add_patch(Arc((XM, YA - 0.14), 0.5, 0.5, theta1=20, theta2=160, color=INK, lw=1.2, zorder=4))
ax.annotate("", xy=(XM + 0.2, YA + 0.2), xytext=(XM, YA - 0.14), arrowprops=dict(arrowstyle="-|>", color=INK, lw=1.1), zorder=5)
ax.text(9.3, 2.25, r"$\langle X\rangle = \mathrm{Re}\,\langle\psi|U(t)|\psi\rangle$" + "\n" +
        r"$\langle Y\rangle = \mathrm{Im}\,\langle\psi|U(t)|\psi\rangle$", ha="center", va="center", fontsize=10, color=INK2)

fig.savefig(os.path.join(F, "fig_circuit_hadamard.png"), dpi=300, bbox_inches="tight")
fig.savefig(os.path.join(F, "fig_circuit_hadamard.pdf"), bbox_inches="tight")
plt.close(fig)
print("wrote figures/fig_circuit_hadamard.png and .pdf")
